#!/usr/bin/env python3
"""
Migration Script Generator v3.0
Execute:  python main.py
"""
import os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
if BASE not in sys.path:
    sys.path.insert(0, BASE)

def _pip(pkg, imp=None):
    try: __import__(imp or pkg)
    except ImportError:
        print(f"  Instalando {pkg}...", flush=True)
        os.system(f'"{sys.executable}" -m pip install {pkg} -q '
                  f'--break-system-packages 2>NUL || '
                  f'"{sys.executable}" -m pip install {pkg} -q')

print("Verificando dependências...", flush=True)
_pip("customtkinter")
_pip("anthropic")
_pip("pyodbc")
_pip("mysql-connector-python", "mysql.connector")
_pip("psycopg2-binary", "psycopg2")

if __name__ == "__main__":
    from gui.app import MigrationApp
    MigrationApp()
