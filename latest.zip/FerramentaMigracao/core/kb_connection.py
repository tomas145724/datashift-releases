"""
Conexão com o banco de conhecimento (FerramentaMigracao).

Regra de thread-safety:
  - A conexão principal (get_kb()) só é usada no main thread
  - Threads em background usam make_thread_connection() — conexão própria
  - NENHUM lock global — cada thread tem sua própria conexão pyodbc
"""
from __future__ import annotations
import re, json
from datetime import datetime
from pathlib import Path

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  NOMES DAS TABELAS — edite aqui se quiser usar nomes diferentes          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

TABLE_NAMES = {
    "table_hints":   "ds_Tabelas",
    "field_hints":   "ds_Campos",
    "join_patterns": "ds_Joins",
    "sql_overrides": "ds_SqlCorrigidos",
    "final_scripts": "ds_ScriptsFinais",
    "history":       "ds_Historico",
}

T = TABLE_NAMES
CFG_FILE = Path(__file__).parent.parent / "data" / "kb_session.json"


def _n(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _build_conn_str(params: dict) -> str:
    import pyodbc
    trusted = str(params.get("trusted","false")).lower() in ("true","yes","s","1")
    avail   = pyodbc.drivers()
    driver  = next(
        (d for d in ["ODBC Driver 18 for SQL Server",
                      "ODBC Driver 17 for SQL Server",
                      "SQL Server"] if d in avail),
        avail[0] if avail else "ODBC Driver 17 for SQL Server",
    )
    cs = (f"DRIVER={{{driver}}};SERVER={params['host']},{params['port']};"
          f"DATABASE={params['database']};TrustServerCertificate=yes;")
    if trusted:
        cs += "Trusted_Connection=yes;"
    else:
        cs += f"UID={params['user']};PWD={params.get('password','')};"
    return cs


def _build_ddl() -> list[str]:
    return [
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["table_hints"]}')
        CREATE TABLE {T["table_hints"]} (
            id         INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            table_norm NVARCHAR(200) NOT NULL, table_orig NVARCHAR(200) NOT NULL,
            entity_key NVARCHAR(100) NOT NULL, db_type    NVARCHAR(100),
            weight     FLOAT NOT NULL DEFAULT 1.0, ts NVARCHAR(30), usuario NVARCHAR(100),
            CONSTRAINT uq_{T["table_hints"]} UNIQUE (table_norm, entity_key))""",
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["field_hints"]}')
        CREATE TABLE {T["field_hints"]} (
            id         INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            field_norm NVARCHAR(200) NOT NULL, field_orig NVARCHAR(200) NOT NULL,
            semantic   NVARCHAR(200) NOT NULL, db_type    NVARCHAR(100),
            weight     FLOAT NOT NULL DEFAULT 1.0, ts NVARCHAR(30), usuario NVARCHAR(100),
            CONSTRAINT uq_{T["field_hints"]} UNIQUE (field_norm, semantic))""",
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["join_patterns"]}')
        CREATE TABLE {T["join_patterns"]} (
            id        INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            table_a   NVARCHAR(200) NOT NULL, table_b   NVARCHAR(200) NOT NULL,
            condition_ NVARCHAR(MAX) NOT NULL, db_type  NVARCHAR(100),
            ts NVARCHAR(30), usuario NVARCHAR(100),
            CONSTRAINT uq_{T["join_patterns"]} UNIQUE (table_a, table_b))""",
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["sql_overrides"]}')
        CREATE TABLE {T["sql_overrides"]} (
            id         INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            entity_key NVARCHAR(100) NOT NULL, db_type NVARCHAR(100),
            sistema    NVARCHAR(200), client_tag NVARCHAR(200),
            sql_text   NVARCHAR(MAX) NOT NULL,
            ts NVARCHAR(30), usuario NVARCHAR(100))""",
        f"""IF EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["sql_overrides"]}')
        AND NOT EXISTS (SELECT 1 FROM sys.columns
            WHERE object_id=OBJECT_ID('{T["sql_overrides"]}') AND name='sistema')
        ALTER TABLE {T["sql_overrides"]} ADD sistema NVARCHAR(200) NULL""",
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["final_scripts"]}')
        CREATE TABLE {T["final_scripts"]} (
            id          INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            usuario     NVARCHAR(100) NOT NULL, cliente    NVARCHAR(200) NOT NULL,
            sistema     NVARCHAR(200) NOT NULL, tipo_banco NVARCHAR(100) NOT NULL,
            tipo_script NVARCHAR(100) NOT NULL, sql_text   NVARCHAR(MAX) NOT NULL,
            observacao  NVARCHAR(500),          ts         NVARCHAR(30) NOT NULL)""",
        f"""IF EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["final_scripts"]}')
        AND NOT EXISTS (SELECT 1 FROM sys.columns
            WHERE object_id=OBJECT_ID('{T["final_scripts"]}') AND name='cliente')
        ALTER TABLE {T["final_scripts"]} ADD cliente NVARCHAR(200) NOT NULL DEFAULT ''""",
        f"""IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='{T["history"]}')
        CREATE TABLE {T["history"]} (
            id         INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
            ts NVARCHAR(30), usuario NVARCHAR(100), db_type NVARCHAR(100),
            entity_key NVARCHAR(100), action NVARCHAR(100), detail NVARCHAR(MAX))""",
    ]


class KBConnection:
    """Conexão principal — usar APENAS no main thread."""

    def __init__(self):
        self._conn    = None
        self._params: dict = {}
        self.usuario: str  = ""
        self._load_saved()

    def _load_saved(self):
        CFG_FILE.parent.mkdir(parents=True, exist_ok=True)
        if CFG_FILE.exists():
            try:
                d = json.loads(CFG_FILE.read_text(encoding="utf-8"))
                self._params = d.get("params", {})
                self.usuario = d.get("usuario", "")
            except Exception:
                pass

    def save_params(self, params: dict, usuario: str):
        safe = {k: v for k, v in params.items() if k != "password"}
        CFG_FILE.write_text(
            json.dumps({"params": safe, "usuario": usuario},
                       ensure_ascii=False, indent=2),
            encoding="utf-8")

    @property
    def saved_params(self) -> dict: return self._params
    @property
    def saved_usuario(self) -> str: return self.usuario
    @property
    def T(self) -> dict: return TABLE_NAMES

    def connect(self, params: dict, usuario: str) -> bool:
        import pyodbc
        conn = pyodbc.connect(_build_conn_str(params), timeout=10,
                              autocommit=True)
        cur  = conn.cursor()
        for ddl in _build_ddl():
            cur.execute(ddl.strip())
        self._conn   = conn
        self._params = params
        self.usuario = usuario
        self.save_params(params, usuario)
        return True

    def is_connected(self) -> bool:
        """Verifica conexão SEM lock, SEM query extra."""
        return self._conn is not None

    def disconnect(self):
        if self._conn:
            try: self._conn.close()
            except Exception: pass
        self._conn = None

    def _cur(self):
        if not self._conn:
            raise RuntimeError("Não conectado.")
        return self._conn.cursor()

    def _ts(self) -> str:
        return datetime.now().isoformat(timespec="seconds")

    # ── Table hints ───────────────────────────────────────────────────────────

    def save_table_hint(self, table_name: str, entity_key: str,
                        db_type: str = "", weight: float = 1.0,
                        accumulate: bool = True):
        if not self.is_connected(): return
        norm = _n(table_name)
        cur  = self._cur()
        row  = cur.execute(
            f"SELECT id, weight FROM {T['table_hints']} "
            f"WHERE table_norm=? AND entity_key=?", (norm, entity_key)
        ).fetchone()
        if row:
            new_w = (row[1] + weight) if accumulate else max(row[1], weight)
            cur.execute(
                f"UPDATE {T['table_hints']} SET weight=?,ts=?,usuario=? WHERE id=?",
                (new_w, self._ts(), self.usuario, row[0]))
        else:
            cur.execute(
                f"INSERT INTO {T['table_hints']} "
                f"(table_norm,table_orig,entity_key,db_type,weight,ts,usuario) "
                f"VALUES (?,?,?,?,?,?,?)",
                (norm, table_name, entity_key, db_type, weight, self._ts(), self.usuario))

    def get_table_hint_score(self, table_name: str, entity_key: str) -> float:
        if not self.is_connected(): return 0.0
        row = self._cur().execute(
            f"SELECT weight FROM {T['table_hints']} "
            f"WHERE table_norm=? AND entity_key=?",
            (_n(table_name), entity_key)).fetchone()
        return float(row[0]) if row else 0.0

    def get_all_table_hints(self) -> list[dict]:
        if not self.is_connected(): return []
        cur = self._cur()
        cur.execute(f"SELECT table_orig,entity_key,weight FROM {T['table_hints']} ORDER BY weight DESC")
        return [{"table": r[0], "entity_key": r[1], "weight": r[2]} for r in cur.fetchall()]

    # ── Field hints ───────────────────────────────────────────────────────────

    def save_field_hint(self, field_name: str, semantic: str,
                        db_type: str = "", weight: float = 1.0,
                        accumulate: bool = True):
        if not self.is_connected(): return
        norm = _n(field_name)
        cur  = self._cur()
        row  = cur.execute(
            f"SELECT id, weight FROM {T['field_hints']} "
            f"WHERE field_norm=? AND semantic=?", (norm, semantic)
        ).fetchone()
        if row:
            new_w = (row[1] + weight) if accumulate else max(row[1], weight)
            cur.execute(
                f"UPDATE {T['field_hints']} SET weight=?,ts=?,usuario=? WHERE id=?",
                (new_w, self._ts(), self.usuario, row[0]))
        else:
            cur.execute(
                f"INSERT INTO {T['field_hints']} "
                f"(field_norm,field_orig,semantic,db_type,weight,ts,usuario) "
                f"VALUES (?,?,?,?,?,?,?)",
                (norm, field_name, semantic, db_type, weight, self._ts(), self.usuario))

    def get_field_hint_score(self, field_name: str, semantic: str) -> float:
        if not self.is_connected(): return 0.0
        row = self._cur().execute(
            f"SELECT weight FROM {T['field_hints']} "
            f"WHERE field_norm=? AND semantic=?",
            (_n(field_name), semantic)).fetchone()
        return float(row[0]) if row else 0.0

    def get_all_field_hints(self) -> list[dict]:
        if not self.is_connected(): return []
        cur = self._cur()
        cur.execute(f"SELECT field_orig,semantic,weight FROM {T['field_hints']} ORDER BY weight DESC")
        return [{"field": r[0], "semantic": r[1], "weight": r[2]} for r in cur.fetchall()]

    # ── Join patterns ─────────────────────────────────────────────────────────

    def save_join_pattern(self, table_a: str, table_b: str,
                          condition: str, db_type: str = ""):
        if not self.is_connected(): return
        na, nb = _n(table_a), _n(table_b)
        ka, kb = (na, nb) if na < nb else (nb, na)
        cur = self._cur()
        row = cur.execute(
            f"SELECT id FROM {T['join_patterns']} WHERE table_a=? AND table_b=?",
            (ka, kb)).fetchone()
        if row:
            cur.execute(
                f"UPDATE {T['join_patterns']} SET condition_=?,ts=?,usuario=? WHERE id=?",
                (condition, self._ts(), self.usuario, row[0]))
        else:
            cur.execute(
                f"INSERT INTO {T['join_patterns']} "
                f"(table_a,table_b,condition_,db_type,ts,usuario) VALUES (?,?,?,?,?,?)",
                (ka, kb, condition, db_type, self._ts(), self.usuario))

    def get_known_join(self, table_a: str, table_b: str) -> str | None:
        if not self.is_connected(): return None
        na, nb = _n(table_a), _n(table_b)
        ka, kb = (na, nb) if na < nb else (nb, na)
        row = self._cur().execute(
            f"SELECT condition_ FROM {T['join_patterns']} WHERE table_a=? AND table_b=?",
            (ka, kb)).fetchone()
        return row[0] if row else None

    def get_all_join_patterns(self) -> list[dict]:
        if not self.is_connected(): return []
        cur = self._cur()
        cur.execute(f"SELECT table_a,table_b,condition_ FROM {T['join_patterns']}")
        return [{"table_a": r[0], "table_b": r[1], "condition": r[2]}
                for r in cur.fetchall()]

    # ── SQL Overrides ─────────────────────────────────────────────────────────

    def save_sql_override(self, entity_key: str, sql: str,
                          db_type: str = "", client_tag: str = "",
                          sistema: str = ""):
        if not self.is_connected(): return
        self._cur().execute(
            f"INSERT INTO {T['sql_overrides']} "
            f"(entity_key,db_type,sistema,client_tag,sql_text,ts,usuario) VALUES (?,?,?,?,?,?,?)",
            (entity_key, db_type, sistema, client_tag, sql, self._ts(), self.usuario))

    def get_latest_override(self, entity_key: str) -> str | None:
        if not self.is_connected(): return None
        try:
            row = self._cur().execute(
                f"SELECT TOP 1 sql_text FROM {T['sql_overrides']} "
                f"WHERE entity_key=? ORDER BY ts DESC", (entity_key,)).fetchone()
            return row[0] if row else None
        except Exception:
            return None

    def get_overrides_list(self) -> list[dict]:
        """Retorna lista de mapeamentos fixos salvos com metadados."""
        if not self.is_connected(): return []
        try:
            cur = self._cur()
            cur.execute(
                f"SELECT entity_key, "
                f"ISNULL(sistema,'') AS sistema, "
                f"ISNULL(db_type,'') AS db_type, "
                f"ISNULL(client_tag,'') AS client_tag, "
                f"ISNULL(ts,'') AS ts, "
                f"ISNULL(usuario,'') AS usuario "
                f"FROM {T['sql_overrides']} ORDER BY ts DESC"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]
        except Exception as e:
            return []

    def get_final_script_for_entity(self, entity_key: str,
                                     sistema: str = "", db_type: str = "") -> str | None:
        """
        Busca script final que corresponda à entidade.
        Prioriza: mesmo sistema + mesmo banco → mesmo sistema → mais recente.
        """
        if not self.is_connected(): return None
        _tipo_map = {
            "cliente_fornecedor": "Clientes / Fornecedores",
            "produtos":           "Produtos",
            "contas_pagar":       "Contas a Pagar",
            "contas_receber":     "Contas a Receber",
        }
        tipo_script = _tipo_map.get(entity_key, "")
        if not tipo_script: return None

        cur = self._cur()
        # Tenta: mesmo sistema + mesmo banco
        if sistema and db_type:
            row = cur.execute(
                f"SELECT TOP 1 sql_text FROM {T['final_scripts']} "
                f"WHERE tipo_script=? AND sistema LIKE ? AND tipo_banco=? ORDER BY ts DESC",
                (tipo_script, f"%{sistema}%", db_type)
            ).fetchone()
            if row: return row[0]

        # Tenta: mesmo sistema
        if sistema:
            row = cur.execute(
                f"SELECT TOP 1 sql_text FROM {T['final_scripts']} "
                f"WHERE tipo_script=? AND sistema LIKE ? ORDER BY ts DESC",
                (tipo_script, f"%{sistema}%")
            ).fetchone()
            if row: return row[0]

        # Tenta: mesmo banco
        if db_type:
            row = cur.execute(
                f"SELECT TOP 1 sql_text FROM {T['final_scripts']} "
                f"WHERE tipo_script=? AND tipo_banco=? ORDER BY ts DESC",
                (tipo_script, db_type)
            ).fetchone()
            if row: return row[0]

        return None

    def has_override(self, entity_key: str) -> bool:
        if not self.is_connected(): return False
        try:
            row = self._cur().execute(
                f"SELECT TOP 1 1 FROM {T['sql_overrides']} WHERE entity_key=?",
                (entity_key,)).fetchone()
            return row is not None
        except Exception:
            return False

    def delete_overrides(self, entity_key: str):
        if not self.is_connected(): return
        self._cur().execute(
            f"DELETE FROM {T['sql_overrides']} WHERE entity_key=?", (entity_key,))

    # ── Scripts finais ────────────────────────────────────────────────────────

    def save_final_script(self, cliente: str, sistema: str, tipo_banco: str,
                          tipo_script: str, sql_text: str,
                          observacao: str = "") -> bool:
        if not self.is_connected(): return False
        self._cur().execute(
            f"INSERT INTO {T['final_scripts']} "
            f"(usuario,cliente,sistema,tipo_banco,tipo_script,sql_text,observacao,ts) "
            f"VALUES (?,?,?,?,?,?,?,?)",
            (self.usuario, cliente, sistema, tipo_banco,
             tipo_script, sql_text, observacao, self._ts()))
        return True

    def search_final_scripts(self, cliente: str = "", sistema: str = "",
                              tipo_banco: str = "", tipo_script: str = "") -> list[dict]:
        if not self.is_connected(): return []
        q = (f"SELECT id,usuario,cliente,sistema,tipo_banco,tipo_script,"
             f"ts,observacao FROM {T['final_scripts']} WHERE 1=1")
        p = []
        if cliente.strip():
            q += " AND cliente LIKE ?"; p.append(f"%{cliente.strip()}%")
        if sistema.strip():
            q += " AND sistema LIKE ?"; p.append(f"%{sistema.strip()}%")
        if tipo_banco and tipo_banco != "Todos":
            q += " AND tipo_banco=?"; p.append(tipo_banco)
        if tipo_script and tipo_script != "Todos":
            q += " AND tipo_script=?"; p.append(tipo_script)
        q += " ORDER BY ts DESC"
        cur = self._cur()
        cur.execute(q, p)
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def get_script_by_id(self, script_id) -> str | None:
        if not self.is_connected(): return None
        try: sid = int(script_id)
        except (ValueError, TypeError): sid = script_id
        row = self._cur().execute(
            f"SELECT sql_text FROM {T['final_scripts']} WHERE id=?", (sid,)).fetchone()
        return row[0] if row else None

    def delete_final_script(self, script_id) -> None:
        if not self.is_connected(): return
        try: sid = int(script_id)
        except (ValueError, TypeError): sid = script_id
        self._cur().execute(
            f"DELETE FROM {T['final_scripts']} WHERE id=?", (sid,))

    # ── Histórico ─────────────────────────────────────────────────────────────

    def save_history(self, entity_key: str, action: str,
                     db_type: str = "", detail: str = ""):
        if not self.is_connected(): return
        try:
            self._cur().execute(
                f"INSERT INTO {T['history']} "
                f"(ts,usuario,db_type,entity_key,action,detail) VALUES (?,?,?,?,?,?)",
                (self._ts(), self.usuario, db_type, entity_key, action, detail))
        except Exception:
            pass

    def get_history(self, limit: int = 50) -> list[dict]:
        if not self.is_connected(): return []
        cur = self._cur()
        cur.execute(
            f"SELECT TOP {limit} ts,usuario,db_type,entity_key,action,detail "
            f"FROM {T['history']} ORDER BY ts DESC")
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    # ── Estatísticas ──────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        if not self.is_connected(): return {}
        cur = self._cur()
        def count(tbl):
            return cur.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        return {
            "table_hints":   count(T["table_hints"]),
            "field_hints":   count(T["field_hints"]),
            "join_patterns": count(T["join_patterns"]),
            "sql_overrides": count(T["sql_overrides"]),
            "final_scripts": count(T["final_scripts"]),
        }


def load_kb_data() -> dict:
    """
    Carrega todos os dados de aprendizado do KB em memória (dict).
    Chamar no MAIN THREAD. O resultado pode ser passado para threads.
    """
    kb = get_kb()
    if not kb.is_connected():
        return {}

    result = {
        "table_hints":            {},
        "field_hints":            {},
        "join_patterns":          {},
        "overrides":              {},
        "final_scripts_fallback": {},
        "errors":                 [],
    }

    cur = kb._cur()

    # ── Tabelas aprendidas ────────────────────────────────────────────────
    try:
        cur.execute(f"SELECT table_norm, entity_key, weight FROM {T['table_hints']}")
        for row in cur.fetchall():
            result["table_hints"][(row[0], row[1])] = float(row[2])
    except Exception as e:
        result["errors"].append(f"table_hints: {e}")

    # ── Campos aprendidos ─────────────────────────────────────────────────
    try:
        cur.execute(f"SELECT field_norm, semantic, weight FROM {T['field_hints']}")
        for row in cur.fetchall():
            result["field_hints"][(row[0], row[1])] = float(row[2])
    except Exception as e:
        result["errors"].append(f"field_hints: {e}")

    # ── JOINs aprendidos ──────────────────────────────────────────────────
    try:
        cur.execute(f"SELECT table_a, table_b, condition_ FROM {T['join_patterns']}")
        for row in cur.fetchall():
            result["join_patterns"][(row[0], row[1])] = row[2]
    except Exception as e:
        result["errors"].append(f"join_patterns: {e}")

    # ── Mapeamentos fixos (overrides) ─────────────────────────────────────
    try:
        cur.execute(
            f"SELECT entity_key, sql_text FROM {T['sql_overrides']} "
            f"WHERE ts IN (SELECT MAX(ts) FROM {T['sql_overrides']} GROUP BY entity_key)"
        )
        for row in cur.fetchall():
            result["overrides"][row[0]] = row[1]
    except Exception as e:
        result["errors"].append(f"overrides: {e}")

    # ── Scripts finais — carrega TODOS para comparação por schema ────────
    try:
        _tipo_map = {
            "Clientes / Fornecedores": "cliente_fornecedor",
            "Produtos":                "produtos",
            "Contas a Pagar":          "contas_pagar",
            "Contas a Receber":        "contas_receber",
        }
        cur.execute(
            f"SELECT tipo_script, sql_text, tipo_banco, sistema "
            f"FROM {T['final_scripts']} ORDER BY ts DESC"
        )
        # final_scripts_all: lista de todos os scripts por entidade
        # final_scripts_fallback: mantido como antes (mais recente) — fallback sem schema
        result["final_scripts_all"] = {}
        for row in cur.fetchall():
            eid = _tipo_map.get(row[0], "")
            if not eid: continue
            entry = {
                "sql":        row[1],
                "tipo_banco": (row[2] or ""),
                "sistema":    (row[3] or ""),
            }
            result["final_scripts_all"].setdefault(eid, []).append(entry)
            # Primeiro encontrado = mais recente = fallback padrão
            if eid not in result["final_scripts_fallback"]:
                result["final_scripts_fallback"][eid] = entry
    except Exception as e:
        result["errors"].append(f"final_scripts: {e}")

    return result


# ── Singleton (main thread only) ──────────────────────────────────────────────

_kb: KBConnection | None = None

def get_kb() -> KBConnection:
    global _kb
    if _kb is None:
        _kb = KBConnection()
    return _kb


def make_thread_connection():
    """
    Cria uma conexão pyodbc INDEPENDENTE para uso em background threads.
    Retorna None se o KB não estiver conectado.
    """
    kb = get_kb()
    if not kb.is_connected():
        return None
    try:
        import pyodbc
        return pyodbc.connect(_build_conn_str(kb.saved_params), timeout=10,
                              autocommit=True)
    except Exception:
        return None
