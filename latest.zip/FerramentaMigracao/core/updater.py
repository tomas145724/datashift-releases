"""
Sistema de atualização automática via GitHub (repositório público de releases).

Estrutura recomendada:
  Repositório PRIVADO: seu-usuario/FerramentaMigracao  (código-fonte)
  Repositório PÚBLICO: seu-usuario/MigraPro-releases   (só distribuição)

O repositório público contém apenas:
  version.json   ← atualizado a cada release
  latest.zip     ← zip do app empacotado

Para publicar uma atualização:
  1. Empacote o app em .zip
  2. Acesse github.com/seu-usuario/MigraPro-releases
  3. Substitua version.json e latest.zip
  4. Todos os usuários recebem o aviso na próxima abertura

Formato do version.json no repositório público:
{
  "versao":    "6.6.0",
  "data":      "2026-03-20",
  "novidades": "- Melhoria X\\n- Correcao Y"
}
"""
from __future__ import annotations
import json, os, sys, shutil, zipfile
from pathlib import Path
from urllib import request

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  CONFIGURE AQUI — altere para o seu repositório PÚBLICO de releases     ║
# ╚══════════════════════════════════════════════════════════════════════════╝

RELEASES_USER = "tomas145724"        # ← seu usuário GitHub
RELEASES_REPO = "datashift-releases"  # ← repositório público de releases

# ══════════════════════════════════════════════════════════════════════════════
_BASE           = f"https://raw.githubusercontent.com/{RELEASES_USER}/{RELEASES_REPO}/main"
VERSION_URL     = f"{_BASE}/version.json"
DOWNLOAD_URL    = f"{_BASE}/latest.zip"
_VERSION_FILE   = Path(__file__).parent.parent / "version.json"
# ══════════════════════════════════════════════════════════════════════════════


def _parse(v: str) -> tuple:
    try:    return tuple(int(x) for x in v.strip().lstrip("v").split("."))
    except: return (0, 0, 0)


def get_local_version() -> dict:
    try:    return json.loads(_VERSION_FILE.read_text(encoding="utf-8"))
    except: return {"versao": "0.0.0", "novidades": ""}


def check_update(timeout: int = 6) -> dict | None:
    """Retorna dict da nova versão ou None se sem atualização / sem conexão."""
    try:
        req = request.Request(VERSION_URL,
                              headers={"User-Agent": "MigraPro/1.0",
                                       "Cache-Control": "no-cache"})
        with request.urlopen(req, timeout=timeout) as r:
            remote = json.loads(r.read().decode())
        local = get_local_version()
        if _parse(remote.get("versao","0")) > _parse(local.get("versao","0")):
            return remote
        return None
    except Exception:
        return None


def download_and_install(remote_info: dict, progress_cb=None) -> bool:
    """Baixa latest.zip, extrai e substitui arquivos. Preserva pasta data/."""
    import tempfile
    url     = remote_info.get("download_url") or DOWNLOAD_URL
    app_dir = Path(__file__).parent.parent
    try:
        req = request.Request(url, headers={"User-Agent": "MigraPro/1.0"})
        with request.urlopen(req, timeout=120) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            done, chunks = 0, []
            while True:
                chunk = resp.read(16384)
                if not chunk: break
                chunks.append(chunk); done += len(chunk)
                if progress_cb and total > 0:
                    progress_cb(int(done / total * 100))
        if progress_cb: progress_cb(100)

        with tempfile.TemporaryDirectory() as tmp:
            zp = Path(tmp) / "update.zip"
            zp.write_bytes(b"".join(chunks))
            with zipfile.ZipFile(zp) as zf:
                zf.extractall(tmp)
            dirs = [p for p in Path(tmp).iterdir()
                    if p.is_dir() and p.name != "__MACOSX"]
            src = dirs[0] if dirs else Path(tmp)

            PRESERVE = {"data"}
            for item in src.iterdir():
                if item.name in PRESERVE: continue
                dest = app_dir / item.name
                if item.is_dir():
                    if dest.exists(): shutil.rmtree(dest)
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
        return True
    except Exception as e:
        print(f"Erro ao atualizar: {e}"); return False


def restart_app():
    os.execv(sys.executable, [sys.executable] + sys.argv)


def show_update_dialog(parent, remote_info: dict) -> None:
    """Popup de atualização com barra de progresso."""
    import threading
    import tkinter as tk
    from tkinter import ttk

    local    = get_local_version()
    v_local  = local.get("versao", "?")
    v_remote = remote_info.get("versao", "?")
    novidades = remote_info.get("novidades", "")
    data_rel  = remote_info.get("data", "")

    dlg = tk.Toplevel(parent)
    dlg.title("Atualizacao disponivel")
    dlg.geometry("500x370"); dlg.resizable(False, False)
    dlg.grab_set(); dlg.configure(bg="#f0f2f5")
    dlg.update_idletasks()
    x = parent.winfo_x() + (parent.winfo_width()  - 500) // 2
    y = parent.winfo_y() + (parent.winfo_height() - 370) // 2
    dlg.geometry(f"+{x}+{y}")

    # Header
    hdr = tk.Frame(dlg, bg="#1a73e8"); hdr.pack(fill="x")
    tk.Label(hdr, text="  Nova versao disponivel!",
             font=("Segoe UI",12,"bold"), fg="white", bg="#1a73e8"
             ).pack(anchor="w", pady=10, padx=8)

    # Versões
    vf = tk.Frame(dlg, bg="#f0f2f5"); vf.pack(fill="x", padx=16, pady=(12,0))
    tk.Label(vf, text=f"Versao instalada:  {v_local}",
             font=("Segoe UI",10), fg="#5f6368", bg="#f0f2f5").pack(anchor="w")
    nova_txt = f"Nova versao:       {v_remote}"
    if data_rel: nova_txt += f"  ({data_rel})"
    tk.Label(vf, text=nova_txt,
             font=("Segoe UI",10,"bold"), fg="#137333", bg="#f0f2f5").pack(anchor="w")

    # Novidades
    if novidades:
        tk.Label(dlg, text="Novidades:",
                 font=("Segoe UI",10,"bold"), fg="#202124", bg="#f0f2f5"
                 ).pack(anchor="w", padx=16, pady=(10,2))
        txt = tk.Text(dlg, wrap="word", font=("Segoe UI",9),
                      bg="white", fg="#202124", relief="solid", bd=1,
                      height=5, padx=8, pady=6)
        txt.pack(fill="x", padx=16)
        txt.insert("1.0", novidades); txt.configure(state="disabled")

    # Progresso
    pf = tk.Frame(dlg, bg="#f0f2f5"); pf.pack(fill="x", padx=16, pady=(8,0))
    prog_lbl = tk.Label(pf, text="", font=("Segoe UI",9),
                        fg="#5f6368", bg="#f0f2f5")
    prog_lbl.pack(anchor="w")
    prog_bar = ttk.Progressbar(pf, length=460, mode="determinate")

    # Botões
    bf = tk.Frame(dlg, bg="#f0f2f5"); bf.pack(fill="x", padx=16, pady=10)

    def do_update():
        btn_ok.configure(state="disabled", text="Baixando...")
        btn_skip.configure(state="disabled")
        prog_bar.pack(fill="x", pady=(4,0))
        prog_lbl.configure(text="Iniciando download..."); dlg.update()

        def progress(pct):
            prog_bar["value"] = pct
            prog_lbl.configure(text=f"Baixando... {pct}%"); dlg.update()

        def run():
            ok = download_and_install(remote_info, progress_cb=progress)
            dlg.after(0, lambda: finish(ok))

        def finish(ok):
            if ok:
                prog_lbl.configure(text="Concluido! Reiniciando...", fg="#137333")
                dlg.update()
                dlg.after(1500, lambda: (dlg.destroy(), restart_app()))
            else:
                prog_lbl.configure(text="Erro ao baixar. Tente novamente.", fg="red")
                btn_skip.configure(state="normal")
                btn_ok.configure(state="normal", text="Tentar novamente")

        threading.Thread(target=run, daemon=True).start()

    btn_ok = tk.Button(bf, text="  Atualizar agora  ",
                       font=("Segoe UI",10,"bold"),
                       bg="#1a73e8", fg="white", relief="flat",
                       cursor="hand2", padx=12, pady=6,
                       command=do_update)
    btn_ok.pack(side="left", padx=(0,8))

    btn_skip = tk.Button(bf, text="Agora nao",
                         font=("Segoe UI",10),
                         bg="#e8eaed", fg="#202124", relief="flat",
                         cursor="hand2", padx=12, pady=6,
                         command=dlg.destroy)
    btn_skip.pack(side="left")

    tk.Label(bf, text="(dados e aprendizado preservados)",
             font=("Segoe UI",8), fg="#9aa0a6", bg="#f0f2f5"
             ).pack(side="right")
