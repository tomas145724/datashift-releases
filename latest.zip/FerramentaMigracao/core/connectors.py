"""
Conectores de banco de dados v2
=================================
Correções:
  • SQL Server: testa ODBC Driver 18, 17 e genérico automaticamente
               adiciona TrustServerCertificate=yes (necessário no Driver 18)
  • Mensagens de erro claras para cada tipo de falha
"""
from __future__ import annotations


def get_schema_from_db(db_type: str, params: dict) -> dict:
    if "Firebird"   in db_type: return _fb(params)
    if "MySQL"      in db_type: return _mysql(params)
    if "PostgreSQL" in db_type: return _pg(params)
    if "SQL Server" in db_type: return _ss(params)
    raise ValueError(f"Banco não suportado: {db_type}")


def get_sample_rows(db_type: str, params: dict,
                    table: str, limit: int = 3) -> list[dict]:
    try:
        conn = _connect(db_type, params)
        if "Firebird"    in db_type: q = f"SELECT FIRST {limit} * FROM {table}"
        elif "MySQL"     in db_type: q = f"SELECT * FROM `{table}` LIMIT {limit}"
        elif "PostgreSQL"in db_type: q = f'SELECT * FROM "{table}" LIMIT {limit}'
        else:                        q = f"SELECT TOP {limit} * FROM [{table}]"
        cur = conn.cursor()
        cur.execute(q)
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        return []


def execute_query(db_type: str, params: dict, sql: str,
                  max_rows: int = 5000) -> tuple[list[str], list[list]]:
    """
    Executa um SQL SELECT no banco do cliente.
    Retorna (colunas, linhas) ou levanta Exception com mensagem clara.
    """
    conn = _connect(db_type, params)
    try:
        cur = conn.cursor()
        cur.execute(sql)
        if cur.description is None:
            return [], []
        cols = [d[0] for d in cur.description]
        rows = []
        for i, r in enumerate(cur):
            if i >= max_rows:
                break
            rows.append([str(v) if v is not None else "" for v in r])
        return cols, rows
    finally:
        try: conn.close()
        except: pass


def _connect(db_type: str, params: dict):
    if "Firebird"   in db_type: return _fb_conn(params)
    if "MySQL"      in db_type: return _mysql_conn(params)
    if "PostgreSQL" in db_type: return _pg_conn(params)
    return _ss_conn(params)


# ─── Firebird ─────────────────────────────────────────────────────────────────

def _fb_conn(p):
    try:
        import firebirdsql as fb
    except ImportError:
        try:
            import fdb as fb
        except ImportError:
            raise ImportError(
                "Driver Firebird não encontrado.\n"
                "Execute:  pip install firebirdsql"
            )
    try:
        return fb.connect(
            host=p.get("host","localhost"), port=int(p.get("port",3050)),
            database=p["database"], user=p.get("user","SYSDBA"),
            password=p["password"], charset="WIN1252",
        )
    except Exception as e:
        raise ConnectionError(
            f"Firebird — falha:\n{e}\n\n"
            "Verifique: host, porta (3050), caminho do .fdb, usuário e senha."
        )


def _fb(p) -> dict:
    conn = _fb_conn(p)
    try:
        cur = conn.cursor()
        cur.execute("""SELECT TRIM(rdb$relation_name) FROM rdb$relations
                       WHERE rdb$view_blr IS NULL
                         AND (rdb$system_flag IS NULL OR rdb$system_flag=0)
                       ORDER BY rdb$relation_name""")
        tables = [r[0] for r in cur.fetchall()]
        schema: dict = {}
        for t in tables:
            cur.execute("""SELECT TRIM(rdb$field_name) FROM rdb$relation_fields
                           WHERE TRIM(rdb$relation_name)=?
                           ORDER BY rdb$field_position""", (t,))
            schema[t] = [r[0] for r in cur.fetchall()]
        return schema
    finally:
        conn.close()


# ─── MySQL ────────────────────────────────────────────────────────────────────

def _mysql_conn(p):
    try:
        import mysql.connector
    except ImportError:
        raise ImportError("Execute:  pip install mysql-connector-python")
    try:
        return mysql.connector.connect(
            host=p.get("host","localhost"), port=int(p.get("port",3306)),
            database=p["database"], user=p["user"], password=p["password"],
        )
    except Exception as e:
        raise ConnectionError(f"MySQL — falha:\n{e}")


def _mysql(p) -> dict:
    conn = _mysql_conn(p)
    try:
        cur = conn.cursor()
        db  = p["database"]
        cur.execute("SELECT TABLE_NAME FROM information_schema.TABLES "
                    "WHERE TABLE_SCHEMA=%s ORDER BY TABLE_NAME", (db,))
        tables = [r[0] for r in cur.fetchall()]
        schema: dict = {}
        for t in tables:
            cur.execute("SELECT COLUMN_NAME FROM information_schema.COLUMNS "
                        "WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s "
                        "ORDER BY ORDINAL_POSITION", (db, t))
            schema[t] = [r[0] for r in cur.fetchall()]
        return schema
    finally:
        conn.close()


# ─── PostgreSQL ───────────────────────────────────────────────────────────────

def _pg_conn(p):
    try:
        import psycopg2
    except ImportError:
        raise ImportError("Execute:  pip install psycopg2-binary")
    try:
        return psycopg2.connect(
            host=p.get("host","localhost"), port=int(p.get("port",5432)),
            dbname=p["database"], user=p["user"], password=p["password"],
        )
    except Exception as e:
        raise ConnectionError(f"PostgreSQL — falha:\n{e}")


def _pg(p) -> dict:
    conn = _pg_conn(p)
    try:
        cur = conn.cursor()
        cur.execute("SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema='public' ORDER BY table_name")
        tables = [r[0] for r in cur.fetchall()]
        schema: dict = {}
        for t in tables:
            cur.execute("SELECT column_name FROM information_schema.columns "
                        "WHERE table_schema='public' AND table_name=%s "
                        "ORDER BY ordinal_position", (t,))
            schema[t] = [r[0] for r in cur.fetchall()]
        return schema
    finally:
        conn.close()


# ─── SQL Server ───────────────────────────────────────────────────────────────

def _ss_conn(p):
    try:
        import pyodbc
    except ImportError:
        raise ImportError(
            "pyodbc não encontrado.\n"
            "Execute:  pip install pyodbc\n"
            "E instale: https://aka.ms/odbc17"
        )

    trusted = str(p.get("trusted","no")).lower() in ("s","sim","yes","y","1","true")
    host    = p.get("host","localhost")
    port    = p.get("port","1433")
    db      = p["database"]

    # Detecta drivers instalados e tenta em ordem
    try:
        avail = pyodbc.drivers()
        ordered = ["ODBC Driver 18 for SQL Server",
                   "ODBC Driver 17 for SQL Server",
                   "SQL Server"]
        candidates = [d for d in ordered if d in avail] or avail[:3]
    except Exception:
        candidates = ["ODBC Driver 17 for SQL Server", "SQL Server"]

    if not candidates:
        raise ConnectionError(
            "Nenhum driver ODBC para SQL Server encontrado no sistema.\n"
            "Baixe e instale em: https://aka.ms/odbc17"
        )

    last_err = None
    for driver in candidates:
        try:
            extra = "TrustServerCertificate=yes;"
            if trusted:
                cs = (f"DRIVER={{{driver}}};SERVER={host},{port};"
                      f"DATABASE={db};Trusted_Connection=yes;{extra}")
            else:
                cs = (f"DRIVER={{{driver}}};SERVER={host},{port};"
                      f"DATABASE={db};UID={p['user']};PWD={p['password']};{extra}")
            return pyodbc.connect(cs, timeout=10)
        except Exception as e:
            last_err = e
            continue

    raise ConnectionError(
        f"SQL Server — todos os drivers falharam.\n\n"
        f"Último erro: {last_err}\n\n"
        "Verifique:\n"
        "  1. ODBC Driver instalado → https://aka.ms/odbc17\n"
        "  2. SQL Server rodando e porta 1433 aberta\n"
        "  3. Host, porta, banco, usuário e senha corretos\n"
        "  4. SQL Server configurado para autenticação mista (se usando usuário/senha)"
    )


def _ss(p) -> dict:
    conn = _ss_conn(p)
    try:
        cur = conn.cursor()
        cur.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
                    "WHERE TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME")
        tables = [r[0] for r in cur.fetchall()]
        schema: dict = {}
        for t in tables:
            cur.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
                        "WHERE TABLE_NAME=? ORDER BY ORDINAL_POSITION", (t,))
            schema[t] = [r[0] for r in cur.fetchall()]
        return schema
    finally:
        conn.close()
