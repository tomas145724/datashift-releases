"""
Mapper v3 — Mapeamento Automático
===================================
Prioridade de resolução:
  1. SQL override no banco central (KB)     ← salvo por qualquer usuário da equipe
  2. SQL override local (learner JSON)      ← salvo neste computador
  3. Mapeamento Automático com pesos        ← learner local + pesos do KB
"""
from __future__ import annotations
import re
from core.learner import get_learner


def _n(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


# ─── Regras de tabelas ────────────────────────────────────────────────────────

TABLE_RULES: dict[str, dict] = {
    "tabela_cliente": {
        "hints":   ["cliente","clientes","customer","customers","cli",
                    "parceiro","parceirosneg","entidade","entidades",
                    "pessoa","pessoas","tcli","t_cli","tcliente","t_cliente",
                    "cadcliente","cadastrocliente","t_cad","cadpessoa"],
        "partial": ["client","clie","pess","enti"],
        "avoid":   ["fornec","supplier","produto","financ","pagar","receber",
                    "nota","fiscal","pedido","lancamento"],
    },
    "tabela_fornecedor": {
        "hints":   ["fornecedor","fornecedores","supplier","suppliers","vendor",
                    "tforn","t_forn","tfornecedor","t_fornecedor","t_frn",
                    "cadfornecedor","fornec"],
        "partial": ["forn","suppl","vend"],
        "avoid":   ["cliente","produto","pagar","receber","nota","lancamento"],
    },
    "tabela_produto": {
        "hints":   ["produto","produtos","product","products","item","itens",
                    "material","materiais","tprod","t_prod","cadproduto",
                    "sku","mercadoria","artigo","t_mat","t_item"],
        "partial": ["prod","item","merc","artig","mater"],
        "avoid":   ["cliente","fornec","financ","preco","custo","saldo",
                    "pagar","receber"],
    },
    "tabela_unidade": {
        "hints":   ["unidademedida","unidade","unit","und","undmedida",
                    "tunidade","t_und","t_unidade","unidmedida"],
        "partial": ["unid","unit"],
        "avoid":   ["produto","cliente","financ"],
    },
    "tabela_grupo": {
        "hints":   ["grupoproduto","grupo","category","categoria","group",
                    "tgrupo","t_grupo","grupodeproduto","linhaproduto",
                    "t_gprod","t_grpprod"],
        "partial": ["grup","categ","linh"],
        "avoid":   ["cliente","financ"],
    },
    "tabela_marca": {
        "hints":   ["marca","marcas","brand","brands","fabricante","tmarca","t_marca"],
        "partial": ["marc","brand","fabr"],
        "avoid":   ["cliente","financ"],
    },
    "tabela_estoque": {
        "hints":   ["saldoestoque","saldo_estoque","estoque","stock",
                    "inventory","posicaoestoque","saldo","testoq","t_estq"],
        "partial": ["estoque","stock","saldo","invent"],
        "avoid":   ["cliente","financ"],
    },
    "tabela_custo": {
        "hints":   ["custoproduto","custo_produto","custo","cost",
                    "precificacao","tabpreco","tabelapreco","tcusto","t_custo"],
        "partial": ["custo","cost","prec"],
        "avoid":   ["cliente","financ"],
    },
    "tabela_pagar": {
        "hints":   ["contapagar","conta_pagar","apagar","payable",
                    "contasapagar","lancamentopagar","tpagar","t_pagar",
                    "duplicatapagar","titulospagar","t_titulopagar","t_titpag"],
        "partial": ["pagar","payab"],
        "avoid":   ["receber","receiv"],
    },
    "tabela_receber": {
        "hints":   ["contareceber","conta_receber","areceber","receivable",
                    "contasareceber","lancamentoreceber","treceber",
                    "t_receber","duplicatareceber","titulosreceber",
                    "t_titulorec","t_titrec"],
        "partial": ["receber","receiv"],
        "avoid":   ["pagar","payab"],
    },
    "tabela_tipo_titulo": {
        "hints":   ["tipotitulo","tipo_titulo","portador","tipocobranca",
                    "tpportador","t_portador","t_tpotit"],
        "partial": ["portad","tipotit","tpotit"],
        "avoid":   [],
    },
    "tabela_municipio": {
        "hints":   ["municipio","municipios","cidade","cidades","city",
                    "ibge","tmunicipio","t_municipio","t_mun"],
        "partial": ["munic","cidade","ibge"],
        "avoid":   [],
    },
    "tabela_endereco": {
        "hints":   ["endereco","enderecos","address","logradouro",
                    "tendereco","t_endereco","cadendereco","t_cliend",
                    "cliend","endcli"],
        "partial": ["ender","addre","logr","cliend"],
        "avoid":   [],
    },
}

FIELD_HINTS: dict[str, list[str]] = {
    "CodCliente":              ["codcliente","cod_cliente","idcliente","id_cliente",
                                "clienteid","cd_cli","nr_cli","codigocliente"],
    "CodFornecedor":           ["codfornecedor","cod_fornecedor","idfornecedor",
                                "cd_frn","nr_frn","codigofornecedor"],
    "CodProduto":              ["codproduto","cod_produto","idproduto","cd_prod",
                                "nr_prod","codigoproduto","itemid","sku"],
    "nome":                    ["nome","razaosocial","razao_social","nm_cli","nm_rzascl",
                                "nm_fnt","name","dsnome","nmcliente","nmpessoa"],
    "NomeFantasia":            ["nomefantasia","nm_fantasia","nm_fnt","fantasia",
                                "apelido","nomecomercial"],
    "endereco":                ["endereco","logradouro","nm_rua","rua","ds_end","address"],
    "Complemento":             ["complemento","ds_complemento","complement","comp"],
    "numero":                  ["numero","nr_numero","num","nrlogradouro","numimovel"],
    "bairro":                  ["bairro","nm_brr","nm_bairro","district","dsbairro"],
    "cep":                     ["cep","nr_cep","zipcode","zip","cdcep"],
    "CodigoIBGE":              ["codigoibge","cd_ibge","ibge","codibge","codigomunicipio",
                                "cd_municipio"],
    "NomeCompleto":            ["nomecompleto","nm_cidade","nomecidade","municipio",
                                "dsmunicipio","dscidade"],
    "UF":                      ["uf","cd_uf","estado","siglauf","siglaestado"],
    "CodMunicipio":            ["codmunicipio","cd_municipio","idmunicipio",
                                "codcidade","nr_municipio"],
    "CNPJ_CPF":                ["cnpj_cpf","nr_cpfcnpj","cpf_cnpj","cnpj","cpf",
                                "nrdocumento","nrcpfcnpj"],
    "InscricaoEstadual":       ["inscricaoestadual","nr_rgie","ie","nrie"],
    "rg":                      ["rg","nr_rg","identidade","numerorg"],
    "InscricaoMunicipal":      ["inscricaomunicipal","nr_inscmunicipal","im"],
    "email":                   ["email","ds_email","emailprincipal","e_mail"],
    "Email1":                  ["email2","email1","emailsecundario"],
    "Email2":                  ["email3","email2"],
    "Telefone":                ["telefone","nr_tel","fone","tel","nrtelefone"],
    "Telefone2":               ["telefone2","nr_tel2","fone2"],
    "Telefone3":               ["telefone3","nr_tel3","fone3"],
    "Celular":                 ["celular","nr_cel","cel","mobile"],
    "Celular2":                ["celular2","nr_cel2","cel2"],
    "Fax":                     ["fax","nr_fax","telefax"],
    "LimiteCredito":           ["limitecredito","vl_credito","limite_credito","vlcredito"],
    "VencimentoLimiteCredito": ["vencimentolimitecredito","vencimentocredito","dtvencredito"],
    "DataCadastro":            ["datacadastro","dt_cadastro","dt_cds","dtcadastro",
                                "createdat","dataabertura"],
    "Observacao":              ["observacao","ds_obs","obs","note","dsobservacao"],
    "Observacao2":             ["observacao2","ds_obs2","obs2"],
    "ObservacaoCliente":       ["observacaocliente","ds_obscli","obscliente"],
    # Produto
    "aplicacao":               ["aplicacao","ds_aplic","application","uso"],
    "CodUnidadeMedida":        ["codunidademedida","cd_und","unidade","undmedida"],
    "nomeUnidadeMedida":       ["descricao","nm_und","sigla","abreviacao","dsunidade"],
    "CodigoFabricante":        ["codigofabricante","cd_fab","fabricante","manufacturer"],
    "linha":                   ["linha","ds_linha","linhadeproduto","tipoproduto"],
    "familia":                 ["familia","ds_familia","subfamilia"],
    "grupo":                   ["grupo","ds_grupo","grupoproduto"],
    "marca":                   ["marca","ds_marca","brand"],
    "MargemLucro":             ["margemlucro","vl_margem","margem","pctmargem"],
    "NCM":                     ["ncm","cd_ncm","codigoncm","ncmsh"],
    "CEST":                    ["cest","cd_cest","codigocest"],
    "CodigoANP":               ["codigoanp","cd_anp","anp"],
    "Ativo":                   ["ativo","fl_ativo","active","status","situacao"],
    "PrecoVenda":              ["precovenda","vl_venda","preco_venda","pvenda"],
    "CustoCompra":             ["custocompra","vl_custo","custo_compra","vlcusto"],
    "CustoMedioPonderado":     ["customedioponderado","vl_cusmed","custo_medio","cmp"],
    "SaldoAtual":              ["saldoatual","qt_saldo","saldo_atual","qtdatual"],
    # Financeiro
    "codigo_fornecedor":       ["codfornecedor","cd_frn","cod_fornecedor","fornecedor_id"],
    "titulo":                  ["numerotitulo","nr_titulo","titulo","nrdocumento"],
    "parcela":                 ["parcela","nr_parcela","parc","installment"],
    "DataEmissao":             ["dataemissao","dt_emissao","emissao","dtlanc","dt_lanc"],
    "DataVencimento":          ["datavencimento","dt_vcto","vencimento","duedate","dt_venc"],
    "Valor":                   ["valor","vl_titulo","vl_doc","amount","vlr"],
    "ValorPago":               ["valorpago","vl_pago","vlrpago","pago"],
    "DataPagamento":           ["datapagamento","dt_pago","pagamento","databaixa","dt_baixa"],
    "portador_codpagamento":   ["portador","ds_portador","nomeportador","formacobranca"],
    "CodCliente_rec":          ["codcliente","cd_cli","cod_cliente","idcliente"],
    "Titulo":                  ["numerotitulo","nr_titulo","titulo","documento"],
    "Parcela":                 ["parcela","nr_parcela","numeroparcela"],
    "valor":                   ["valor","vl_titulo","vlr","amount"],
    "ValorRecebido":           ["valorrecebido","vl_recebido","vlrrecebido","recebido"],
    "valorMoraDiaria":         ["valormora","vl_mora","mora","juros","vlmora"],
    "ValorDaMulta":            ["valordemulta","vl_multa","multa","fine"],
    "DataRecebimento":         ["datarecebimento","dt_recebimento","databaixa","dt_baixa"],
    "NossoNumero":             ["nossonumero","nr_nosso","our_number"],
    "portador":                ["portador","ds_portador","nomeportador","formacobranca"],
    "Observacao_rec":          ["observacao","ds_obs","obs","note"],
    "status":                  ["status","fl_status","situacao","stregistro","cd_status"],
    # ── Novos campos adicionados no template ──────────────────────────────
    "DataNascimento":          ["datanascimento","dt_nasc","dtnascimento","nascimento","dt_nascimento"],
    "sexo":                    ["sexo","ds_sexo","genero","gender","fl_sexo","cd_sexo"],
    "site":                    ["site","ds_site","website","url","homepage","nm_site","ds_homepage"],
    "descricao":               ["descricao","ds_descricao","descricaodetalhada","ds_prod",
                                "description","ds_item","nm_descricao","ds_complemento2"],
    "PesoBruto":               ["pesobruto","vl_pesobruto","peso_bruto","peso","nr_peso",
                                "vl_peso","pesobrutoproduto"],
    "PesoLiquido":             ["pesoliquido","vl_pesoliq","peso_liquido","nr_pesoliq",
                                "pesoliquidoproduto","vl_peso_liq"],
    "CodigoDeBarras":          ["codigodebarras","cd_barras","nr_barras","barcode",
                                "ean","gtin","nr_ean","ds_barras","cd_ean"],
    "CodigoFornecedor":        ["codigofornecedorproduto","cd_frn_prod","fornecedorprincipal",
                                "cd_fornecedor","nr_forn"],
    "PrecoCompra":             ["precocompra","vl_prccompra","preco_compra","vl_precocompra",
                                "precodecompra","vl_compra"],
    "CustoReposicao":          ["custoreposicao","vl_custrep","custo_reposicao","vl_custo_rep",
                                "custodereposicao"],
    "CustoMedio":              ["customedio","vl_cusmed","custo_medio","customedioponderado",
                                "cmp","vl_cmp","vl_custo_med","customedio"],
    "CustoInformado":          ["custoinformado","vl_custoinf","custo_informado","vl_custo_inf"],
    "SaldoEstoque":            ["saldoestoque","qt_saldo","saldo_estoque","saldoatual",
                                "qt_estoque","saldo","qt_atual","vl_saldo"],
    "Locacao":                 ["locacao","fl_locacao","aluguel","fl_aluguel","cd_locacao"],
    "Sublocacao":              ["sublocacao","fl_sublocacao","sub_locacao","cd_sublocacao"],
    "Estabelecimento":         ["estabelecimento","cd_est","nr_est","codigoestabelecimento",
                                "cd_empresa","nr_empresa"],
    "Observacoes":             ["observacoes","ds_obs","obs","observacao","ds_observacoes",
                                "observacao_doc","ds_obsdoc"],
    "desconto":                ["desconto","vl_desconto","vl_desc","descto","nr_desconto",
                                "vl_abatimento"],
    "taxaadiministrativa":     ["taxaadministrativa","taxa_administrativa","vl_taxa",
                                "txadm","taxaadm","vl_txadm","taxa_adm"],
}


# ─── Funções de scoring ───────────────────────────────────────────────────────

def _score(table: str, rule_key: str, learner, kb=None) -> float:
    """Pontua o quanto a tabela se encaixa na regra.
    Usa pesos do learner local E do banco central (KB)."""
    rules = TABLE_RULES.get(rule_key, {})
    nt    = _n(table)
    score = 0.0

    # Mapa de entity_key por rule_key
    entity_of = {
        "tabela_cliente":    "cliente_fornecedor",
        "tabela_fornecedor": "cliente_fornecedor",
        "tabela_produto":    "produtos",
        "tabela_pagar":      "contas_pagar",
        "tabela_receber":    "contas_receber",
    }
    ent = entity_of.get(rule_key)
    if ent:
        # Peso do learner local
        score += learner.table_hint_score(table, ent) * 3.0
        # Peso do banco central (compartilhado entre usuários)
        if kb:
            score += kb.get_table_hint_score(table, ent) * 4.0

    for h in rules.get("hints", []):
        if nt == h:      score += 10.0
        elif h in nt:    score += 4.0
        elif nt in h:    score += 2.0
    for p in rules.get("partial", []):
        if p in nt:      score += 2.0
    for a in rules.get("avoid", []):
        if a in nt:      score -= 8.0

    return score


def _best(rule: str, schema: dict, learner, kb=None,
          exclude: list = None) -> str:
    exclude = exclude or []
    best, bs = None, -9999.0
    for t in schema:
        if t in exclude: continue
        s = _score(t, rule, learner, kb)
        if s > bs: best, bs = t, s
    return best or (list(schema.keys())[0] if schema else "<tabela>")


def _col(table: str, sem: str, schema: dict, learner, kb=None) -> str | None:
    cols  = schema.get(table, [])
    if not cols: return None
    ncols = {_n(c): c for c in cols}

    # 1. Peso aprendido no learner local
    for c in cols:
        if learner.field_boost(c, sem) > 0:
            return c

    # 2. Peso aprendido no banco central
    if kb:
        for c in cols:
            if kb.get_field_hint_score(c, sem) > 0:
                return c

    hints = FIELD_HINTS.get(sem, [sem.lower()])

    # 3. Match exato por sinônimos
    for h in hints:
        if _n(h) in ncols: return ncols[_n(h)]

    # 4. Match parcial
    for h in hints:
        nh = _n(h)
        for nc, c in ncols.items():
            if nh and nc and (nh in nc or nc in nh): return c

    return None


def _ref(alias: str, col: str | None, sem: str) -> str:
    return f"{alias}.{col}" if col else f"/* NÃO_ENCONTRADO: {sem} */"


def _auto_join(primary: str, pa: str, target: str, ta: str,
               schema: dict, learner, kb=None) -> str | None:
    # 1. JOIN aprendido no banco central
    if kb:
        known = kb.get_known_join(primary, target)
        if known:
            return f"LEFT JOIN {target} {ta} ON {known}"

    # 2. JOIN aprendido no learner local
    known = learner.known_join(primary, target)
    if known:
        return f"LEFT JOIN {target} {ta} ON {known}"

    pcols = {_n(c): c for c in schema.get(primary, [])}
    tcols = {_n(c): c for c in schema.get(target,  [])}

    # 3. Nome de coluna idêntico nas duas tabelas
    for nc in tcols:
        if nc in pcols:
            cond = f"{pa}.{pcols[nc]} = {ta}.{tcols[nc]}"
            # Aprende nos dois lugares
            learner.learn_join(primary, target, cond)
            # kb.save_join_pattern omitido aqui — não seguro em thread
            return f"LEFT JOIN {target} {ta} ON {cond}"

    # 4. FK por nome
    nt = _n(target)
    for nc, pc in pcols.items():
        if len(nt) >= 4 and (nt[:5] in nc or _n(pc) in nt):
            for pk in ["id", "cod"+nt[:5], "codigo", "pk"]:
                if pk in tcols:
                    cond = f"{pa}.{pc} = {ta}.{tcols[pk]}"
                    learner.learn_join(primary, target, cond)
                    return f"LEFT JOIN {target} {ta} ON {cond}"
            if schema.get(target):
                cond = f"{pa}.{pc} = {ta}.{schema[target][0]}"
                learner.learn_join(primary, target, cond)
                return f"LEFT JOIN {target} {ta} ON {cond}"
    return None


def _resolve(primary: str, pa: str, fields: list,
             schema: dict, learner, kb=None) -> tuple[dict, list, list]:
    resolved, joins, joined = {}, [], {}
    n = [0]
    def nxt(t): n[0] += 1; return t[:2].lower() + str(n[0])

    for sem in fields:
        c = _col(primary, sem, schema, learner, kb)
        if c: resolved[sem] = _ref(pa, c, sem)

    missing = [s for s in fields if s not in resolved]

    for tbl in schema:
        if not missing or tbl == primary: continue
        hits = [s for s in missing if _col(tbl, s, schema, learner, kb)]
        if not hits: continue
        alias = joined.get(tbl)
        if not alias:
            alias = nxt(tbl)
            jl = _auto_join(primary, pa, tbl, alias, schema, learner, kb)
            joins.append(jl if jl else
                         f"-- LEFT JOIN {tbl} {alias} ON <condição não detectada>")
            joined[tbl] = alias
        for s in hits:
            resolved[s] = _ref(alias, _col(tbl, s, schema, learner, kb), s)
            missing.remove(s)

    return resolved, joins, missing


# ─── Ponto de entrada ─────────────────────────────────────────────────────────

def _score_script_vs_schema(sql: str, schema: dict) -> int:
    """Pontua similaridade entre SQL salvo e schema atual.
    +5/tabela encontrada, +3 bônus FROM, +1/campo encontrado.
    """
    import re as _re
    schema_tables = {_n(t) for t in schema.keys()}
    schema_fields = {_n(f) for cols in schema.values() for f in cols}
    score = 0
    sql_tables = set()
    for m in _re.finditer(r'\b(?:FROM|JOIN)\s+(\w+)', sql, _re.IGNORECASE):
        sql_tables.add(_n(m.group(1)))
    for t in sql_tables:
        if t in schema_tables: score += 5
    m_from = _re.search(r'\b(?:FROM)\s+(\w+)', sql, _re.IGNORECASE)
    if m_from and _n(m_from.group(1)) in schema_tables: score += 3
    for m in _re.finditer(r'(?:\w+\.)?([\w]+)\s+[Aa][Ss]\s+[\w]+', sql):
        fc = _n(m.group(1))
        if fc and len(fc) > 2 and fc in schema_fields: score += 1
    return score


def _best_script_for_schema(candidates: list, schema: dict) -> dict | None:
    """
    Dado uma lista de scripts salvos, retorna o que tem maior
    similaridade com o schema atual do banco conectado.
    """
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    best = max(candidates,
               key=lambda e: _score_script_vs_schema(e["sql"], schema))
    return best


def map_schema(schema: dict, entity_key: str, kb_data: dict = None, current_schema: dict = None) -> dict:
    """
    Retorna o mapeamento.
    kb_data: dict pré-carregado no main thread com dados do KB.
             Se None, usa só o learner local (offline).

    Prioridade:
      1. Mapeamento Fixo do KB (ds_SqlCorrigidos)
      2. Mapeamento Fixo local (learner)
      3. Script Final salvo — escolhe o mais similar ao schema atual
      4. Mapeamento Automático (heurística + pesos aprendidos)
    """
    learner = get_learner()

    # Wrapper que lê do kb_data (dict em memória, sem conexão)
    kb = None
    if kb_data:
        class _MemKB:
            def get_table_hint_score(self, table_name, entity_key):
                key = (_n(table_name), entity_key)
                return kb_data.get("table_hints", {}).get(key, 0.0)
            def get_field_hint_score(self, field_name, semantic):
                key = (_n(field_name), semantic)
                return kb_data.get("field_hints", {}).get(key, 0.0)
            def get_known_join(self, table_a, table_b):
                na, nb = _n(table_a), _n(table_b)
                ka, kb2 = (na, nb) if na < nb else (nb, na)
                return kb_data.get("join_patterns", {}).get((ka, kb2))
            def has_override(self, entity_key):
                return entity_key in kb_data.get("overrides", {})
            def get_latest_override(self, entity_key):
                return kb_data.get("overrides", {}).get(entity_key)
            def is_connected(self): return True
        kb = _MemKB()

    # ── 1. Mapeamento Fixo do banco central ─────────────────────────────────
    if kb and kb.has_override(entity_key):
        sql = kb.get_latest_override(entity_key)
        if sql:
            return {
                "__sql_override__": True,
                "__sql__":          sql,
                "mapeamento": "✓ Mapeamento fixo salvo",
            }

    # ── 2. Mapeamento Fixo local (learner) ───────────────────────────────────
    if learner.has_sql_override(entity_key):
        info = learner.get_override_info(entity_key)
        return {
            "__sql_override__": True,
            "__sql__":          info["sql"],
            "mapeamento": f"✓ Mapeamento fixo local — {info.get('ts','')}",
        }

    # ── 3. Script Final salvo — escolhe o mais parecido com o schema atual ─
    if kb_data:
        all_scripts = kb_data.get("final_scripts_all", {})
        candidates  = all_scripts.get(entity_key, [])
        if candidates:
            # Se só tem um, usa direto; se tem vários, escolhe pelo score
            _sch = current_schema or schema
            if _sch:
                best = _best_script_for_schema(candidates, _sch)
            else:
                best = candidates[0]  # fallback: mais recente
            if best:
                _sch2 = current_schema or schema
                score = _score_script_vs_schema(best["sql"], _sch2) if _sch2 else 0
                sistema_info = best.get("sistema", "")
                return {
                    "__sql_override__": True,
                    "__sql__":          best["sql"],
                    "mapeamento": (
                        f"✓ Script Final salvo"
                        f"{' — ' + sistema_info if sistema_info else ''}"
                        f" [{best.get('tipo_banco','')}]"
                        f" (similaridade: {score})"
                    ),
                }

    # ── 4. Mapeamento Automático (heurística) ────────────────────────────────
    fn = {
        "cliente_fornecedor": _cli_forn,
        "produtos":           _produtos,
        "contas_pagar":       _pagar,
        "contas_receber":     _receber,
    }.get(entity_key)
    if not fn:
        raise ValueError(f"Entidade desconhecida: {entity_key}")
    return fn(schema, learner, kb)


def _learn_both(table: str, entity_key: str, learner, kb=None, db_type: str = ""):
    """Aprende a tabela no learner local. KB é só leitura neste contexto."""
    learner.learn_table(table, entity_key, 0.5)


def _cli_forn(schema, learner, kb=None):
    cli  = _best("tabela_cliente",    schema, learner, kb)
    forn = _best("tabela_fornecedor", schema, learner, kb, exclude=[cli])

    CLI = ["CodCliente","DataCadastro","nome","NomeFantasia","endereco","Complemento",
           "numero","bairro","cep","CodigoIBGE","NomeCompleto","UF","CodMunicipio",
           "CNPJ_CPF","InscricaoEstadual","rg","InscricaoMunicipal",
           "email","Email1","Email2","Telefone","Telefone2","Telefone3",
           "Celular","Celular2","Fax","LimiteCredito","VencimentoLimiteCredito",
           "DataNascimento","sexo","site",
           "Observacao","Observacao2","ObservacaoCliente"]

    cr, cj, cn = _resolve(cli,  "cl",   CLI,                  schema, learner, kb)
    fr, fj, fn2= _resolve(forn, "forn", CLI+["CodFornecedor"], schema, learner, kb)

    _learn_both(cli,  "cliente_fornecedor", learner, kb)
    _learn_both(forn, "cliente_fornecedor", learner, kb)

    m = {
        "TABELA_CLIENTE":    cli,  "ALIAS_CLIENTE":    "cl",
        "TABELA_FORNECEDOR": forn, "ALIAS_FORNECEDOR": "forn",
        "JOINS_CLIENTE":  "\n".join(cj), "JOINS_FORNECEDOR": "\n".join(fj),
        "WHERE_CLIENTE":  "",             "WHERE_FORNECEDOR": "",
        **{f"CampoCliente_{s}":    v for s, v in cr.items()},
        **{f"CampoFornecedor_{s}": v for s, v in fr.items()},
    }
    nf = cn + fn2
    m["mapeamento"] = (f"Clientes: {cli} | Fornecedores: {forn} | "
                       f"{len(cr)+len(fr)} campos"
                       + (f" | sem equiv: {nf}" if nf else ""))
    return m


def _produtos(schema, learner, kb=None):
    pd = _best("tabela_produto", schema, learner, kb)
    _learn_both(pd, "produtos", learner, kb)

    F = ["DataCadastro","CodProduto","nome","descricao","aplicacao",
         "CodUnidadeMedida","nomeUnidadeMedida","linha","familia","grupo",
         "marca","CodigoFabricante","CodigoDeBarras","CodigoFornecedor",
         "PesoBruto","PesoLiquido","MargemLucro","NCM","CEST","CodigoANP",
         "Ativo","Locacao","Sublocacao",
         "PrecoCompra","CustoCompra","CustoReposicao","CustoMedio","CustoInformado",
         "PrecoVenda","SaldoEstoque"]

    res, joins, nf = _resolve(pd, "pd", F, schema, learner, kb)
    m = {
        "TABELA_PRODUTO":  pd, "ALIAS_PRODUTO": "pd",
        "JOINS_PRODUTO":  "\n".join(joins), "WHERE_PRODUTO": "",
        **{f"CampoTabela_{s}": v for s, v in res.items()},
    }
    m["mapeamento"] = (f"Produto: {pd} | {len(res)} campos"
                       + (f" | sem equiv: {nf}" if nf else ""))
    return m


def _pagar(schema, learner, kb=None):
    pg = _best("tabela_pagar", schema, learner, kb)
    _learn_both(pg, "contas_pagar", learner, kb)

    F = ["codigo_fornecedor","titulo","parcela","Estabelecimento",
         "DataEmissao","DataVencimento",
         "Valor","ValorPago","DataPagamento","portador_codpagamento","Observacoes"]

    res, joins, nf = _resolve(pg, "pagar", F, schema, learner, kb)
    m = {
        "TABELA_PAGAR":  pg, "ALIAS_PAGAR": "pagar",
        "JOINS_PAGAR":  "\n".join(joins), "WHERE_PAGAR": "",
        **{f"CampoTabela_{s}": v for s, v in res.items()},
    }
    m["mapeamento"] = (f"Conta Pagar: {pg} | {len(res)} campos"
                       + (f" | sem equiv: {nf}" if nf else ""))
    return m


def _receber(schema, learner, kb=None):
    rc = _best("tabela_receber", schema, learner, kb)
    _learn_both(rc, "contas_receber", learner, kb)

    F = ["CodCliente_rec","Titulo","Parcela","DataEmissao","DataVencimento",
         "valor","desconto","ValorRecebido","valorMoraDiaria","ValorDaMulta",
         "DataRecebimento","NossoNumero","portador","taxaadiministrativa",
         "Observacao_rec","status"]

    res, joins, nf = _resolve(rc, "rc", F, schema, learner, kb)
    sc = _col(rc, "status", schema, learner, kb) or "Status"

    m = {
        "TABELA_RECEBER":  rc, "ALIAS_RECEBER": "rc",
        "JOINS_RECEBER":  "\n".join(joins),
        "WHERE_RECEBER": "", "AND_WHERE_RECEBER": "",
        "CAMPO_STATUS_RECEBER": sc, "VALOR_STATUS_ABERTO": "A",
        **{f"CampoTabela_{s}": v for s, v in res.items()},
        "CampoTabela_CodCliente": res.get(
            "CodCliente_rec", "/* NÃO_ENCONTRADO: CodCliente */"),
    }
    m["mapeamento"] = (f"Conta Receber: {rc} | {len(res)} campos"
                       + (f" | sem equiv: {nf}" if nf else ""))
    return m
