"""
Sistema de Aprendizado — v3
============================
Dois modos de operação:
  • LOCAL  : salva em data/learned_mappings.json  (sempre disponível)
  • SERVIDOR: sincroniza com o servidor central    (compartilhado pela equipe)

O que é aprendido:
  1. sql_overrides  : SQL COMPLETO corrigido (armazenado integralmente, sem parsear)
  2. table_hints    : nome_tabela → entidade (com peso acumulado)
  3. field_hints    : nome_campo  → semântico (com peso)
  4. join_patterns  : tabelaA ↔ tabelaB → condição JOIN
"""

from __future__ import annotations

import re
import json
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime

DATA_FILE = Path(__file__).parent.parent / "data" / "learned_mappings.json"
CFG_FILE  = Path(__file__).parent.parent / "data" / "server_config.json"

_DEFAULT: dict = {
    "version":       3,
    "sql_overrides": {},   # entity_key → {sql, ts, banco, client_tag}
    "table_hints":   {},   # norm_table → {entity_key: peso}
    "field_hints":   {},   # norm_field → {semantic: peso}
    "join_patterns": {},   # "tblA|tblB" → condição
    "history":       [],
}


def _n(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


# ─────────────────────────────────────────────────────────────────────────────

class MappingLearner:

    def __init__(self):
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        self._d    = self._load_local()
        self._cfg  = self._load_cfg()

    # ── Config do servidor ────────────────────────────────────────────────────

    def _load_cfg(self) -> dict:
        # Padrão pré-configurado com o servidor da empresa
        default = {
            "url":       "http://br2sql.moveresoftware.com:8765",
            "usuario":   "",
            "api_user":  "",
            "api_pass":  "",
            "auto_sync": False,
        }
        if CFG_FILE.exists():
            try:
                saved = json.loads(CFG_FILE.read_text(encoding="utf-8"))
                default.update(saved)
            except Exception:
                pass
        return default

    def save_cfg(self, url: str, usuario: str,
                 api_user: str, api_pass: str, auto_sync: bool):
        cfg = {
            "url":       url.rstrip("/"),
            "usuario":   usuario,
            "api_user":  api_user,
            "api_pass":  api_pass,
            "auto_sync": auto_sync,
        }
        CFG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        self._cfg = cfg

    @property
    def server_url(self) -> str:
        return self._cfg.get("url", "")

    @property
    def usuario(self) -> str:
        return self._cfg.get("usuario", "anonimo")

    @property
    def api_user(self) -> str:
        return self._cfg.get("api_user", "")

    @property
    def api_pass(self) -> str:
        return self._cfg.get("api_pass", "")

    @property
    def auto_sync(self) -> bool:
        return self._cfg.get("auto_sync", False)

    def _auth_header(self) -> dict:
        """Monta header Authorization Basic se credenciais configuradas."""
        if self.api_user and self.api_pass:
            import base64
            token = base64.b64encode(
                f"{self.api_user}:{self.api_pass}".encode()
            ).decode()
            return {"Authorization": f"Basic {token}"}
        return {}

    def server_connected(self) -> bool:
        if not self.server_url:
            return False
        try:
            headers = {"Content-Type": "application/json"}
            headers.update(self._auth_header())
            req = urllib.request.Request(
                f"{self.server_url}/", headers=headers)
            with urllib.request.urlopen(req, timeout=4) as r:
                return r.status == 200
        except Exception:
            return False

    # ── I/O local ────────────────────────────────────────────────────────────

    def _load_local(self) -> dict:
        if DATA_FILE.exists():
            try:
                d = json.loads(DATA_FILE.read_text(encoding="utf-8"))
                for k, v in _DEFAULT.items():
                    d.setdefault(k, v)
                return d
            except Exception:
                pass
        return dict(_DEFAULT)

    def _save_local(self):
        DATA_FILE.write_text(
            json.dumps(self._d, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # ── SQL Override (abordagem principal) ────────────────────────────────────

    def set_sql_override(self, entity_key: str, sql: str,
                         db_type: str = "", client_tag: str = ""):
        """
        Armazena o SQL COMPLETO como override.
        É o método mais confiável — preserva subqueries, CTEs, qualquer estrutura.
        """
        entry = {
            "sql":        sql,
            "ts":         datetime.now().isoformat(timespec="seconds"),
            "banco":      db_type,
            "client_tag": client_tag,
            "usuario":    self.usuario,
        }
        self._d["sql_overrides"][entity_key] = entry

        # Histórico
        self._d["history"].append({
            "ts":      entry["ts"],
            "entity":  entity_key,
            "action":  "sql_override",
            "banco":   db_type,
            "usuario": self.usuario,
            "tag":     client_tag,
        })
        self._d["history"] = self._d["history"][-200:]
        self._save_local()

        # Sincroniza com servidor se configurado
        if self.auto_sync and self.server_url:
            self._push_override(entity_key, sql, db_type, client_tag)

    def get_sql_override(self, entity_key: str) -> str | None:
        entry = self._d["sql_overrides"].get(entity_key)
        return entry["sql"] if entry else None

    def has_sql_override(self, entity_key: str) -> bool:
        return entity_key in self._d["sql_overrides"]

    def get_override_info(self, entity_key: str) -> dict | None:
        return self._d["sql_overrides"].get(entity_key)

    def delete_sql_override(self, entity_key: str):
        self._d["sql_overrides"].pop(entity_key, None)
        self._save_local()

    # ── Table hints ───────────────────────────────────────────────────────────

    def learn_table(self, table_name: str, entity_key: str,
                    weight: float = 1.0, db_type: str = ""):
        key = _n(table_name)
        th  = self._d["table_hints"]
        th.setdefault(key, {"_orig": table_name})
        th[key][entity_key] = th[key].get(entity_key, 0.0) + weight
        self._save_local()

        if self.auto_sync and self.server_url:
            self._post_json("/learn/table", {
                "table_name": table_name, "entity_key": entity_key,
                "db_type": db_type, "weight": weight, "usuario": self.usuario,
            })

    def table_hint_score(self, table_name: str, entity_key: str) -> float:
        return self._d["table_hints"].get(_n(table_name), {}).get(entity_key, 0.0)

    # ── Field hints ───────────────────────────────────────────────────────────

    def learn_field(self, field_name: str, semantic: str,
                    weight: float = 1.0, db_type: str = ""):
        key = _n(field_name)
        fh  = self._d["field_hints"]
        fh.setdefault(key, {"_orig": field_name})
        fh[key][semantic] = fh[key].get(semantic, 0.0) + weight
        self._save_local()

    def field_boost(self, field_name: str, semantic: str) -> float:
        return self._d["field_hints"].get(_n(field_name), {}).get(semantic, 0.0)

    def best_field_match(self, field_name: str) -> str | None:
        scores = {k: v for k, v in
                  self._d["field_hints"].get(_n(field_name), {}).items()
                  if not k.startswith("_") and isinstance(v, float)}
        if not scores:
            return None
        return max(scores, key=scores.get)

    # ── Join patterns ─────────────────────────────────────────────────────────

    def learn_join(self, table_a: str, table_b: str, condition: str,
                   db_type: str = ""):
        na, nb = _n(table_a), _n(table_b)
        key = f"{na}|{nb}" if na < nb else f"{nb}|{na}"
        self._d["join_patterns"][key] = condition
        self._save_local()

        if self.auto_sync and self.server_url:
            self._post_json("/learn/join", {
                "table_a": table_a, "table_b": table_b,
                "condition": condition, "db_type": db_type, "usuario": self.usuario,
            })

    def known_join(self, table_a: str, table_b: str) -> str | None:
        na, nb = _n(table_a), _n(table_b)
        k1 = f"{na}|{nb}"; k2 = f"{nb}|{na}"
        return (self._d["join_patterns"].get(k1)
             or self._d["join_patterns"].get(k2))

    # ── Sincronização com servidor ────────────────────────────────────────────

    def sync_push(self) -> dict:
        """Envia todo o conhecimento local para o servidor."""
        if not self.server_url:
            return {"ok": False, "erro": "Servidor não configurado"}

        payload = {
            "table_hints":   [],
            "field_hints":   [],
            "join_patterns": [],
            "sql_overrides": [],
            "usuario":       self.usuario,
        }

        # Table hints
        for norm, scores in self._d["table_hints"].items():
            orig = scores.get("_orig", norm)
            for ent, w in scores.items():
                if not ent.startswith("_") and isinstance(w, float):
                    payload["table_hints"].append(
                        {"table_name": orig, "entity_key": ent,
                         "weight": w, "db_type": "", "usuario": self.usuario})

        # Field hints
        for norm, scores in self._d["field_hints"].items():
            orig = scores.get("_orig", norm)
            for sem, w in scores.items():
                if not sem.startswith("_") and isinstance(w, float):
                    payload["field_hints"].append(
                        {"field_name": orig, "semantic": sem,
                         "weight": w, "db_type": "", "usuario": self.usuario})

        # Join patterns
        for key, cond in self._d["join_patterns"].items():
            parts = key.split("|")
            if len(parts) == 2:
                payload["join_patterns"].append(
                    {"table_a": parts[0], "table_b": parts[1],
                     "condition": cond, "db_type": "", "usuario": self.usuario})

        # SQL overrides
        for ent, entry in self._d["sql_overrides"].items():
            payload["sql_overrides"].append({
                "entity_key": ent,
                "sql_text":   entry["sql"],
                "db_type":    entry.get("banco", ""),
                "client_tag": entry.get("client_tag", ""),
                "usuario":    self.usuario,
            })

        result = self._post_json("/sync/push", payload)
        return result or {"ok": False, "erro": "Sem resposta do servidor"}

    def sync_pull(self) -> dict:
        """Baixa todo o conhecimento do servidor e funde com o local."""
        if not self.server_url:
            return {"ok": False, "erro": "Servidor não configurado"}

        data = self._get_json("/sync/pull")
        if not data:
            return {"ok": False, "erro": "Falha ao baixar dados"}

        counts = {"table_hints": 0, "field_hints": 0,
                  "join_patterns": 0, "sql_overrides": 0}

        # Funde table hints (soma pesos)
        for row in data.get("table_hints", []):
            key = _n(row["table_orig"])
            th  = self._d["table_hints"]
            th.setdefault(key, {"_orig": row["table_orig"]})
            cur = th[key].get(row["entity_key"], 0.0)
            if row["weight"] > cur:
                th[key][row["entity_key"]] = row["weight"]
            counts["table_hints"] += 1

        # Funde field hints
        for row in data.get("field_hints", []):
            key = _n(row["field_orig"])
            fh  = self._d["field_hints"]
            fh.setdefault(key, {"_orig": row["field_orig"]})
            cur = fh[key].get(row["semantic"], 0.0)
            if row["weight"] > cur:
                fh[key][row["semantic"]] = row["weight"]
            counts["field_hints"] += 1

        # Funde join patterns (servidor tem prioridade)
        for row in data.get("join_patterns", []):
            key = f"{row['table_a']}|{row['table_b']}"
            self._d["join_patterns"][key] = row["condition"]
            counts["join_patterns"] += 1

        # SQL overrides: apenas adiciona novos (não sobrescreve locais)
        for row in data.get("sql_overrides", []):
            ent = row["entity_key"]
            if ent not in self._d["sql_overrides"]:
                self._d["sql_overrides"][ent] = {
                    "sql":        row["sql_text"],
                    "ts":         row.get("ts", ""),
                    "banco":      row.get("db_type", ""),
                    "client_tag": row.get("client_tag", ""),
                    "usuario":    row.get("usuario", ""),
                }
                counts["sql_overrides"] += 1

        self._save_local()
        return {"ok": True, "baixado": counts}

    def get_server_overrides(self, entity_key: str) -> list[dict]:
        """Busca overrides de outros clientes no servidor (para referência)."""
        if not self.server_url:
            return []
        data = self._get_json(f"/learn/override?entity_key={entity_key}")
        return data if isinstance(data, list) else []

    # ── Helpers HTTP ──────────────────────────────────────────────────────────

    def _post_json(self, path: str, payload: dict) -> dict | None:
        try:
            body    = json.dumps(payload).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            headers.update(self._auth_header())
            req = urllib.request.Request(
                f"{self.server_url}{path}",
                data=body, headers=headers, method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except Exception:
            return None

    def _get_json(self, path: str) -> dict | list | None:
        try:
            headers = {"Content-Type": "application/json"}
            headers.update(self._auth_header())
            req = urllib.request.Request(
                f"{self.server_url}{path}", headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read())
        except Exception:
            return None

    # ── Estatísticas ──────────────────────────────────────────────────────────

    def summary(self) -> dict:
        ovr = self._d["sql_overrides"]
        return {
            "overrides_locais":    list(ovr.keys()),
            "tabelas_aprendidas":  len(self._d["table_hints"]),
            "campos_aprendidos":   len(self._d["field_hints"]),
            "joins_aprendidos":    len(self._d["join_patterns"]),
            "correcoes":           len(self._d["history"]),
            "servidor_url":        self.server_url,
            "usuario":             self.usuario,
            "auto_sync":           self.auto_sync,
            "ultima_atualizacao": (self._d["history"][-1]["ts"]
                                   if self._d["history"] else "—"),
        }

    def get_history(self) -> list:
        return list(reversed(self._d["history"]))

    def clear_all(self):
        self._d = dict(_DEFAULT)
        self._save_local()


# ── Singleton ──────────────────────────────────────────────────────────────────

_learner: MappingLearner | None = None

def get_learner() -> MappingLearner:
    global _learner
    if _learner is None:
        _learner = MappingLearner()
    return _learner
