"""
Analisador de SQL — extrai conhecimento real dos scripts corrigidos e finais.

O que ele aprende de cada SQL salvo:
  1. Tabela principal (FROM) → qual entidade ela representa
  2. Campos usados (alias.campo AS destino) → qual semântico cada campo representa
  3. JOINs (LEFT JOIN tbl ON cond) → como tabelas se relacionam
  4. Aliases de tabela → resolve "cl.NM_CLI" para "tabela_cliente.NM_CLI"

Quanto maior o peso salvo, mais confiante o sistema fica naquela associação.
Cada script analisado acumula +2.0 de peso por acerto confirmado.
Após 5 scripts com o mesmo mapeamento, ele vira praticamente certeza.

Compatível com qualquer banco (SQL Server, Firebird, MySQL, PostgreSQL)
porque analisa texto SQL, não conecta ao banco.
"""

from __future__ import annotations

import re
from datetime import datetime


def _n(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


# ─── Mapeamento: alias de destino → chave semântica ───────────────────────────
# Cobre os aliases AS usados nos templates de todas as 4 entidades.
# Quanto mais genérico o destino, mais entidades ele cobre.

_DEST_TO_SEMANTIC: dict[str, str] = {
    # Identificadores
    "datacadastro":                "DataCadastro",
    "nome":                        "nome",
    "nomefantasia":                "NomeFantasia",
    # Endereço
    "endereco":                    "endereco",
    "numerologradouro":            "numero",
    "bairro":                      "bairro",
    "cep":                         "cep",
    "codigoibgedacidade":          "CodigoIBGE",
    "nomedacidade":                "NomeCompleto",
    "ufdacidade":                  "UF",
    # Documentos
    "cpfoucnpj":                   "CNPJ_CPF",
    "inscricaoestadualourg":       "InscricaoEstadual",
    "inscricaomunicipal":          "InscricaoMunicipal",
    # Contato
    "emailprincipal":              "email",
    "telefonecomercial":           "Telefone",
    "telefonecelular":             "Celular",
    "telefonefax":                 "Fax",
    # Crédito
    "valordolimitedecredito":      "LimiteCredito",
    "valorodolimitedecredito":     "LimiteCredito",
    "datavencimentocredito":       "VencimentoLimiteCredito",
    # Identificadores de entidade
    "codigoclienteimportado":      "CodCliente",
    "codigoimportadodofornecedor": "CodFornecedor",
    "observacaodecobranca":        "Observacao",
    # Produto
    "codigodoitemimportado":       "CodProduto",
    "codigodoitem":                "CodProduto",
    "nomedoitem":                  "nome",
    "aplicacao":                   "aplicacao",
    "unidadedemedida":             "CodUnidadeMedida",
    "embalagemdevenda":            "nomeUnidadeMedida",
    "linhadeitens":                "linha",
    "familiadeitens":              "familia",
    "grupodeitens":                "grupo",
    "codigodefabricacao":          "CodigoFabricante",
    "marcadeitens":                "marca",
    "percentualmargemlucro":       "MargemLucro",
    "codigoncmsh":                 "NCM",
    "codigocest":                  "CEST",
    "codigoanp":                   "CodigoANP",
    "ativo":                       "Ativo",
    "precocompra":                 "CustoCompra",
    "custocompra":                 "CustoCompra",
    "custoreposicao":              "CustoCompra",
    "customedio":                  "CustoMedioPonderado",
    "custoinformado":              "CustoCompra",
    "precovenda":                  "PrecoVenda",
    "saldoestoque":                "SaldoAtual",
    # Financeiro pagar
    "documento":                   "titulo",
    "numeroparcela":               "parcela",
    "datadadigitacao":             "DataEmissao",
    "datadaemissao":               "DataEmissao",
    "datadovencimento":            "DataVencimento",
    "valordodocumento":            "Valor",
    "valordoabatimento":           "ValorPago",
    "datadoabatimento":            "DataPagamento",
    "nomedoportador":              "portador_codpagamento",
    # Financeiro receber
    "codigodoclienteimportado":    "CodCliente_rec",
    "numerodaparcela":             "Parcela",
    "datadeemissao":               "DataEmissao",
    "datadevenncimento":           "DataVencimento",
    "valordamoradiaria":           "valorMoraDiaria",
    "valordamulta":                "ValorDaMulta",
    "nossonumero":                 "NossoNumero",
    "observacoes":                 "Observacao_rec",
    # ── Novos campos adicionados no template ─────────────────────────────
    "datanascimento":              "DataNascimento",
    "sexo":                        "sexo",
    "site":                        "site",
    "descricaodetalhada":          "descricao",
    "pesobruto":                   "PesoBruto",
    "pesoliquido":                 "PesoLiquido",
    "codigodebarras":              "CodigoDeBarras",
    "codigoimportadodofornecedor": "CodigoFornecedor",
    "precocompra":                 "PrecoCompra",
    "custoreposicao":              "CustoReposicao",
    "customedio":                  "CustoMedio",
    "custoinformado":              "CustoInformado",
    "saldoestoque":                "SaldoEstoque",
    "locacao":                     "Locacao",
    "sublocacao":                  "Sublocacao",
    "estabelecimento":             "Estabelecimento",
    "observacoesdodocumento":      "Observacoes",
    "valordodesconto":             "desconto",
    "taxaadministracaofinanceira": "taxaadiministrativa",
}

# Entidade → quais tabela_rule_keys correspondem
_ENTITY_TO_RULES: dict[str, list[str]] = {
    "cliente_fornecedor": ["tabela_cliente", "tabela_fornecedor"],
    "produtos":           ["tabela_produto"],
    "contas_pagar":       ["tabela_pagar"],
    "contas_receber":     ["tabela_receber"],
}


class SQLAnalyzer:
    """
    Analisa um SQL e extrai conhecimento estruturado.
    Resultado salvo com peso 2.0 por ser confirmado por humano.
    """

    LEARN_WEIGHT = 2.0   # peso por campo aprendido de script corrigido
    FINAL_WEIGHT = 1.5   # peso menor para scripts finais (não necessariamente o mapper ideal)

    def analyze_and_learn(self, sql: str, entity_key: str,
                          db_type: str = "", weight: float = None,
                          accumulate: bool = True) -> dict:
        """
        Analisa o SQL e salva tudo que aprender no KB e no learner.
        Retorna dict com resumo do que foi extraído.
        """
        if weight is None:
            weight = self.LEARN_WEIGHT

        result = {
            "tables":  [],   # (table_name, entity_key)
            "fields":  [],   # (field_name, semantic_key)
            "joins":   [],   # (table_a, table_b, condition)
            "skipped": [],
        }

        try:
            from core.kb_connection import get_kb
            from core.learner       import get_learner
            kb      = get_kb()
            learner = get_learner()
        except Exception:
            return result

        # ── Extrai alias_map: {alias_lower: table_name} ──────────────────────
        alias_map = self._extract_alias_map(sql)

        # ── Aprende tabelas ───────────────────────────────────────────────────
        rules = _ENTITY_TO_RULES.get(entity_key, [])
        for alias, table in alias_map.items():
            # A tabela principal (primeiro FROM) tem peso maior
            is_main = alias in self._main_aliases(sql)
            w = weight * (1.5 if is_main else 0.8)

            # Associa à entidade correta
            for rule in rules:
                kb.save_table_hint(table, entity_key, db_type, w, accumulate=accumulate)
                learner.learn_table(table, entity_key, w)
                result["tables"].append((table, entity_key))

        # ── Aprende campos ────────────────────────────────────────────────────
        select_block = self._get_select_block(sql)
        # Remove blocos CASE...END para evitar capturar END como campo
        select_clean = re.sub(
            r"\bCASE\b.+?\bEND\b", "__CASE_EXPR__",
            select_block, flags=re.IGNORECASE | re.DOTALL
        )
        # Reintroduz o AS destino do CASE (ex: END AS CodigoClienteImportado)
        # capturando apenas o alias final de cada CASE
        case_aliases = re.findall(
            r"\bEND\b\s+AS\s+(\w+)", select_block, re.IGNORECASE
        )
        # Adiciona aliases do CASE ao select_clean como colunas fictícias
        for ca in case_aliases:
            select_clean += f" __CASE__ AS {ca}"

        for field_match in re.finditer(
            r"(?:(\w+)\.)?(\w+)\s+AS\s+(\w+)",
            select_clean, re.IGNORECASE
        ):
            alias     = (field_match.group(1) or "").lower()
            field_col = field_match.group(2)
            dest_name = field_match.group(3)
            # Pula marcadores internos
            if field_col.startswith("__"):
                field_col = None

            # Ignora palavras-chave SQL e constantes
            SQL_KEYWORDS = {
                "END","THEN","ELSE","WHEN","CASE","NULL","TRUE","FALSE",
                "TM","REVENDA","PADRÃO","PADRAO","M","A","P","F","C","S","N",
                "SELECT","FROM","WHERE","AND","OR","NOT","IN","IS","AS",
                "LEFT","RIGHT","INNER","JOIN","ON","BY","ORDER","GROUP",
                "HAVING","UNION","ALL","DISTINCT","TOP","SET","INTO",
                "CURRENT_TIMESTAMP","GETDATE","NOW","COALESCE","ISNULL",
            }
            if not field_col:  # CASE WHEN — usa só o destino
                semantic = _DEST_TO_SEMANTIC.get(_n(dest_name))
                if semantic:
                    result["fields"].append((f"<CASE AS {dest_name}>", semantic))
                continue
            # Ignora palavras-chave SQL e constantes
            SQL_KEYWORDS = {
                "END","THEN","ELSE","WHEN","CASE","NULL","TRUE","FALSE",
                "TM","REVENDA","PADRÃO","PADRAO","M","A","P","F","C","S","N",
                "SELECT","FROM","WHERE","AND","OR","NOT","IN","IS","AS",
                "LEFT","RIGHT","INNER","JOIN","ON","BY","ORDER","GROUP",
                "HAVING","UNION","ALL","DISTINCT","TOP","SET","INTO",
                "CURRENT_TIMESTAMP","GETDATE","NOW","COALESCE","ISNULL",
            }
            if field_col.upper() in SQL_KEYWORDS:
                continue
            if re.match(r"^\d+$", field_col):
                continue
            if "(" in field_col or ")" in field_col:
                continue
            # Descobre o semântico pelo nome de destino
            semantic = _DEST_TO_SEMANTIC.get(_n(dest_name))
            if not semantic:
                # Busca parcial
                for k, v in _DEST_TO_SEMANTIC.items():
                    if k in _n(dest_name) or _n(dest_name) in k:
                        semantic = v
                        break

            if semantic:
                kb.save_field_hint(field_col, semantic, db_type, weight, accumulate=accumulate)
                learner.learn_field(field_col, semantic, weight)
                result["fields"].append((field_col, semantic))
            else:
                result["skipped"].append(f"{field_col} AS {dest_name}")

        # ── Aprende JOINs ─────────────────────────────────────────────────────
        for jm in re.finditer(
            r"(?:LEFT|RIGHT|INNER|FULL|CROSS)?\s*JOIN\s+(\w+)\s+(\w+)?\s+ON\s+([^\n]+)",
            sql, re.IGNORECASE
        ):
            join_table = jm.group(1)
            join_alias = (jm.group(2) or jm.group(1)[:2]).lower()
            condition  = jm.group(3).strip()

            # Descobre a tabela principal (FROM)
            main_table = self._main_table(sql)
            if main_table and join_table:
                kb.save_join_pattern(main_table, join_table, condition, db_type)
                learner.learn_join(main_table, join_table, condition)
                result["joins"].append((main_table, join_table, condition))

        # ── Para UNION ALL (cliente+fornecedor): analisa o segundo bloco ─────
        if "UNION ALL" in sql.upper() and entity_key == "cliente_fornecedor":
            parts = re.split(r"UNION\s+ALL", sql, flags=re.IGNORECASE)
            if len(parts) >= 2:
                # Segundo bloco = fornecedores
                second = parts[1]
                forn_table = self._main_table(second)
                if forn_table:
                    kb.save_table_hint(forn_table, entity_key, db_type, weight * 0.9, accumulate=accumulate)
                    learner.learn_table(forn_table, entity_key, weight * 0.9)
                    if (forn_table, entity_key) not in result["tables"]:
                        result["tables"].append((forn_table, entity_key))

        return result

    # ── Helpers de parsing ────────────────────────────────────────────────────

    def _extract_alias_map(self, sql: str) -> dict[str, str]:
        """Extrai {alias: nome_real_tabela} de FROM e JOINs."""
        alias_map: dict[str, str] = {}

        # FROM tabela alias  ou  FROM tabela
        for m in re.finditer(
            r"\bFROM\s+(\w+)(?:\s+(\w+))?",
            sql, re.IGNORECASE
        ):
            tbl   = m.group(1)
            alias = (m.group(2) or tbl[:2]).lower()
            if alias.upper() not in ("WHERE","ON","JOIN","SET","LEFT","RIGHT","INNER"):
                alias_map[alias] = tbl

        # JOINs
        for m in re.finditer(
            r"\bJOIN\s+(\w+)(?:\s+(\w+))?\s+ON",
            sql, re.IGNORECASE
        ):
            tbl   = m.group(1)
            alias = (m.group(2) or tbl[:2]).lower()
            alias_map[alias] = tbl

        # Subqueries: FROM ( SELECT ... ) alias
        for m in re.finditer(r"\)\s+(\w+)\s+ON\b", sql, re.IGNORECASE):
            alias = m.group(1).lower()
            alias_map[alias] = f"<subquery:{alias}>"

        return alias_map

    def _main_aliases(self, sql: str) -> set[str]:
        """Retorna os aliases da primeira cláusula FROM (antes do UNION ALL)."""
        first_block = re.split(r"UNION\s+ALL", sql, flags=re.IGNORECASE)[0]
        aliases: set[str] = set()
        m = re.search(r"\bFROM\s+(\w+)(?:\s+(\w+))?", first_block, re.IGNORECASE)
        if m:
            aliases.add((m.group(2) or m.group(1)[:2]).lower())
        return aliases

    def _main_table(self, sql: str) -> str | None:
        """Retorna o nome da tabela no FROM principal."""
        m = re.search(r"\bFROM\s+(\w+)", sql, re.IGNORECASE)
        return m.group(1) if m else None

    def _get_select_block(self, sql: str) -> str:
        """Extrai o bloco entre SELECT e FROM."""
        # Pega apenas o primeiro bloco (antes de UNION ALL)
        first = re.split(r"UNION\s+ALL", sql, flags=re.IGNORECASE)[0]
        m = re.search(r"\bSELECT\b(.+?)\bFROM\b",
                      first, re.IGNORECASE | re.DOTALL)
        return m.group(1) if m else first


# ── Singleton ──────────────────────────────────────────────────────────────────

_analyzer: SQLAnalyzer | None = None

def get_analyzer() -> SQLAnalyzer:
    global _analyzer
    if _analyzer is None:
        _analyzer = SQLAnalyzer()
    return _analyzer


def learn_from_sql(sql: str, entity_key: str,
                   db_type: str = "",
                   weight: float = None) -> dict:
    """Atalho para chamar de qualquer lugar."""
    return get_analyzer().analyze_and_learn(sql, entity_key, db_type, weight)


def reprocess_all_saved() -> dict:
    """
    Reprocessa TODOS os SQLs já salvos no banco (overrides + scripts finais)
    e reaplica o aprendizado.
    Útil para enriquecer a base quando o sistema é atualizado.
    """
    try:
        from core.kb_connection import make_thread_connection, get_kb, TABLE_NAMES as _TN
        # Tenta conexão de thread; se falhar, usa None (só learner local)
        thread_conn = make_thread_connection()
        if not thread_conn:
            return {"ok": False, "erro": "Sem conexão com o banco central"}
    except Exception as e:
        return {"ok": False, "erro": str(e)}

    analyzer = get_analyzer()
    counts   = {"overrides": 0, "final_scripts": 0, "fields": 0,
                "tables": 0, "joins": 0}

    # ── Overrides ─────────────────────────────────────────────────────────────
    try:
        cur = thread_conn.cursor()
    except Exception as e:
        return {"ok": False, "erro": f"Erro ao criar cursor: {e}"}
    cur.execute(
        f"SELECT entity_key, sql_text, db_type FROM {_TN['sql_overrides']}"
    )
    for row in cur.fetchall():
        entity_key, sql, db_type = row[0], row[1], (row[2] or "")
        result = analyzer.analyze_and_learn(
            sql, entity_key, db_type,
            weight=SQLAnalyzer.LEARN_WEIGHT,
            accumulate=False
        )
        counts["overrides"]    += 1
        counts["tables"]       += len(result["tables"])
        counts["fields"]       += len(result["fields"])
        counts["joins"]        += len(result["joins"])

    # ── Scripts finais ────────────────────────────────────────────────────────
    cur.execute(
        f"SELECT tipo_script, sql_text, tipo_banco "
        f"FROM {_TN['final_scripts']}"
    )
    _tipo_to_entity = {
        "Clientes / Fornecedores": "cliente_fornecedor",
        "Produtos":                "produtos",
        "Contas a Pagar":          "contas_pagar",
        "Contas a Receber":        "contas_receber",
    }
    for row in cur.fetchall():
        tipo_script, sql, db_type = row[0], row[1], (row[2] or "")
        entity_key = _tipo_to_entity.get(tipo_script, "")
        if not entity_key:
            continue
        result = analyzer.analyze_and_learn(
            sql, entity_key, db_type,
            weight=SQLAnalyzer.FINAL_WEIGHT,
            accumulate=False
        )
        counts["final_scripts"] += 1
        counts["tables"]        += len(result["tables"])
        counts["fields"]        += len(result["fields"])
        counts["joins"]         += len(result["joins"])

    return {"ok": True, "contagens": counts}
