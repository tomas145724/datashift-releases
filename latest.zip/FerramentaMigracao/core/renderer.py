"""
Renderer v3
===========
Se o mapper sinalizar __sql_override__, devolve o SQL armazenado diretamente.
Caso contrário, substitui placeholders e adapta a sintaxe por banco.

Correção SQL Server: evita erro "O sistema não pode encontrar o caminho especificado"
causado pelo PATH do Python não encontrar o driver ODBC — o renderer não tem impacto
nisto, mas o connector agora trata esse erro de forma mais clara.
"""

from __future__ import annotations
import re
from datetime import datetime
from templates.sql_templates import TEMPLATES


def render_sql(entity_key: str, mapping: dict, db_type: str) -> str:

    # ── Override: devolve o SQL salvo diretamente ──────────────────────────
    if mapping.get("__sql_override__"):
        sql = mapping["__sql__"]
        header = (
            f"-- ══════════════════════════════════════════════════════\n"
            f"--  {TEMPLATES[entity_key]['nome'].upper()}  —  SQL OVERRIDE SALVO\n"
            f"--  {mapping.get('mapeamento','')}\n"
            f"--  Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            f"-- ══════════════════════════════════════════════════════\n\n"
        )
        return header + sql

    # ── Geração via template ───────────────────────────────────────────────
    tpl = TEMPLATES[entity_key]["sql"]
    m   = dict(mapping)
    m["data"]  = datetime.now().strftime("%d/%m/%Y %H:%M")
    m["banco"] = db_type

    sql = tpl
    for k, v in m.items():
        sql = sql.replace("{" + k + "}", str(v))

    # Substitui prefixos CampoXxx_ que ainda restarem
    for k, v in m.items():
        for prefix in ("CampoTabela_", "CampoCliente_", "CampoFornecedor_"):
            if k.startswith(prefix):
                sql = sql.replace(k, str(v))

    # Remove placeholders não preenchidos
    sql = re.sub(r"\{JOINS_\w+\}",     "", sql)
    sql = re.sub(r"\{WHERE_\w+\}",     "", sql)
    sql = re.sub(r"\{AND_WHERE_\w+\}", "", sql)
    sql = re.sub(r"\{ALIAS_\w+\}",     "", sql)
    sql = re.sub(r"\n{3,}",            "\n\n", sql)

    sql = _adapt(sql, db_type)
    return sql.strip()


# ─── Adaptações de sintaxe ────────────────────────────────────────────────────

def _adapt(sql: str, db_type: str) -> str:
    if "Firebird" in db_type: return _firebird(sql)
    if "MySQL"    in db_type: return _mysql(sql)
    if "PostgreSQL" in db_type: return _postgresql(sql)
    return sql  # SQL Server → sintaxe nativa


def _firebird(sql: str) -> str:
    sql = re.sub(r"\bisnull\s*\(",        "COALESCE(",         sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bgetdate\s*\(\s*\)",  "CURRENT_TIMESTAMP", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\btry_cast\s*\(",      "CAST(",             sql, flags=re.IGNORECASE)
    sql = re.sub(r"\blen\s*\(",           "CHAR_LENGTH(",       sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bSUBSTRING\s*\(\s*([^,]+),\s*(\d+),\s*(\d+)\s*\)",
        r"SUBSTRING(\1 FROM \2 FOR \3)", sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bCHARINDEX\s*\(\s*([^,]+),\s*([^)]+)\)",
        r"POSITION(\1 IN \2)", sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bdateadd\s*\(\s*day\s*,\s*(\d+)\s*,\s*([^)]+)\)",
        r"DATEADD(\1 DAY TO \2)", sql, flags=re.IGNORECASE)

    def _fix_concat(m):
        parts, d, cur = [], 0, []
        for ch in m.group(1):
            if ch == '(':   d += 1; cur.append(ch)
            elif ch == ')': d -= 1; cur.append(ch)
            elif ch == ',' and d == 0: parts.append(''.join(cur).strip()); cur = []
            else: cur.append(ch)
        if cur: parts.append(''.join(cur).strip())
        return " || ".join(parts)
    sql = re.sub(r"\bCONCAT\s*\(([^;]+?)\)", _fix_concat, sql, flags=re.IGNORECASE)
    sql = sql.replace("NOT LIKE '%[^0-9]%'", "NOT SIMILAR TO '%[^0-9]%'")
    return sql


def _mysql(sql: str) -> str:
    sql = re.sub(r"\bisnull\s*\(",        "COALESCE(", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bgetdate\s*\(\s*\)",  "NOW()",     sql, flags=re.IGNORECASE)
    sql = re.sub(r"\btry_cast\s*\(",      "CAST(",     sql, flags=re.IGNORECASE)
    sql = re.sub(r"\blen\s*\(",           "LENGTH(",   sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bdateadd\s*\(\s*day\s*,\s*(\d+)\s*,\s*([^)]+)\)",
        r"DATE_ADD(\2, INTERVAL \1 DAY)", sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bCHARINDEX\s*\(\s*([^,]+),\s*([^)]+)\)",
        r"LOCATE(\1, \2)", sql, flags=re.IGNORECASE)
    sql = sql.replace("NOT LIKE '%[^0-9]%'", "NOT REGEXP '^[0-9]+$'")
    return sql


def _postgresql(sql: str) -> str:
    sql = re.sub(r"\bisnull\s*\(",        "COALESCE(", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\bgetdate\s*\(\s*\)",  "NOW()",     sql, flags=re.IGNORECASE)
    sql = re.sub(r"\btry_cast\s*\(",      "CAST(",     sql, flags=re.IGNORECASE)
    sql = re.sub(r"\blen\s*\(",           "LENGTH(",   sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bdateadd\s*\(\s*day\s*,\s*(\d+)\s*,\s*([^)]+)\)",
        r"(\2 + INTERVAL '\1 days')", sql, flags=re.IGNORECASE)
    sql = re.sub(
        r"\bCHARINDEX\s*\(\s*([^,]+),\s*([^)]+)\)",
        r"POSITION(\1 IN \2)", sql, flags=re.IGNORECASE)
    sql = sql.replace("NOT LIKE '%[^0-9]%'", "NOT SIMILAR TO '%[0-9]+'")
    return sql
