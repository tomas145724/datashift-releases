"""
╔══════════════════════════════════════════════════════════════════════════╗
║  TEMPLATES SQL DE MIGRAÇÃO                                 ║
║                                                                          ║
║  Regras de placeholder:                                                  ║
║   {TABELA_xxx}       → nome real da tabela (resolvido pelo mapper)       ║
║   {ALIAS_xxx}        → apelido da tabela no SELECT                      ║
║   {JOINS_xxx}        → LEFT JOINs gerados automaticamente               ║
║   {WHERE_xxx}        → cláusula WHERE opcional                          ║
║   CampoTabela_xxx    → campo real resolvido pelo mapper                  ║
║   CampoCliente_xxx   → campo específico da tabela de clientes            ║
║   CampoFornecedor_xxx→ campo específico da tabela de fornecedores        ║
╚══════════════════════════════════════════════════════════════════════════╝

Como editar:
  • Para mudar um campo fixo (flag, conta contábil) basta alterar o valor aqui.
  • Para adicionar uma nova coluna de destino, inclua-a com o alias correto.
  • Não altere os nomes {TABELA_xxx} nem CampoTabela_xxx — eles são resolvidos
    automaticamente contra o schema do banco do cliente.

4 lugares para alterar ao adicionar um campo novo:
    *templates/sql_templates.py Adiciona  ---- {CampoCliente_site} AS Site, no SELECT
    *core/mapper.py → FIELD_HINTS ---- Adiciona os sinônimos do campo: "site": ["ds_site", "url", ...]
    *core/mapper.py → _cli_forn() ---- Adiciona "site" na lista CLI = [...]
    *core/sql_analyzer.py → _DEST_TO_SEMANTIC ---- Adiciona "site": "site" para o reaprendizado reconhecer

"""
# ─────────────────────────────────────────────────────────────────────────────
#  METADADOS
# ─────────────────────────────────────────────────────────────────────────────

ENTITY_META = {
    "cliente_fornecedor": {"nome": "Clientes / Fornecedores", "cor": "#1a73e8", "ordem": 1},
    "produtos":           {"nome": "Produtos",                "cor": "#f59e0b", "ordem": 2},
    "contas_pagar":       {"nome": "Contas a Pagar",          "cor": "#ef4444", "ordem": 3},
    "contas_receber":     {"nome": "Contas a Receber",        "cor": "#10b981", "ordem": 4},
}


# ═════════════════════════════════════════════════════════════════════════════
#  TEMPLATE 1 — CLIENTES E FORNECEDORES
# ═════════════════════════════════════════════════════════════════════════════

SQL_CLIENTE_FORNECEDOR = """\
-- ═══════════════════════════════════════════════════════════════════════════
--  IMPORTAÇÃO: CLIENTES E FORNECEDORES
--  Gerado em : {data}    Banco: {banco}
--  {mapeamento}
-- ═══════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────── BLOCO 1: CLIENTES ──────────────────────────
SELECT
    isnull(CampoCliente_DataCadastro, getdate())                   AS DataCadastro,
    1                                                               AS CodigoEstabelecimento,
    1                                                               AS CodigoGrupoFornecedor,
    1                                                               AS CodigoGrupoCliente,
    UPPER(CampoCliente_nome)                                       AS Nome,
    upper(CampoCliente_NomeFantasia)                               AS NomeFantasia,
    concat(CampoCliente_endereco, ' // ', CampoCliente_Complemento) AS Endereco,
    CampoCliente_numero                                            AS NumeroLogradouro,
    CampoCliente_bairro                                            AS Bairro,
    CampoCliente_CodigoIBGE                                        AS CodigoIbgeDaCidade,
    CampoCliente_NomeCompleto                                      AS NomeDaCidade,
    CampoCliente_UF                                                AS UFDaCidade,
    replace(replace(CampoCliente_cep, '-', ''), '.', '')           AS CEP,
    CampoCliente_CNPJ_CPF                                          AS CpfOuCnpj,
    isnull(CampoCliente_InscricaoEstadual, CampoCliente_rg)        AS InscricaoEstadualOuRg,
    CampoCliente_InscricaoMunicipal                                AS InscricaoMunicipal,
    0                                                               AS SubstitutoIss,
    coalesce(CampoCliente_email, CampoCliente_Email1, CampoCliente_Email2) AS EmailPrincipal,
    replace(replace(replace(
        coalesce(CampoCliente_Telefone, CampoCliente_Telefone2, CampoCliente_Telefone3),
        '(',''), ')',''), '-','')                                   AS TelefoneComercial,
    isnull(CampoCliente_Celular, CampoCliente_Celular2)            AS TelefoneCelular,
    CampoCliente_Fax                                               AS TelefoneFax,
    CASE
        WHEN len(replace(replace(CampoCliente_CNPJ_CPF, '.', ''), '-', '')) > 11
         AND isnull(CampoCliente_InscricaoEstadual, '') <> ''
        THEN 2 ELSE 1
    END                                                             AS Atividade,
    replace(CampoCliente_LimiteCredito, '.', ',')                  AS ValorDoLimiteCredito,
    CASE
        WHEN CampoCliente_LimiteCredito > 0
         AND CampoCliente_VencimentoLimiteCredito > getdate()
        THEN 'A' ELSE 'P'
    END                                                             AS SituacaoCredito,
    CampoCliente_VencimentoLimiteCredito                           AS DataVencimentoCredito,
    CampoCliente_DataNascimento                                     AS DataNascimento,
    CampoCliente_sexo                                                             AS Sexo,
    concat(CampoCliente_CodCliente, 'C')                          AS CodigoClienteImportado,
    1  AS AtivoFornecedor,
    1  AS AtivoCliente,
    0  AS OptantePeloSimplesNacional,
    1  AS EhCliente,
    0  AS EhFornecedor,
    concat(CampoCliente_CodCliente, 'C')                          AS CodigoImportadoDoFornecedor,
    CONCAT(CampoCliente_Observacao, ' - ', CampoCliente_Observacao2, ' - ', CampoCliente_ObservacaoCliente) AS ObservacaoDeCobranca,
    -- ▼ Ajuste contas contábeis conforme seu plano de contas ▼
    33  AS CodigoContaContabilCliente,
    187 AS CodigoContaContabilFornecedor,
    1  AS AceitaReceberSms,
    0  AS BloquearCompraPorPortador,
    1  AS BloqueiaVendasChequeAprazo,
    0  AS CalculaMulta,
    0  AS ClienteVip,
    0  AS ComprasSuspensas,
    0  AS ComprovouRenda,
    0  AS ComprovouRendaConjuge,
    0  AS DestacaOutrosAcrescimosPortadorBoleto,
    1  AS DestacaPercentualDescontoVenda,
    '' AS DiasPrazo,
    1  AS EmiteCartaCobranca,
    0  AS EmitePedidoVenda,
    1  AS EnviaEmailDeLembrete,
    1  AS EnviaParaCobrancaAposVencimento,
    1  AS EnviaParaProtesto,
    1  AS EnviaParaSerasa,
    0  AS ExigeNotaPagamentoImposto,
    0  AS FazJuncaoPedidosVenda,
    0  AS GeraAvisoDebito,
    1  AS GeraRemessaBancaria,
    0  AS GeraRequisicao,
    1  AS IdentificaOClienteNaNotaFiscalDeConsumidorEletronica,
    0  AS IncluirCnpjTribunalDecontasXmlNfe,
    0  AS ParticipaComissaoAdicionalItensAgregados,
    1  AS ParticipaDoBloqueioPorNotaFiscalDeEntradaPendenteDeConfirmacao,
    1  AS ParticipaIntegracaoUmov,
    0  AS ParticipaMonitoraSerasa,
    0  AS PermiteAlterarTabelaDePrecoNaVenda,
    0  AS PermiteCompraAVistaParaOPortadorBloqueado,
    0  AS PermiteVendaTriangulada,
    1  AS RecalculaChequesSePossuirChequeDevolvido,
    0  AS RetemImpostosRurais,
    0  AS SubstitutoIcms,
    0  AS UsaMultiploDeNota,
    0  AS UtilizaIntegracaoRelato,
    0  AS UtilizaXmlNoPedido,
    1  AS SegmentoDeVenda
FROM {TABELA_CLIENTE} {ALIAS_CLIENTE}
{JOINS_CLIENTE}
{WHERE_CLIENTE}

UNION ALL

-- ─────────────────────────────── BLOCO 2: FORNECEDORES ──────────────────────
SELECT
    isnull(CampoFornecedor_DataCadastro, getdate())                AS DataCadastro,
    1                                                               AS CodigoEstabelecimento,
    1                                                               AS CodigoGrupoFornecedor,
    1                                                               AS CodigoGrupoCliente,
    UPPER(CampoFornecedor_nome)                                    AS Nome,
    upper(CampoFornecedor_NomeFantasia)                            AS NomeFantasia,
    concat(CampoFornecedor_endereco, ' // ', CampoFornecedor_Complemento) AS Endereco,
    CASE
        WHEN TRY_CAST(CampoFornecedor_numero AS INT) IS NOT NULL
         AND CampoFornecedor_numero NOT LIKE '%[^0-9]%'
        THEN CampoFornecedor_numero
        ELSE ''
    END                                                             AS NumeroLogradouro,
    CASE WHEN CampoFornecedor_bairro LIKE '*%' THEN '' ELSE CampoFornecedor_bairro END AS Bairro,
    CampoFornecedor_CodigoIBGE                                     AS CodigoIbgeDaCidade,
    CampoFornecedor_NomeCompleto                                   AS NomeDaCidade,
    CampoFornecedor_UF                                             AS UFDaCidade,
    replace(replace(CampoFornecedor_cep, '-', ''), '.', '')        AS CEP,
    CampoFornecedor_CNPJ_CPF                                       AS CpfOuCnpj,
    isnull(CampoFornecedor_InscricaoEstadual, CampoFornecedor_rg)  AS InscricaoEstadualOuRg,
    CampoFornecedor_InscricaoMunicipal                             AS InscricaoMunicipal,
    0                                                               AS SubstitutoIss,
    coalesce(CampoFornecedor_email, CampoFornecedor_Email1, CampoFornecedor_Email2) AS EmailPrincipal,
    replace(replace(replace(
        coalesce(CampoFornecedor_Telefone, CampoFornecedor_Telefone2, CampoFornecedor_Telefone3),
        '(',''), ')',''), '-','')                                   AS TelefoneComercial,
    isnull(CampoFornecedor_Celular, CampoFornecedor_Celular2)      AS TelefoneCelular,
    CampoFornecedor_Fax                                            AS TelefoneFax,
    CASE
        WHEN len(replace(replace(CampoFornecedor_CNPJ_CPF, '.', ''), '-', '')) > 11
         AND isnull(CampoFornecedor_InscricaoEstadual, '') <> ''
        THEN 2 ELSE 1
    END                                                             AS Atividade,
    replace(CampoFornecedor_LimiteCredito, '.', ',')               AS ValorDoLimiteCredito,
    CASE
        WHEN CampoFornecedor_LimiteCredito > 0 THEN 'A' ELSE 'P'
    END                                                             AS SituacaoCredito,
    ''                                                              AS DataVencimentoCredito,
    ''                                                              AS DataNascimento,
    'M'                                                             AS Sexo,
    concat(CampoFornecedor_CodFornecedor, 'F')                     AS CodigoClienteImportado,
    1  AS AtivoFornecedor,
    1  AS AtivoCliente,
    0  AS OptantePeloSimplesNacional,
    0  AS EhCliente,
    1  AS EhFornecedor,
    concat(CampoFornecedor_CodFornecedor, 'F')                     AS CodigoImportadoDoFornecedor,
    CONCAT(CampoFornecedor_Observacao, ' - ', CampoFornecedor_Observacao2, ' - ', CampoFornecedor_ObservacaoCliente) AS ObservacaoDeCobranca,
    33  AS CodigoContaContabilCliente,
    187 AS CodigoContaContabilFornecedor,
    1  AS AceitaReceberSms,
    0  AS BloquearCompraPorPortador,
    1  AS BloqueiaVendasChequeAprazo,
    0  AS CalculaMulta,
    0  AS ClienteVip,
    0  AS ComprasSuspensas,
    0  AS ComprovouRenda,
    0  AS ComprovouRendaConjuge,
    0  AS DestacaOutrosAcrescimosPortadorBoleto,
    1  AS DestacaPercentualDescontoVenda,
    '' AS DiasPrazo,
    1  AS EmiteCartaCobranca,
    0  AS EmitePedidoVenda,
    1  AS EnviaEmailDeLembrete,
    1  AS EnviaParaCobrancaAposVencimento,
    1  AS EnviaParaProtesto,
    1  AS EnviaParaSerasa,
    0  AS ExigeNotaPagamentoImposto,
    0  AS FazJuncaoPedidosVenda,
    0  AS GeraAvisoDebito,
    1  AS GeraRemessaBancaria,
    0  AS GeraRequisicao,
    1  AS IdentificaOClienteNaNotaFiscalDeConsumidorEletronica,
    0  AS IncluirCnpjTribunalDecontasXmlNfe,
    0  AS ParticipaComissaoAdicionalItensAgregados,
    1  AS ParticipaDoBloqueioPorNotaFiscalDeEntradaPendenteDeConfirmacao,
    1  AS ParticipaIntegracaoUmov,
    0  AS ParticipaMonitoraSerasa,
    0  AS PermiteAlterarTabelaDePrecoNaVenda,
    0  AS PermiteCompraAVistaParaOPortadorBloqueado,
    0  AS PermiteVendaTriangulada,
    1  AS RecalculaChequesSePossuirChequeDevolvido,
    0  AS RetemImpostosRurais,
    0  AS SubstitutoIcms,
    0  AS UsaMultiploDeNota,
    0  AS UtilizaIntegracaoRelato,
    0  AS UtilizaXmlNoPedido,
    1  AS SegmentoDeVenda
FROM {TABELA_FORNECEDOR} {ALIAS_FORNECEDOR}
{JOINS_FORNECEDOR}
{WHERE_FORNECEDOR}
"""


# ═════════════════════════════════════════════════════════════════════════════
#  TEMPLATE 2 — PRODUTOS
# ═════════════════════════════════════════════════════════════════════════════

SQL_PRODUTOS = """\
-- ═══════════════════════════════════════════════════════════════════════════
--  IMPORTAÇÃO: PRODUTOS
--  Gerado em : {data}    Banco: {banco}
--  {mapeamento}
-- ═══════════════════════════════════════════════════════════════════════════

SELECT
    1                                                               AS CodigoEstabelecimento,
    CampoTabela_DataCadastro                                       AS DataCadastro,
    CampoTabela_CodProduto                                         AS CodigoDoItemImportado,
    CampoTabela_nome                                               AS NomeDoItem,
    CampoTabela_descricao                                               AS DescricaoDetalhada,
    ISNULL(CampoTabela_aplicacao, '')                              AS Aplicacao,
    CampoTabela_CodUnidadeMedida                                   AS UnidadeDeMedida,
    CampoTabela_nomeUnidadeMedida                                  AS EmbalagemDeVenda,
    -- ▼ Linha/Família/Grupo — vêm direto da tabela do cliente (sem CASE fixo) ▼
    CampoTabela_linha                                              AS LinhaDeItens,
    CampoTabela_familia                                            AS FamiliaDeItens,
    CampoTabela_grupo                                              AS GrupoDeItens,
    ISNULL(CampoTabela_CodigoFabricante, '')                       AS CodigoDeFabricacao,
    CampoTabela_CodProduto                                         AS CodigoOriginal,
    CampoTabela_marca                                              AS MarcaDeItens,
    'REVISAR'                                                       AS NaturezaDeItens,
    0  AS CodigoDeOrigemDeItens,
    1  AS MultiploDeVenda,
    1  AS MultiploDeEstoque,
    0  AS ComprasSuspensas,
    1  AS tipocontroleestoque,
    1  AS ControlaEstoque,
    CampoTabela_PesoBruto                                          AS PesoBruto,
    CampoTabela_PesoLiquido                                        AS PesoLiquido,
    CampoTabela_CodigoDeBarras                                     AS CodigoDeBarras,
    CampoTabela_CodigoFornecedor                                   AS CodigoImportadoDoFornecedor,
    CampoTabela_MargemLucro                                        AS PercentualMargemLucro,
    CampoTabela_NCM                                                AS CodigoNcmSh,
    CampoTabela_CEST                                               AS CODIGOCEST,
    'Verificar'  AS Lubrificante,
    ISNULL(CampoTabela_CodigoANP, '')                              AS CodigoANP,
    CampoTabela_Ativo                                              AS Ativo,
    CampoTabela_Locacao                                            AS Locacao,
    CampoTabela_Sublocacao                                         AS Sublocacao,
    replace(isnull(CampoTabela_PrecoCompra, 0.0), '.', ',')       AS PrecoCompra,
    replace(isnull(CampoTabela_CustoCompra, 0.0), '.', ',')       AS CustoCompra,
    replace(isnull(CampoTabela_CustoReposicao, 0.0), '.', ',')       AS CustoReposicao,
    replace(isnull(CampoTabela_CustoMedio, 0.0), '.', ',') AS CustoMedio,
    replace(isnull(CampoTabela_CustoInformado, 0.0), '.', ',')       AS CustoInformado,
    replace(isnull(CampoTabela_PrecoVenda, 0.0), '.', ',')        AS PrecoVenda,
    replace(isnull(CampoTabela_SaldoEstoque, 0.0), '.', ',')        AS SaldoEstoque,
    'PADRÃO'                                                        AS SegmentoDoGrupoDeItens,
    -- ▼ Ajuste as contas contábeis conforme seu plano de contas ▼
    'verificar' AS CodigoContaContabilEstoque,
    'verificar' AS CodigoContaContabilVenda,
    'verificar' AS CodigoContaContabilCusto,
    'verificar' AS CodigoContaContabilConsumo
FROM {TABELA_PRODUTO} {ALIAS_PRODUTO}
{JOINS_PRODUTO}
{WHERE_PRODUTO}
"""


# ═════════════════════════════════════════════════════════════════════════════
#  TEMPLATE 3 — CONTAS A PAGAR
# ═════════════════════════════════════════════════════════════════════════════

SQL_CONTAS_PAGAR = """\
-- ═══════════════════════════════════════════════════════════════════════════
--  IMPORTAÇÃO: CONTAS A PAGAR
--  Gerado em : {data}    Banco: {banco}
--  {mapeamento}
-- ═══════════════════════════════════════════════════════════════════════════

SELECT
    CONCAT(CampoTabela_codigo_fornecedor, '-F')                    AS CodigoImportadoDoFornecedor,
    CampoTabela_titulo                                             AS Documento,
    CampoTabela_parcela                                            AS NumeroParcela,
    'TM'                                                            AS Serie,
    CampoTabela_Estabelecimento                                     AS Estabelecimento,
    CampoTabela_DataEmissao                                        AS DataDaDigitacao,
    CampoTabela_DataEmissao                                        AS DataDaEmissao,
    CampoTabela_DataVencimento                                     AS DataDoVencimento,
    replace(CampoTabela_Valor, '.', ',')                           AS ValorDoDocumento,
    1                                                               AS CodigoDoTipoDoDocumento,
    0                                                               AS ValorDaMoraDiaria,
    0                                                               AS ValorDaMulta,
    ''                                                              AS DataDaMulta,
    CampoTabela_ValorPago                                          AS ValorDoAbatimento,
    CampoTabela_DataPagamento                                      AS DataDoAbatimento,
    CampoTabela_portador_codpagamento                              AS NomeDoPortador,
    CampoTabela_Observacoes                                        AS ObservacoesDoDocumento,
    ''                                                              AS CodigoDeBarras
FROM {TABELA_PAGAR} {ALIAS_PAGAR}
{JOINS_PAGAR}
{WHERE_PAGAR}
"""


# ═════════════════════════════════════════════════════════════════════════════
#  TEMPLATE 4 — CONTAS A RECEBER
# ═════════════════════════════════════════════════════════════════════════════

SQL_CONTAS_RECEBER = """\
-- ═══════════════════════════════════════════════════════════════════════════
--  IMPORTAÇÃO: CONTAS A RECEBER
--  Gerado em : {data}    Banco: {banco}
--  {mapeamento}
-- ═══════════════════════════════════════════════════════════════════════════

SELECT
    concat(CampoTabela_CodCliente, '-C')                           AS CodigoDoClienteImportado,
    CampoTabela_Titulo                                             AS Documento,
    CampoTabela_Parcela                                            AS NumeroDaParcela,
    'TM'                                                            AS Serie,
    1                                                               AS CodigoDoEstabelecimento,
    CampoTabela_DataEmissao                                        AS DataDeEmissao,
    CampoTabela_DataVencimento                                     AS DataDeVencimento,
    replace(CampoTabela_valor, '.', ',')                           AS ValorDoDocumento,
    CampoTabela_desconto                                                               AS ValorDoDesconto,
    ''                                                              AS DataLimiteParaDesconto,
    1                                                               AS CodigoDoTipoDoDocumento,
    replace(CampoTabela_ValorRecebido, '.', ',')                   AS ValorDoAbatimento,
    0  AS ValorDaDespesaDeCobranca,
    0  AS ValorDaDespesaProcessual,
    0  AS ValorDaDespesaCartoraria,
    0  AS ValorDaDespesaBancaria,
    '' AS ValorDaDespesaCorreio,
    0  AS ValorDaDespesaProtesto,
    0  AS ValorDaDespesaOutras,
    CampoTabela_valorMoraDiaria                                    AS ValorDaMoraDiaria,
    CampoTabela_ValorDaMulta                                       AS ValorDaMulta,
    dateadd(day, 1, CampoTabela_DataVencimento)                    AS DataDaMulta,
    CampoTabela_DataRecebimento                                    AS DataDoAbatimento,
    CampoTabela_NossoNumero                                        AS NossoNumero,
    CampoTabela_portador                                           AS NomeDoPortador,
    CampoTabela_taxaadiministrativa                                                               AS TaxaAdministracaoFinanceira,
    CampoTabela_Observacao                                         AS Observacoes,
    CampoTabela_Parcela                                            AS SequenciaNoPortador
FROM {TABELA_RECEBER} {ALIAS_RECEBER}
{JOINS_RECEBER}
WHERE {ALIAS_RECEBER}.{CAMPO_STATUS_RECEBER} = '{VALOR_STATUS_ABERTO}'
{AND_WHERE_RECEBER}
"""


# ─────────────────────────────────────────────────────────────────────────────
#  Dicionário principal exportado
# ─────────────────────────────────────────────────────────────────────────────

TEMPLATES = {
    "cliente_fornecedor": {**ENTITY_META["cliente_fornecedor"], "sql": SQL_CLIENTE_FORNECEDOR},
    "produtos":           {**ENTITY_META["produtos"],           "sql": SQL_PRODUTOS},
    "contas_pagar":       {**ENTITY_META["contas_pagar"],       "sql": SQL_CONTAS_PAGAR},
    "contas_receber":     {**ENTITY_META["contas_receber"],     "sql": SQL_CONTAS_RECEBER},
}
