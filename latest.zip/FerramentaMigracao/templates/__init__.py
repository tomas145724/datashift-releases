from .sql_templates import TEMPLATES, ENTITY_META
