"""
Tela de login — aparece ao iniciar o app.
Pede os dados do banco FerramentaMigracao.
O nome do usuário é o próprio login do SQL Server.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox


class LoginDialog:
    BG    = "#f0f2f5"
    ACC   = "#1a73e8"
    TEXT  = "#202124"
    MUT   = "#5f6368"
    GREEN = "#137333"
    RED   = "#c5221f"

    def __init__(self, parent: tk.Tk):
        self.parent  = parent
        self.success = False
        self._conn_result = None   # (True, None) ou (False, "msg de erro")

        self.win = tk.Toplevel(parent)
        self.win.title("Conectar ao Banco de Dados - DataShift")
        self.win.configure(bg=self.BG)
        self.win.resizable(False, False)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self._on_cancel)

        self._build()
        self._center()
        self.win.wait_window()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        from core.kb_connection import get_kb
        sp = get_kb().saved_params

        # Header
        hdr = tk.Frame(self.win, bg=self.ACC)
        hdr.pack(fill="x")
        tk.Label(hdr,
            text="  🔄  DataShift",
            font=("Segoe UI", 14, "bold"),
            fg="white", bg=self.ACC
        ).pack(side="left", pady=12)

        # Card
        card = tk.Frame(self.win, bg="white", relief="solid", bd=1)
        card.pack(padx=30, pady=20, fill="x")

        tk.Label(card,
            text="Conectar ao banco de dados",
            font=("Segoe UI", 12, "bold"),
            fg=self.TEXT, bg="white"
        ).pack(anchor="w", padx=16, pady=(16, 2))

        tk.Label(card,
            text="Informe os dados de acesso ao SQL Server.",
            font=("Segoe UI", 9),
            fg=self.MUT, bg="white"
        ).pack(anchor="w", padx=16, pady=(0, 10))

        ttk.Separator(card).pack(fill="x", padx=16, pady=(0, 10))

        # Campos
        self.v_host    = tk.StringVar(value=sp.get("host",     "br2sql.moveresoftware.com"))
        self.v_port    = tk.StringVar(value=sp.get("port",     "1906"))
        self.v_db      = tk.StringVar(value=sp.get("database", "FerramentaMigracao"))
        self.v_user    = tk.StringVar(value=sp.get("user",     ""))
        self.v_pass    = tk.StringVar()
        self.v_trusted = tk.BooleanVar(value=sp.get("trusted", "false") == "true")

        def row(lbl, var, show=None, width=28):
            r = tk.Frame(card, bg="white"); r.pack(fill="x", padx=16, pady=3)
            tk.Label(r, text=lbl, fg=self.MUT, bg="white",
                     font=("Segoe UI", 10), width=24, anchor="w").pack(side="left")
            e = tk.Entry(r, textvariable=var, font=("Segoe UI", 10),
                         relief="solid", bd=1, bg="white",
                         fg=self.TEXT, insertbackground=self.TEXT, width=width)
            if show: e.configure(show=show)
            e.pack(side="left")
            return e

        row("Host (SQL Server):", self.v_host)
        row("Porta:",             self.v_port, width=8)
        row("Banco de dados:",    self.v_db)

        ttk.Separator(card).pack(fill="x", padx=16, pady=8)
        tk.Label(card, text="  Autenticação SQL Server:",
                 font=("Segoe UI", 10, "bold"),
                 fg=self.TEXT, bg="white").pack(anchor="w", padx=16)

        self.e_user = row("Usuário:", self.v_user)
        self.e_pass = row("Senha:",   self.v_pass, show="●")
        # Enter na senha = conectar
        self.e_pass.bind("<Return>", lambda _: self._do_connect())

        tk.Checkbutton(card,
            text="Usar Autenticação Windows (Trusted Connection)",
            variable=self.v_trusted,
            command=self._on_trusted,
            bg="white", fg=self.TEXT,
            font=("Segoe UI", 10),
            activebackground="white", cursor="hand2"
        ).pack(anchor="w", padx=16, pady=(4, 10))

        # Botões
        btn_row = tk.Frame(card, bg="white")
        btn_row.pack(fill="x", padx=16, pady=(4, 16))

        self.btn_conn = tk.Button(btn_row,
            text="🔌  Conectar",
            command=self._do_connect,
            bg=self.ACC, fg="white",
            font=("Segoe UI", 11, "bold"),
            relief="flat", cursor="hand2",
            padx=20, pady=8
        )
        self.btn_conn.pack(side="left")

        tk.Button(btn_row,
            text="Cancelar",
            command=self._on_cancel,
            bg=self.BG, fg=self.MUT,
            font=("Segoe UI", 10),
            relief="flat", cursor="hand2",
            padx=12, pady=8
        ).pack(side="left", padx=(8, 0))

        self.lbl_status = tk.Label(card, text="",
                                    fg=self.MUT, bg="white",
                                    font=("Segoe UI", 9))
        self.lbl_status.pack(anchor="w", padx=16, pady=(0, 8))

        self._on_trusted()

    def _on_trusted(self):
        on = self.v_trusted.get()
        s  = "disabled" if on else "normal"
        self.e_user.configure(state=s)
        self.e_pass.configure(state=s)

    def _center(self):
        self.win.update_idletasks()
        w  = self.win.winfo_reqwidth()
        h  = self.win.winfo_reqheight()
        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()
        self.win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2 - 40}")

    # ── Conectar — sem thread, direto no main loop ────────────────────────────

    def _do_connect(self):
        self.btn_conn.configure(state="disabled", text="Conectando...")
        self.lbl_status.configure(text="Aguarde...", fg=self.ACC)
        self.win.update()

        params = {
            "host":     self.v_host.get().strip(),
            "port":     self.v_port.get().strip(),
            "database": self.v_db.get().strip(),
            "user":     self.v_user.get().strip(),
            "password": self.v_pass.get(),
            "trusted":  "true" if self.v_trusted.get() else "false",
        }

        # O nome do usuário É o login do SQL Server
        usuario = self.v_user.get().strip() if not self.v_trusted.get() else "windows_auth"

        from core.kb_connection import get_kb
        try:
            get_kb().connect(params, usuario)
            self.success = True
            self.win.destroy()
        except Exception as exc:
            self.btn_conn.configure(state="normal", text="🔌  Conectar")
            self.lbl_status.configure(text="✗ Falha na conexão", fg=self.RED)
            messagebox.showerror(
                "Erro de Conexão",
                f"Não foi possível conectar:\n\n{exc}\n\n"
                "Verifique host, porta, banco, usuário e senha.",
                parent=self.win
            )

    def _on_cancel(self):
        self.success = False
        self.win.destroy()
        self.parent.destroy()
