"""
Interface Gráfica v5 — DataShift
• Login ao iniciar (SQL Server FerramentaMigracao)
• Salva em learner local E no banco central simultaneamente
• Aba Scripts Finais: salvar e pesquisar (com campo Cliente)
• Aba Mapeamento Automático: override de SQL completo
"""
from __future__ import annotations

import re
import threading
import queue
import webbrowser
from datetime import datetime
from pathlib import Path

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

try:
    import customtkinter as ctk
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    USE_CTK = True
except ImportError:
    USE_CTK = False

from templates.sql_templates import TEMPLATES
from core.connectors    import get_schema_from_db, get_sample_rows, execute_query
from core.mapper        import map_schema
from core.renderer      import render_sql
from core.learner       import get_learner
from core.kb_connection import get_kb

DB_PORTS = {
    "SQL Server":      "1433",
    "MySQL / MariaDB": "3306",
    "PostgreSQL":      "5432",
    "Firebird 2.5":    "3050",
    "Firebird 3.0":    "3050",
    "Firebird 5.0":    "3050",
}

TIPOS_BANCO  = ["SQL Server","MySQL / MariaDB","PostgreSQL",
                "Firebird 2.5","Firebird 3.0","Firebird 5.0"]
TIPOS_SCRIPT = ["Clientes / Fornecedores","Produtos",
                "Contas a Pagar","Contas a Receber","Serviços","Outro"]

SQL_KW = (r"\b(SELECT|FROM|WHERE|LEFT|RIGHT|INNER|JOIN|ON|AS|CASE|WHEN|THEN|ELSE|END|"
          r"AND|OR|NOT|NULL|UPPER|LOWER|REPLACE|ISNULL|COALESCE|CONCAT|CAST|LEN|LENGTH|"
          r"UNION|ALL|INSERT|INTO|UPDATE|SET|ORDER|BY|GROUP|HAVING|OUTER|LIKE|IS|IN|"
          r"DISTINCT|TOP|DATEADD|DATE_ADD|SUBSTRING|TRIM|CHARINDEX|POSITION|LOCATE|"
          r"SIMILAR|INTERVAL|CURRENT_TIMESTAMP|NOW|GETDATE|ROW_NUMBER|OVER|PARTITION|"
          r"FIRST|ROWS|FETCH|NEXT|ONLY)\b")


class MigrationApp:
    BG    = "#f0f2f5"; CARD  = "#ffffff"
    ACC   = "#1a73e8"; ACC2  = "#1558b0"
    TEXT  = "#202124"; MUT   = "#5f6368"
    GREEN = "#137333"; RED   = "#c5221f"
    AMBER = "#b45309"; PURP  = "#7c3aed"

    def __init__(self):
        self.root = ctk.CTk() if USE_CTK else tk.Tk()
        self.root.title("MigraPro  v5.0")
        self.root.geometry("1280x880")
        self.root.minsize(1000, 700)
        try: self.root.configure(bg=self.BG)
        except: pass

        # Login antes de tudo
        from gui.login_dialog import LoginDialog
        dlg = LoginDialog(self.root)
        if not dlg.success:
            return
        self.root.after(1500, self._auto_reprocess)
        self.root.after(3000, self._check_update)

        self.schema: dict    = {}
        self.db_params: dict = {}
        self.db_type_var     = tk.StringVar(value="SQL Server")
        self.host_var        = tk.StringVar(value="localhost")
        self.port_var        = tk.StringVar(value="1433")
        self.db_var          = tk.StringVar()
        self.user_var        = tk.StringVar()
        self.pass_var        = tk.StringVar()
        self.trusted_var     = tk.BooleanVar(value=False)
        self.api_key_var     = tk.StringVar()
        self.use_ai_var      = tk.BooleanVar(value=False)
        self.client_tag_var  = tk.StringVar()
        self.ent_vars: dict  = {}
        self.sql_texts: dict = {}
        self.ovr_labels: dict= {}

        self._build()
        self.root.mainloop()

    # ══════════════════════════════════════════════════════════════════════════
    #  BUILD
    # ══════════════════════════════════════════════════════════════════════════

    def _build(self):
        kb = get_kb()
        # Header
        hdr = tk.Frame(self.root, bg=self.ACC); hdr.pack(fill="x")
        tk.Label(hdr, text="  🔄  DataShift",
                 font=("Segoe UI",15,"bold"), fg="white", bg=self.ACC
                 ).pack(side="left", pady=9)
        tk.Label(hdr,
            text=f"  👤 {kb.usuario}  |  🏢 {kb.saved_params.get('database','?')}  ",
            font=("Segoe UI",9), fg="#c8d8f8", bg=self.ACC
        ).pack(side="right", pady=9)

        main = tk.Frame(self.root, bg=self.BG)
        main.pack(fill="both", expand=True, padx=12, pady=8)

        left = tk.Frame(main, bg=self.BG, width=320)
        left.pack(side="left", fill="y", padx=(0,8))
        left.pack_propagate(False)
        self._build_left(left)

        right = tk.Frame(main, bg=self.BG)
        right.pack(side="left", fill="both", expand=True)
        self._build_right(right)

        # Status bar
        sb = tk.Frame(self.root, bg="#e8eaed"); sb.pack(fill="x", side="bottom")
        tk.Label(sb, text="  ", bg="#e8eaed").pack(side="left")
        self.lbl_st = tk.Label(sb, text="Pronto.", fg=self.MUT,
                               bg="#e8eaed", font=("Segoe UI",9))
        self.lbl_st.pack(side="left", fill="x", expand=True)
        stats = kb.get_stats()
        tk.Label(sb,
            text=(f"  Base: {stats.get('table_hints',0)} tabelas | "
                  f"{stats.get('sql_overrides',0)} mapeamentos | "
                  f"{stats.get('final_scripts',0)} scripts finais  "),
            fg=self.MUT, bg="#e8eaed", font=("Segoe UI",9)
        ).pack(side="right")

    # ── Left ──────────────────────────────────────────────────────────────────

    def _build_left(self, p):
        self._sec(p, "1.  Banco de Dados do Cliente")
        tk.Label(p,text="Tipo:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(anchor="w",padx=8)
        ttk.Combobox(p, values=list(DB_PORTS.keys()),
                     textvariable=self.db_type_var,
                     state="readonly", font=("Segoe UI",10)
                     ).pack(fill="x",padx=8,pady=(0,5))
        self.db_type_var.trace_add("write", lambda *_: self.port_var.set(
            DB_PORTS.get(self.db_type_var.get(),"")))

        row = tk.Frame(p,bg=self.BG); row.pack(fill="x",padx=8,pady=(0,4))
        tk.Label(row,text="Host:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10),width=5).pack(side="left")
        self._entry(row,self.host_var).pack(side="left",fill="x",expand=True,padx=(4,4))
        tk.Label(row,text="Porta:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10),width=5).pack(side="left")
        self._entry(row,self.port_var,width=6).pack(side="left")

        for lbl,var,show in [("Banco:",self.db_var,None),("Usuário:",self.user_var,None),("Senha:",self.pass_var,"●")]:
            tk.Label(p,text=lbl,fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(anchor="w",padx=8,pady=(4,0))
            e = self._entry(p,var,show=show); e.pack(fill="x",padx=8,pady=(0,2))
            if lbl=="Usuário:": self.eu=e
            if lbl=="Senha:":   self.ep=e

        tk.Checkbutton(p,text="Autenticação Windows",variable=self.trusted_var,
            command=self._on_trusted,bg=self.BG,fg=self.TEXT,font=("Segoe UI",10),
            activebackground=self.BG,cursor="hand2").pack(anchor="w",padx=8,pady=(0,4))

        tk.Label(p,text="Tag do cliente (opcional):",fg=self.MUT,bg=self.BG,
                 font=("Segoe UI",9)).pack(anchor="w",padx=8)
        self._entry(p,self.client_tag_var).pack(fill="x",padx=8,pady=(0,4))

        ttk.Separator(p,orient="horizontal").pack(fill="x",padx=8,pady=4)
        self.btn_conn = self._btn(p,"🔌  Conectar e Ler Schema",self._do_connect,bg=self.ACC,fg="white")
        self.btn_conn.pack(fill="x",padx=8,pady=4)

        self._sec(p,"2.  Entidades")
        for key,meta in TEMPLATES.items():
            v = tk.BooleanVar(value=True); self.ent_vars[key]=v
            r2 = tk.Frame(p,bg=self.BG); r2.pack(fill="x",padx=8,pady=1)
            tk.Checkbutton(r2,text=meta["nome"],variable=v,
                bg=self.BG,fg=self.TEXT,font=("Segoe UI",10),
                activebackground=self.BG,cursor="hand2").pack(side="left")
            lbl = tk.Label(r2,text="⚪",fg=self.MUT,bg=self.BG,font=("Segoe UI",10))
            lbl.pack(side="right"); self.ovr_labels[key]=lbl

        ttk.Separator(p,orient="horizontal").pack(fill="x",padx=8,pady=4)
        self._sec(p,"3.  IA — Claude (opcional)")
        tk.Checkbutton(p,text="Usar Claude AI",variable=self.use_ai_var,
            command=self._on_ai,bg=self.BG,fg=self.TEXT,font=("Segoe UI",10),
            activebackground=self.BG,cursor="hand2").pack(anchor="w",padx=8,pady=(0,2))
        tk.Label(p,text="API Key:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(anchor="w",padx=8)
        self.eai = self._entry(p,self.api_key_var,show="●")
        self.eai.pack(fill="x",padx=8,pady=(0,2)); self.eai.configure(state="disabled")
        lnk=tk.Label(p,text="  ↗ Obter chave gratuita",fg=self.ACC,cursor="hand2",
                     bg=self.BG,font=("Segoe UI",9,"underline"))
        lnk.pack(anchor="w",padx=8,pady=(0,4))
        lnk.bind("<Button-1>",lambda _: webbrowser.open("https://platform.anthropic.com/account/api-keys"))

        ttk.Separator(p,orient="horizontal").pack(fill="x",padx=8,pady=4)
        self.btn_gen=self._btn(p,"⚙  Gerar Scripts",self._do_generate,
                               bg="#137333",fg="white",state="disabled")
        self.btn_gen.pack(fill="x",padx=8,pady=4)
        self._refresh_ovr_labels()

    # ── Right ─────────────────────────────────────────────────────────────────

    def _build_right(self, parent):
        self.nb = ttk.Notebook(parent); self.nb.pack(fill="both",expand=True)

        # Aba Schema
        ts = tk.Frame(self.nb,bg=self.BG); self.nb.add(ts,text="  Schema  ")
        tk.Label(ts,text="Tabelas do banco do cliente — duplo-clique para ver amostra:",
                 fg=self.MUT,font=("Segoe UI",9),bg=self.BG).pack(anchor="w",padx=8,pady=(6,2))
        frm = tk.Frame(ts,bg=self.BG); frm.pack(fill="both",expand=True,padx=8,pady=(0,8))
        self.tree = ttk.Treeview(frm,columns=("cols",),show="tree headings",selectmode="browse")
        self.tree.heading("#0",text="Tabela"); self.tree.heading("cols",text="Colunas")
        self.tree.column("#0",width=220,minwidth=120); self.tree.column("cols",width=400,minwidth=200)
        sb2=ttk.Scrollbar(frm,orient="vertical",command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb2.set)
        self.tree.pack(side="left",fill="both",expand=True); sb2.pack(side="left",fill="y")
        self.tree.bind("<Double-1>",self._on_dclick)

        # Abas por entidade
        for key,meta in TEMPLATES.items():
            tab=tk.Frame(self.nb,bg=self.BG); self.nb.add(tab,text=f"  {meta['nome']}  ")
            tb=tk.Frame(tab,bg=self.BG); tb.pack(fill="x",padx=8,pady=(6,2))
            self._btn(tb,"💾 Salvar",lambda k=key: self._save(k),
                      bg=self.ACC,fg="white",padx=8,pady=3).pack(side="left",padx=(0,4))
            self._btn(tb,"📋 Copiar",lambda k=key: self._copy(k),
                      padx=8,pady=3).pack(side="left",padx=(0,4))
            self._btn(tb,"✏️ Enviar p/ Mapeamento",lambda k=key: self._to_feedback(k),
                      padx=8,pady=3).pack(side="left",padx=(0,4))
            self._btn(tb,"⭐ Salvar como Script Final",
                      lambda k=key: self._to_final_script(k),
                      bg=self.PURP,fg="white",padx=8,pady=3).pack(side="left")
            txt=scrolledtext.ScrolledText(tab,wrap="none",font=("Consolas",10),
                bg="#1e1e2e",fg="#cdd6f4",insertbackground="white",padx=8,pady=6,relief="flat")
            txt.pack(fill="both",expand=True,padx=8,pady=(0,8))
            self.sql_texts[key]=txt

        self._build_learn_tab()
        self._build_final_scripts_tab()
        self._build_exec_tab()
        self._build_xml_tab()

    # ── Aba Mapeamento Automático ─────────────────────────────────────────────

    def _build_exec_tab(self):
        """Aba para executar SQL no banco do cliente e exportar resultado."""
        tab = tk.Frame(self.nb, bg=self.BG)
        self.nb.add(tab, text="  ▶ Executar SQL  ")

        # ── Editor SQL ────────────────────────────────────────────────────────
        ed = tk.LabelFrame(tab, text="  SQL a executar  ",
                           bg=self.BG, fg=self.ACC,
                           font=("Segoe UI",10,"bold"), relief="groove")
        ed.pack(fill="x", padx=8, pady=(8,4))

        self.exec_sql = scrolledtext.ScrolledText(
            ed, wrap="none", font=("Consolas",10),
            bg="#1e1e2e", fg="#cdd6f4", insertbackground="white",
            padx=8, pady=6, relief="flat", height=8)
        self.exec_sql.pack(fill="both", expand=True, padx=8, pady=(4,4))
        self.exec_sql.insert("1.0", "-- Cole ou escreva o SELECT aqui\n")

        btn_row = tk.Frame(ed, bg=self.BG)
        btn_row.pack(fill="x", padx=8, pady=(0,8))
        self._btn(btn_row, "▶  Executar", self._do_exec_sql,
                  bg="#137333", fg="white", padx=12, pady=5).pack(side="left", padx=(0,8))
        self._btn(btn_row, "📋 Copiar SQL", lambda: (
            self.root.clipboard_clear(),
            self.root.clipboard_append(self.exec_sql.get("1.0","end").strip())
        ), padx=8, pady=4).pack(side="left", padx=(0,8))
        self._btn(btn_row, "🧹 Limpar", lambda: (
            self.exec_sql.delete("1.0","end"),
            self.exec_sql.insert("1.0","-- Cole ou escreva o SELECT aqui\n")
        ), padx=8, pady=4).pack(side="left")
        self.exec_msg = tk.Label(btn_row, text="", fg=self.MUT, bg=self.BG,
                                 font=("Segoe UI",9))
        self.exec_msg.pack(side="left", padx=12)

        # ── Resultado ─────────────────────────────────────────────────────────
        res = tk.LabelFrame(tab, text="  Resultado  ",
                            bg=self.BG, fg=self.ACC,
                            font=("Segoe UI",10,"bold"), relief="groove")
        res.pack(fill="both", expand=True, padx=8, pady=(0,8))

        res_top = tk.Frame(res, bg=self.BG)
        res_top.pack(fill="x", padx=8, pady=(6,4))
        self.exec_info = tk.Label(res_top, text="Nenhuma consulta executada.",
                                  fg=self.MUT, bg=self.BG, font=("Segoe UI",9))
        self.exec_info.pack(side="left")
        self._btn(res_top, "📥 Exportar Excel", self._exec_export_excel,
                  bg=self.ACC, fg="white", padx=8, pady=3).pack(side="right")

        # Treeview para resultados
        tree_frame = tk.Frame(res, bg=self.BG)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=(0,8))

        self.exec_tree = ttk.Treeview(tree_frame, show="headings",
                                       selectmode="extended")
        sb_v = ttk.Scrollbar(tree_frame, orient="vertical",
                              command=self.exec_tree.yview)
        sb_h = ttk.Scrollbar(tree_frame, orient="horizontal",
                              command=self.exec_tree.xview)
        self.exec_tree.configure(yscrollcommand=sb_v.set,
                                  xscrollcommand=sb_h.set)
        sb_v.pack(side="right", fill="y")
        sb_h.pack(side="bottom", fill="x")
        self.exec_tree.pack(fill="both", expand=True)

        # Guarda dados para exportar
        self._exec_cols: list = []
        self._exec_rows: list = []

    def _parse_sql_error(self, raw: str) -> dict:
        """Transforma mensagens de erro do banco em algo legível."""
        import re as _re
        r = raw.lower()

        # Tabela não encontrada
        m = _re.search(r"table\s+unknown\s*\n?\s*(\w+)", raw, _re.IGNORECASE)
        if not m:
            m = _re.search(r"table[s]?\s+['\`\[]?(\w+)['\`\]]?\s*(?:unknown|not found|doesn.t exist|does not exist)", r)
        if m:
            nome = m.group(1).upper()
            sugestoes = [t for t in self.schema if nome.lower() in t.lower()][:5]
            dica = ""
            if sugestoes:
                dica = "\n\nTabelas parecidas no schema:\n  " + "\n  ".join(sugestoes)
            return {
                "titulo": f"Tabela nao encontrada: {nome}",
                "detalhe": f"A tabela '{nome}' nao existe no banco conectado.{dica}"
            }

        # Campo nao encontrado — Firebird: 'Column unknown\nNOME', SQL Server: 'Invalid column name'
        col_pat = _re.compile('column[\\s\\S]{0,20}unknown[\\s\\S]{0,5}([\\w]+)', _re.IGNORECASE)
        m = col_pat.search(raw)
        if not m:
            m = _re.search("invalid column name '([\\w]+)'", r)
        if not m:
            m = _re.search("unknown column '([\\w.]+)'", r)
        if m:
            nome = m.group(1)
            return {
                "titulo": f"Campo nao encontrado: {nome}",
                "detalhe": (f"O campo '{nome}' nao existe na(s) tabela(s) usada(s).\n\n"
                            "Verifique:\n"
                            "  - Nome do campo no schema (duplo-clique na tabela na aba Schema)\n"
                            "  - Alias de tabela correto (ex: cl.nm_cli)")
            }

        # Erro de sintaxe
        if any(x in r for x in ["syntax error", "sql syntax", "unexpected token",
                                  "token unknown", "invalid syntax"]):
            linha = ""
            m = _re.search(r"line (\d+)", r)
            col  = _re.search(r"column (\d+)", r)
            if m: linha = f" na linha {m.group(1)}"
            if col: linha += f", coluna {col.group(1)}"
            return {
                "titulo": f"Erro de sintaxe SQL{linha}",
                "detalhe": ("Verifique:\n"
                            "  - Parenteses abertos e fechados\n"
                            "  - Virgulas entre campos\n"
                            "  - Palavras reservadas usadas como nome de campo\n"
                            "  - Sintaxe compativel com o banco selecionado")
            }

        # Permissão negada
        if any(x in r for x in ["permission", "access denied", "not authorized",
                                  "privilege", "denied"]):
            return {
                "titulo": "Sem permissao para executar",
                "detalhe": "O usuario nao tem permissao de SELECT nesta tabela."
            }

        # Conexão perdida
        if any(x in r for x in ["connection", "timeout", "broken pipe", "not connected"]):
            return {
                "titulo": "Conexao perdida com o banco",
                "detalhe": "Clique em 'Conectar e Ler Schema' para reconectar."
            }

        # Genérico
        return {
            "titulo": "Erro na execucao do SQL",
            "detalhe": raw[:300]
        }

    def _do_exec_sql(self):
        if not self.db_params:
            messagebox.showwarning("Aviso", "Conecte ao banco do cliente primeiro.")
            return
        sql = self.exec_sql.get("1.0", "end").strip()
        sql = "\n".join(l for l in sql.splitlines()
                         if not l.strip().startswith("--"))
        if not sql:
            messagebox.showwarning("Aviso", "Digite um SQL para executar.")
            return
        self.exec_msg.configure(text="Executando...", fg=self.ACC)
        self.root.update()
        q = queue.Queue()
        threading.Thread(
            target=self._exec_worker,
            args=(sql, q),
            daemon=True
        ).start()
        self._wait_exec(q)

    def _exec_worker(self, sql: str, q: queue.Queue):
        try:
            # Sem limite — pega tudo para exportação completa
            cols, rows = execute_query(
                self.db_type_var.get(), self.db_params, sql, max_rows=9_999_999)
            q.put(("ok", cols, rows))
        except Exception as exc:
            q.put(("err", str(exc), []))

    def _wait_exec(self, q: queue.Queue):
        try:
            result = q.get_nowait()
            self._on_exec_ok(result)
        except queue.Empty:
            self.root.after(100, lambda: self._wait_exec(q))

    def _on_exec_ok(self, result):
        if result[0] == "err":
            raw = result[1]
            msg = self._parse_sql_error(raw)
            self.exec_msg.configure(text=f"✗ {msg['titulo']}", fg=self.RED)
            self.exec_info.configure(text="Erro na consulta.")
            detail = f"{msg['titulo']}\n\n{msg['detalhe']}\n\n─────────────────\nErro original:\n{raw}"
            messagebox.showerror("Erro na execução", detail)
            return

        _, cols, rows = result
        self._exec_cols = cols
        self._exec_rows = rows  # todas as linhas — para exportação completa

        DISPLAY_LIMIT = 5000
        display_rows  = rows[:DISPLAY_LIMIT]

        # Limpa e reconstrói treeview
        self.exec_tree.delete(*self.exec_tree.get_children())
        self.exec_tree["columns"] = cols
        for c in cols:
            w = max(80, min(200, len(c)*10))
            self.exec_tree.heading(c, text=c)
            self.exec_tree.column(c, width=w, minwidth=60)

        for i, row in enumerate(display_rows):
            tag = "even" if i % 2 == 0 else "odd"
            self.exec_tree.insert("", "end", values=row, tags=(tag,))

        self.exec_tree.tag_configure("odd",  background="#f8f9ff")
        self.exec_tree.tag_configure("even", background="white")

        total = len(rows)
        truncado = total > DISPLAY_LIMIT
        self.exec_info.configure(
            text=(f"{total} linha(s) | {len(cols)} coluna(s)"
                  + (f" — exibindo {DISPLAY_LIMIT} (Excel exporta todas)"
                     if truncado else "")),
            fg=self.AMBER if truncado else self.GREEN)
        self.exec_msg.configure(text="✓ Concluído", fg=self.GREEN)

    def _exec_export_excel(self):
        if not self._exec_cols:
            messagebox.showwarning("Aviso", "Execute uma consulta primeiro.")
            return
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx"), ("CSV", "*.csv"), ("All", "*.*")],
            initialfile="resultado_sql.xlsx"
        )
        if not path: return
        try:
            if path.endswith(".csv"):
                import csv
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f, delimiter=";")
                    w.writerow(self._exec_cols)
                    w.writerows(self._exec_rows)
            else:
                try:
                    import openpyxl
                    wb = openpyxl.Workbook()
                    ws = wb.active
                    ws.title = "Resultado"
                    # Header em negrito
                    from openpyxl.styles import Font, PatternFill
                    header_fill = PatternFill("solid", fgColor="1a73e8")
                    ws.append(self._exec_cols)
                    for cell in ws[1]:
                        cell.font = Font(bold=True, color="FFFFFF")
                        cell.fill = header_fill
                    # Dados
                    for row in self._exec_rows:
                        ws.append(row)
                    # Auto-width
                    for col in ws.columns:
                        max_len = max(
                            (len(str(cell.value or "")) for cell in col), default=8)
                        ws.column_dimensions[col[0].column_letter].width = min(max_len+4, 50)
                    wb.save(path)
                except ImportError:
                    # Fallback: CSV se openpyxl não instalado
                    import csv
                    path = path.replace(".xlsx", ".csv")
                    with open(path, "w", newline="", encoding="utf-8-sig") as f:
                        w = csv.writer(f, delimiter=";")
                        w.writerow(self._exec_cols)
                        w.writerows(self._exec_rows)
                    messagebox.showinfo("Aviso",
                        "openpyxl não instalado. Salvo como CSV.\n"
                        "Execute: pip install openpyxl")
            self._st(f"✓ Exportado: {path.split('/')[-1].split(chr(92))[-1]}",
                     self.GREEN)
        except Exception as e:
            messagebox.showerror("Erro ao exportar", str(e))

    def _build_learn_tab(self):
        tab=tk.Frame(self.nb,bg=self.BG); self.nb.add(tab,text="  🗺️ Mapeamento  ")

        # Status
        ovr=tk.LabelFrame(tab,text="  Mapeamentos salvos  ",bg=self.BG,fg=self.ACC,
                           font=("Segoe UI",10,"bold"),relief="groove")
        ovr.pack(fill="x",padx=8,pady=(8,4))
        row=tk.Frame(ovr,bg=self.BG); row.pack(fill="x",padx=8,pady=6)
        self.ovr_detail_labels: dict={}
        for key,meta in TEMPLATES.items():
            col=tk.Frame(row,bg=self.BG); col.pack(side="left",expand=True,padx=4)
            tk.Label(col,text=meta["nome"],fg=self.TEXT,bg=self.BG,font=("Segoe UI",9,"bold")).pack()
            lbl=tk.Label(col,text="⚪ Automático",fg=self.MUT,bg=self.BG,font=("Segoe UI",9)); lbl.pack()
            self.ovr_detail_labels[key]=lbl
            self._btn(col,"🗑 Limpar",lambda k=key: self._clear_ovr(k),
                      padx=4,pady=2,font=("Segoe UI",8)).pack()

        # Instruções
        hw=tk.LabelFrame(tab,text="  Como usar  ",bg=self.BG,fg=self.ACC,
                          font=("Segoe UI",10,"bold"),relief="groove")
        hw.pack(fill="x",padx=8,pady=(0,4))
        tk.Label(hw,bg=self.BG,fg=self.MUT,font=("Segoe UI",9),justify="left",
                 text=(
                     "  1. Gere o script → clique '✏️ Enviar p/ Mapeamento'\n"
                     "  2. Corrija tudo: tabela no FROM, JOINs, campos /* NÃO_ENCONTRADO */\n"
                     "  3. Clique '💾 Salvar Mapeamento Fixo'\n"
                     "  4. Salvo no banco central e local — todos os usuários se beneficiam\n"
                     "  5. 🟢 = mapeamento fixo salvo  |  ⚪ = mapeamento automático"
                 )).pack(anchor="w",padx=8,pady=(4,6))

        # Editor
        ed=tk.LabelFrame(tab,text="  Cole ou edite o SQL corrigido  ",
                          bg=self.BG,fg=self.ACC,font=("Segoe UI",10,"bold"),relief="groove")
        ed.pack(fill="both",expand=True,padx=8,pady=(0,4))

        sr=tk.Frame(ed,bg=self.BG); sr.pack(fill="x",padx=8,pady=(6,2))
        tk.Label(sr,text="Entidade:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(side="left",padx=(0,6))
        self.fb_ent=tk.StringVar(value=list(TEMPLATES.keys())[0])
        ttk.Combobox(sr,values=list(TEMPLATES.keys()),textvariable=self.fb_ent,
                     state="readonly",font=("Segoe UI",10),width=28).pack(side="left",padx=(0,12))
        tk.Label(sr,text="Sistema:",fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(side="left",padx=(0,4))
        self.fb_sistema=tk.StringVar()
        self._entry(sr,self.fb_sistema,width=20).pack(side="left")
        tk.Label(sr,text="(ex: Sankhya, Totvs...)",fg=self.MUT,bg=self.BG,font=("Segoe UI",9)).pack(side="left",padx=(4,0))

        self.fb_txt=scrolledtext.ScrolledText(ed,wrap="none",font=("Consolas",10),
            bg="#1e1e2e",fg="#cdd6f4",insertbackground="white",padx=8,pady=6,relief="flat",height=14)
        self.fb_txt.pack(fill="both",expand=True,padx=8,pady=(4,4))
        self.fb_txt.insert("1.0",
            "-- Cole aqui o SQL completamente corrigido\n"
            "-- FROM correto, todos os JOINs, sem /* NÃO_ENCONTRADO */\n")

        br=tk.Frame(ed,bg=self.BG); br.pack(fill="x",padx=8,pady=(0,6))
        self._btn(br,"💾  Salvar Mapeamento Fixo",self._do_save_override,
                  bg="#137333",fg="white").pack(side="left",padx=(0,8))
        self._btn(br,"🧹 Limpar",lambda: self.fb_txt.delete("1.0","end"),
                  padx=8,pady=4).pack(side="left")
        self.fb_msg=tk.Label(ed,text="",fg=self.GREEN,bg=self.BG,font=("Segoe UI",9),wraplength=700)
        self.fb_msg.pack(anchor="w",padx=8,pady=(0,4))

        # Histórico
        hf=tk.LabelFrame(tab,text="  Histórico de mapeamentos salvos  ",
                          bg=self.BG,fg=self.ACC,font=("Segoe UI",10,"bold"),relief="groove")
        hf.pack(fill="x",padx=8,pady=(0,8))
        hff=tk.Frame(hf,bg=self.BG); hff.pack(fill="x",padx=8,pady=4)
        self.hist=ttk.Treeview(hff,columns=("entity","sistema","banco","tag","ts"),
                               show="headings",height=3)
        for c,l,w in [("entity","Entidade",140),("sistema","Sistema",130),
                       ("banco","Banco",110),("tag","Tag/Cliente",130),("ts","Data/Hora",130)]:
            self.hist.heading(c,text=l); self.hist.column(c,width=w,minwidth=50)
        self.hist.pack(fill="x")
        br2=tk.Frame(hf,bg=self.BG); br2.pack(fill="x",padx=8,pady=(0,6))
        self._btn(br2,"🔄 Atualizar",self._refresh_all,padx=8,pady=3).pack(side="left",padx=(0,6))
        self._btn(br2,"⚠ Resetar local",self._reset_all,padx=8,pady=3).pack(side="left",padx=(0,6))
        self._btn(br2,"🧠 Reaprender de todos os scripts salvos",
                  self._do_reprocess,bg=self.ACC,fg="white",
                  padx=8,pady=3).pack(side="left")

        self._refresh_all()

    # ── Aba Scripts Finais ────────────────────────────────────────────────────

    def _build_final_scripts_tab(self):
        tab=tk.Frame(self.nb,bg=self.BG); self.nb.add(tab,text="  ⭐ Scripts Finais  ")

        paned=tk.PanedWindow(tab,orient="vertical",bg=self.BG,sashwidth=6,sashpad=2)
        paned.pack(fill="both",expand=True,padx=8,pady=8)

        # ── Painel Salvar ──────────────────────────────────────────────────────
        save_outer=tk.Frame(paned,bg=self.BG); paned.add(save_outer,minsize=260)
        sv=tk.LabelFrame(save_outer,text="  Salvar Script Validado  ",
                          bg=self.BG,fg=self.ACC,font=("Segoe UI",10,"bold"),relief="groove")
        sv.pack(fill="both",expand=True)

        top_row=tk.Frame(sv,bg=self.BG); top_row.pack(fill="x",padx=8,pady=(8,4))

        def field(parent,label):
            f=tk.Frame(parent,bg=self.BG); f.pack(side="left",padx=(0,12))
            tk.Label(f,text=label,fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(anchor="w")
            return f

        # Usuário (auto)
        f0=field(top_row,"Usuário (automático)")
        tk.Label(f0,text=get_kb().usuario,fg=self.TEXT,bg="#e8f0fe",
                 font=("Segoe UI",10,"bold"),relief="solid",bd=1,padx=8,pady=4,width=14
                 ).pack(anchor="w")

        # Cliente (obrigatório)
        f_cli=field(top_row,"Cliente *")
        self.fs_cliente=tk.StringVar()
        self._entry(f_cli,self.fs_cliente,width=20).pack(anchor="w")

        # Sistema (obrigatório)
        f2=field(top_row,"Sistema *")
        self.fs_sistema=tk.StringVar()
        self._entry(f2,self.fs_sistema,width=20).pack(anchor="w")

        # Banco
        f3=field(top_row,"Banco de dados")
        self.fs_tipo_banco=tk.StringVar(value="SQL Server")
        ttk.Combobox(f3,values=TIPOS_BANCO,textvariable=self.fs_tipo_banco,
                     state="readonly",font=("Segoe UI",10),width=16).pack(anchor="w")

        # Tipo script
        f4=field(top_row,"Tipo de script")
        self.fs_tipo_script=tk.StringVar(value="Clientes / Fornecedores")
        ttk.Combobox(f4,values=TIPOS_SCRIPT,textvariable=self.fs_tipo_script,
                     state="readonly",font=("Segoe UI",10),width=22).pack(anchor="w")

        # Observação
        obs_row=tk.Frame(sv,bg=self.BG); obs_row.pack(fill="x",padx=8,pady=(0,4))
        tk.Label(obs_row,text="Observação (opcional):",fg=self.MUT,bg=self.BG,
                 font=("Segoe UI",10)).pack(side="left",padx=(0,8))
        self.fs_obs=tk.StringVar()
        self._entry(obs_row,self.fs_obs,width=60).pack(side="left")

        # Script SQL
        tk.Label(sv,text="Script SQL:",fg=self.MUT,bg=self.BG,
                 font=("Segoe UI",10)).pack(anchor="w",padx=8)
        self.fs_sql=scrolledtext.ScrolledText(sv,wrap="none",font=("Consolas",10),
            bg="#1e1e2e",fg="#cdd6f4",insertbackground="white",padx=6,pady=4,
            relief="flat",height=7)
        self.fs_sql.pack(fill="both",expand=True,padx=8,pady=(2,4))

        btn_sv=tk.Frame(sv,bg=self.BG); btn_sv.pack(fill="x",padx=8,pady=(0,8))
        self._btn(btn_sv,"⭐  Salvar Script Final",self._do_save_final,
                  bg=self.PURP,fg="white",padx=12,pady=5).pack(side="left")
        self.fs_msg=tk.Label(btn_sv,text="",fg=self.GREEN,bg=self.BG,font=("Segoe UI",9))
        self.fs_msg.pack(side="left",padx=12)

        # ── Painel Pesquisar ───────────────────────────────────────────────────
        search_outer=tk.Frame(paned,bg=self.BG); paned.add(search_outer,minsize=200)
        sr_frame=tk.LabelFrame(search_outer,text="  Consultar Scripts Salvos  ",
                                bg=self.BG,fg=self.ACC,font=("Segoe UI",10,"bold"),
                                relief="groove")
        sr_frame.pack(fill="both",expand=True)

        fil=tk.Frame(sr_frame,bg=self.BG); fil.pack(fill="x",padx=8,pady=(8,4))

        def filt_field(label,var,values=None,width=18):
            f=tk.Frame(fil,bg=self.BG); f.pack(side="left",padx=(0,10))
            tk.Label(f,text=label,fg=self.MUT,bg=self.BG,font=("Segoe UI",10)).pack(anchor="w")
            if values:
                cb=ttk.Combobox(f,values=["Todos"]+values,textvariable=var,
                                 state="readonly",font=("Segoe UI",10),width=width)
                cb.pack(anchor="w")
            else:
                self._entry(f,var,width=width+2).pack(anchor="w")

        self.sf_cliente     = tk.StringVar()
        self.sf_sistema     = tk.StringVar()
        self.sf_tipo_banco  = tk.StringVar(value="Todos")
        self.sf_tipo_script = tk.StringVar(value="Todos")

        filt_field("Cliente:",  self.sf_cliente,  width=16)
        filt_field("Sistema:",  self.sf_sistema,  width=16)
        filt_field("Banco:",    self.sf_tipo_banco,  TIPOS_BANCO,  width=16)
        filt_field("Tipo:",     self.sf_tipo_script, TIPOS_SCRIPT, width=20)

        btn_f=tk.Frame(fil,bg=self.BG); btn_f.pack(side="left",padx=(8,0))
        tk.Label(btn_f,text=" ",bg=self.BG).pack()
        self._btn(btn_f,"🔍 Pesquisar",self._do_search_final,
                  bg=self.ACC,fg="white",padx=8,pady=4).pack()

        # Treeview resultados
        res_frm=tk.Frame(sr_frame,bg=self.BG)
        res_frm.pack(fill="both",expand=True,padx=8,pady=(0,4))
        self.fs_tree=ttk.Treeview(res_frm,
            columns=("usuario","cliente","sistema","tipo_banco","tipo_script","ts","observacao"),
            show="headings",selectmode="browse",height=5)
        for c,l,w in [("usuario","Usuário",90),("cliente","Cliente",120),
                       ("sistema","Sistema",120),("tipo_banco","Banco",100),
                       ("tipo_script","Tipo",150),("ts","Data/Hora",130),
                       ("observacao","Observação",180)]:
            self.fs_tree.heading(c,text=l); self.fs_tree.column(c,width=w,minwidth=50)
        fsb=ttk.Scrollbar(res_frm,orient="vertical",command=self.fs_tree.yview)
        self.fs_tree.configure(yscrollcommand=fsb.set)
        self.fs_tree.pack(side="left",fill="both",expand=True); fsb.pack(side="left",fill="y")
        self.fs_tree.bind("<Double-1>",self._on_script_dclick)

        act=tk.Frame(sr_frame,bg=self.BG); act.pack(fill="x",padx=8,pady=(0,8))
        self._btn(act,"👁 Ver script",self._view_selected_script,padx=8,pady=3).pack(side="left",padx=(0,6))
        self._btn(act,"📋 Copiar",self._copy_selected_script,padx=8,pady=3).pack(side="left",padx=(0,6))
        self._btn(act,"🗺️ Usar como Mapeamento Fixo",self._use_as_override,
                  bg="#137333",fg="white",padx=8,pady=3).pack(side="left",padx=(0,6))
        self._btn(act,"🗑 Excluir",self._delete_selected_script,padx=8,pady=3).pack(side="left")
        tk.Label(act,text="  Duplo-clique para ver o script",fg=self.MUT,bg=self.BG,
                 font=("Segoe UI",9)).pack(side="right")

        self.root.after(500,self._do_search_final)

    # ══════════════════════════════════════════════════════════════════════════
    #  EVENTOS
    # ══════════════════════════════════════════════════════════════════════════

    def _on_trusted(self):
        on=self.trusted_var.get()
        self.eu.configure(state="disabled" if on else "normal")
        self.ep.configure(state="disabled" if on else "normal")

    def _on_ai(self):
        self.eai.configure(state="normal" if self.use_ai_var.get() else "disabled")

    def _on_dclick(self,_):
        sel=self.tree.selection()
        if not sel: return
        tbl=self.tree.item(sel[0],"text").strip()
        if tbl not in self.schema: return
        threading.Thread(target=self._sample_thread,
            args=(self.db_type_var.get(),dict(self.db_params),tbl),daemon=True).start()

    def _sample_thread(self,db,params,tbl):
        rows=get_sample_rows(db,params,tbl,limit=3)
        if not rows:
            self.root.after(0,lambda: self._st(f"Sem dados em {tbl}",self.MUT)); return
        txt=f"Amostra: {tbl}\n{'='*50}\n"
        for i,r in enumerate(rows,1):
            txt+=f"\nLinha {i}:\n"
            for c,v in r.items(): txt+=f"  {c}: {v}\n"
        self.root.after(0,lambda t=txt: messagebox.showinfo(f"Amostra — {tbl}",t))

    # ══════════════════════════════════════════════════════════════════════════
    #  ABA XML NF-e
    # ══════════════════════════════════════════════════════════════════════════

    def _build_xml_tab(self):
        tab = tk.Frame(self.nb, bg=self.BG)
        self.nb.add(tab, text="  XML NF-e  ")

        # Selecao de arquivos
        top = tk.LabelFrame(tab, text="  Arquivos XML  ", bg=self.BG, fg=self.ACC,
                            font=("Segoe UI",10,"bold"), relief="groove")
        top.pack(fill="x", padx=8, pady=(8,4))
        top_row = tk.Frame(top, bg=self.BG); top_row.pack(fill="x", padx=8, pady=6)
        self.xml_files_var = tk.StringVar(value="Nenhum arquivo selecionado")
        tk.Label(top_row, textvariable=self.xml_files_var,
                 fg=self.MUT, bg=self.BG, font=("Segoe UI",9),
                 wraplength=700, justify="left").pack(side="left", fill="x", expand=True)
        self._btn(top_row, "Selecionar XMLs (varios ao mesmo tempo)", self._xml_select_files,
                  bg=self.ACC, fg="white", padx=8, pady=4).pack(side="right")
        self._xml_files = []

        # Opcoes
        opts = tk.Frame(tab, bg=self.BG); opts.pack(fill="x", padx=8, pady=4)

        # Tributacao
        trib = tk.LabelFrame(opts, text="  Extrair Tributacao  ",
                             bg=self.BG, fg="#137333",
                             font=("Segoe UI",10,"bold"), relief="groove")
        trib.pack(side="left", fill="both", expand=True, padx=(0,6))
        tk.Label(trib, bg=self.BG, fg=self.MUT, font=("Segoe UI",9), justify="left",
                 text=("Extrai NCM, CEST, ANP\nCST e Aliquotas: PIS, COFINS, IPI, ICMS\nRemove duplicatas por NCM")
                 ).pack(anchor="w", padx=8, pady=(4,6))
        self._btn(trib, "Extrair Tributacao -> Excel",
                  self._xml_extract_tributacao,
                  bg="#137333", fg="white", padx=10, pady=5).pack(padx=8, pady=(0,8))

        # Produtos
        prod_f = tk.LabelFrame(opts, text="  Extrair Produtos  ",
                              bg=self.BG, fg=self.PURP,
                              font=("Segoe UI",10,"bold"), relief="groove")
        prod_f.pack(side="left", fill="both", expand=True)
        tk.Label(prod_f, bg=self.BG, fg=self.MUT, font=("Segoe UI",9), justify="left",
                 text=("Extrai produtos no formato do template\nCodigo, Nome, NCM, Unidade, Precos\nPronto para importacao")
                 ).pack(anchor="w", padx=8, pady=(4,6))
        self._btn(prod_f, "Extrair Produtos -> Excel",
                  self._xml_extract_produtos,
                  bg=self.PURP, fg="white", padx=10, pady=5).pack(padx=8, pady=(0,8))

        # Log
        log_f = tk.LabelFrame(tab, text="  Log  ", bg=self.BG, fg=self.ACC,
                              font=("Segoe UI",10,"bold"), relief="groove")
        log_f.pack(fill="both", expand=True, padx=8, pady=(4,8))
        self.xml_log_txt = scrolledtext.ScrolledText(log_f, wrap="word",
            font=("Segoe UI",9), bg="#1e1e2e", fg="#cdd6f4",
            insertbackground="white", padx=8, pady=6, relief="flat", height=8)
        self.xml_log_txt.pack(fill="both", expand=True, padx=8, pady=(4,8))

    def _xml_log(self, msg: str):
        self.xml_log_txt.configure(state="normal")
        self.xml_log_txt.insert("end", msg + "\n")
        self.xml_log_txt.see("end")
        self.root.update()

    def _xml_select_files(self):
        files = filedialog.askopenfilenames(
            title="Selecione um ou mais arquivos XML de NF-e (Ctrl+clique para varios)",
            filetypes=[("XML NF-e","*.xml"),("Todos","*.*")]
        )
        if files:
            self._xml_files = list(files)
            nomes = [f.replace("\\","/").split("/")[-1] for f in files]
            resumo = ", ".join(nomes[:4]) + ("..." if len(nomes) > 4 else "")
            self.xml_files_var.set(f"{len(files)} arquivo(s) selecionado(s): {resumo}")
            self._xml_log(f"Selecionados {len(files)} arquivo(s):")
            for n in nomes:
                self._xml_log(f"  - {n}")
        else:
            self._xml_files = []
            self.xml_files_var.set("Nenhum arquivo selecionado")

    def _xml_parse_all(self) -> list:
        import xml.etree.ElementTree as ET
        NS = {"nfe": "http://www.portalfiscal.inf.br/nfe"}

        def txt(el, path, default=""):
            if el is None: return default
            v = el.findtext(path, default=default, namespaces=NS)
            return (v or default).strip()

        all_items = []
        for fpath in self._xml_files:
            fname = fpath.replace("\\","/").split("/")[-1]
            try:
                tree = ET.parse(fpath)
                root = tree.getroot()

                ide   = root.find(".//nfe:ide",  NS)
                emit  = root.find(".//nfe:emit", NS)
                nf_num    = txt(ide, "nfe:nNF")
                nf_serie  = txt(ide, "nfe:serie")
                nf_dt     = (txt(ide,"nfe:dhEmi") or txt(ide,"nfe:dEmi"))[:10]
                emit_nome = txt(emit, "nfe:xNome")
                count = 0

                for det in root.findall(".//nfe:det", NS):
                    prod = det.find("nfe:prod", NS)
                    imp  = det.find("nfe:imposto", NS)
                    if prod is None: continue

                    item = {
                        "_arquivo":  fname,
                        "_nf":       nf_num,
                        "_serie":    nf_serie,
                        "_data":     nf_dt,
                        "_emitente": emit_nome,
                        "cProd":     txt(prod,"nfe:cProd"),
                        "cEAN":      txt(prod,"nfe:cEAN"),
                        "xProd":     txt(prod,"nfe:xProd"),
                        "NCM":       txt(prod,"nfe:NCM"),
                        "CEST":      txt(prod,"nfe:CEST"),
                        "ANP":       txt(prod,"nfe:cProdANP"),
                        "CFOP":      txt(prod,"nfe:CFOP"),
                        "uCom":      txt(prod,"nfe:uCom"),
                        "qCom":      txt(prod,"nfe:qCom","0"),
                        "vUnCom":    txt(prod,"nfe:vUnCom","0"),
                        "vProd":     txt(prod,"nfe:vProd","0"),
                    }

                    if imp:
                        pis = imp.find("nfe:PIS",NS)
                        item["CstPis"]    = txt(pis,".//nfe:CST")
                        item["AliqPis"]   = txt(pis,".//nfe:pPIS","0")
                        cof = imp.find("nfe:COFINS",NS)
                        item["CstCofins"]  = txt(cof,".//nfe:CST")
                        item["AliqCofins"] = txt(cof,".//nfe:pCOFINS","0")
                        ipi = imp.find("nfe:IPI",NS)
                        item["CstIpi"]  = txt(ipi,".//nfe:CST") if ipi is not None else ""
                        item["AliqIpi"] = txt(ipi,".//nfe:pIPI","0") if ipi is not None else "0"
                        icms = imp.find(".//nfe:ICMS",NS)
                        ic   = list(icms)[0] if icms is not None and list(icms) else None
                        item["CstIcms"]  = txt(ic,"nfe:CST") or txt(ic,"nfe:CSOSN")
                        item["AliqIcms"] = txt(ic,"nfe:pICMS","0")
                    else:
                        for k in ["CstPis","CstCofins","CstIpi","CstIcms"]:
                            item[k] = ""
                        for k in ["AliqPis","AliqCofins","AliqIpi","AliqIcms"]:
                            item[k] = "0"

                    all_items.append(item)
                    count += 1

                self._xml_log(f"  OK: {fname} — {count} itens")
            except Exception as e:
                self._xml_log(f"  ERRO em {fname}: {e}")

        return all_items

    def _xml_extract_tributacao(self):
        if not self._xml_files:
            messagebox.showwarning("Aviso","Selecione arquivos XML primeiro."); return
        self._xml_log("\nExtraindo tributacao...")
        items = self._xml_parse_all()
        if not items:
            self._xml_log("Nenhum item encontrado."); return

        icms_map = {
            "00":"T","10":"S","20":"S","30":"F","40":"I","41":"N",
            "50":"U","51":"D","60":"R","70":"S","90":"O",
        }
        seen: dict = {}
        for it in items:
            ncm = it.get("NCM","")
            if ncm and ncm not in seen:
                cst = it.get("CstIcms","")
                def dec(v): return str(v or "0").replace(".",",")
                seen[ncm] = {
                    "Ncm":               ncm,
                    "Cest":              it.get("CEST",""),
                    "Anp":               it.get("ANP",""),
                    "CstPisEntrada":     it.get("CstPis",""),
                    "CstPisSaida":       it.get("CstPis",""),
                    "AliqPisEntrada":    dec(it.get("AliqPis","0")),
                    "AliqPisSaida":      dec(it.get("AliqPis","0")),
                    "CstCofinsEntrada":  it.get("CstCofins",""),
                    "CstCofinsSaida":    it.get("CstCofins",""),
                    "AliqCofinsEntrada": dec(it.get("AliqCofins","0")),
                    "AliqCofinsSaida":   dec(it.get("AliqCofins","0")),
                    "CondicaoIpi":       it.get("CstIpi",""),
                    "AliqIpiEntrada":    dec(it.get("AliqIpi","0")),
                    "AliqIpiSaida":      dec(it.get("AliqIpi","0")),
                    "CondicaoIcms":      cst,
                    "NomeCondicaoIcms":  icms_map.get(cst,""),
                    "AliqIcmsEntrada":   dec(it.get("AliqIcms","0")),
                    "AliqIcmsSaida":     dec(it.get("AliqIcms","0")),
                }

        rows = list(seen.values())
        cols = list(rows[0].keys()) if rows else []
        self._xml_save_excel(rows, cols, "tributacao_nfe.xlsx")
        self._xml_log(f"\nTributacao: {len(rows)} NCMs unicos exportados.")

    def _xml_extract_produtos(self):
        if not self._xml_files:
            messagebox.showwarning("Aviso","Selecione arquivos XML primeiro."); return
        self._xml_log("\nExtraindo produtos...")
        items = self._xml_parse_all()
        if not items:
            self._xml_log("Nenhum item encontrado."); return

        def dec(v):
            """Formata decimal: troca ponto por virgula."""
            return str(v or "0").replace(".",",")

        seen: dict = {}
        for it in items:
            key = it.get("cProd","") + "|" + it.get("NCM","")
            if key not in seen:
                preco = it.get("vUnCom","0")
                seen[key] = {
                    # Ordem exata do template de produtos
                    "CodigoEstabelecimento":        "1",
                    "DataCadastro":                 it.get("_data",""),
                    "CodigoDoItemImportado":        it.get("cProd",""),
                    "NomeDoItem":                   it.get("xProd",""),
                    "DescricaoDetalhada":           it.get("xProd",""),
                    "Aplicacao":                    "",
                    "UnidadeDeMedida":              it.get("uCom",""),
                    "EmbalagemDeVenda":             it.get("uCom",""),
                    "LinhaDeItens":                 "",
                    "FamiliaDeItens":               "",
                    "GrupoDeItens":                 "",
                    "CodigoDeFabricacao":           "",
                    "CodigoOriginal":               it.get("cProd",""),
                    "MarcaDeItens":                 "",
                    "NaturezaDeItens":              "REVISAR",
                    "CodigoDeOrigemDeItens":        "0",
                    "MultiploDeVenda":              "1",
                    "MultiploDeEstoque":            "1",
                    "ComprasSuspensas":             "0",
                    "tipocontroleestoque":          "1",
                    "ControlaEstoque":              "1",
                    "PesoBruto":                   dec("0"),
                    "PesoLiquido":                  dec("0"),
                    "CodigoDeBarras":               it.get("cEAN",""),
                    "CodigoImportadoDoFornecedor":  "",
                    "PercentualMargemLucro":        dec("0"),
                    "CodigoNcmSh":                  it.get("NCM",""),
                    "CODIGOCEST":                   it.get("CEST",""),
                    "Lubrificante":                 "Verificar",
                    "CodigoANP":                    it.get("ANP",""),
                    "Ativo":                        "1",
                    "Locacao":                      "0",
                    "Sublocacao":                   "0",
                    "PrecoCompra":                  dec(preco),
                    "CustoCompra":                  dec(preco),
                    "CustoReposicao":               dec(preco),
                    "CustoMedio":                   dec(preco),
                    "CustoInformado":               dec(preco),
                    "PrecoVenda":                   dec(preco),
                    "SaldoEstoque":                 dec(it.get("qCom","0")),
                    "SegmentoDoGrupoDeItens":       "PADRAO",
                    "CodigoContaContabilEstoque":   "verificar",
                    "CodigoContaContabilVenda":     "verificar",
                    "CodigoContaContabilCusto":     "verificar",
                    "CodigoContaContabilConsumo":   "verificar",
                    # Info extra para referencia
                    "OrigemNF":                     it.get("_nf",""),
                    "Emitente":                     it.get("_emitente",""),
                    "CFOP":                         it.get("CFOP",""),
                }

        rows = list(seen.values())
        cols = list(rows[0].keys()) if rows else []
        self._xml_save_excel(rows, cols, "produtos_nfe.xlsx")
        self._xml_log(f"\nProdutos: {len(rows)} itens unicos exportados.")

    def _xml_save_excel(self, rows: list, cols: list, default_name: str):
        if not rows:
            self._xml_log("Nenhum dado para exportar."); return
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel","*.xlsx"),("CSV","*.csv"),("Todos","*.*")],
            initialfile=default_name
        )
        if not path: return
        try:
            if path.endswith(".csv"):
                import csv
                with open(path,"w",newline="",encoding="utf-8-sig") as f:
                    w = csv.DictWriter(f, fieldnames=cols, delimiter=";",
                                       extrasaction="ignore")
                    w.writeheader(); w.writerows(rows)
            else:
                try:
                    import openpyxl
                    from openpyxl.styles import Font, PatternFill, Alignment
                    wb = openpyxl.Workbook(); ws = wb.active
                    ws.title = default_name.replace(".xlsx","")[:31]
                    hfill = PatternFill("solid", fgColor="1a73e8")
                    hfont = Font(bold=True, color="FFFFFF")
                    ws.append(cols)
                    for cell in ws[1]:
                        cell.font = hfont
                        cell.fill = hfill
                        cell.alignment = Alignment(horizontal="center")
                    for row in rows:
                        ws.append([row.get(c,"") for c in cols])
                    for col in ws.columns:
                        ml = max((len(str(cell.value or "")) for cell in col), default=8)
                        ws.column_dimensions[col[0].column_letter].width = min(ml+4,50)
                    wb.save(path)
                except ImportError:
                    import csv
                    path = path.replace(".xlsx",".csv")
                    with open(path,"w",newline="",encoding="utf-8-sig") as f:
                        w = csv.DictWriter(f, fieldnames=cols, delimiter=";",
                                           extrasaction="ignore")
                        w.writeheader(); w.writerows(rows)
                    self._xml_log("openpyxl nao instalado — salvo como CSV.")
                    self._xml_log("Para Excel: pip install openpyxl")
            nome = path.replace("\\","/").split("/")[-1]
            self._xml_log(f"Salvo: {nome}")
            self._st(f"XML exportado: {nome}", self.GREEN)
        except Exception as e:
            messagebox.showerror("Erro ao salvar", str(e))


    # ══════════════════════════════════════════════════════════════════════════
    #  CONEXÃO (banco do cliente)
    # ══════════════════════════════════════════════════════════════════════════

    def _do_connect(self):
        self._st("Conectando...",self.ACC)
        self.btn_conn.configure(state="disabled",text="Conectando...")
        self.db_params={
            "host":self.host_var.get(),"port":self.port_var.get(),
            "database":self.db_var.get(),"user":self.user_var.get(),
            "password":self.pass_var.get(),"trusted":str(self.trusted_var.get()),
        }
        qc = queue.Queue()
        threading.Thread(target=self._conn_worker,args=(qc,),daemon=True).start()
        self._wait_conn(qc)

    def _wait_conn(self, q):
        try:
            ok, data = q.get_nowait()
            if ok: self.schema=data; self._on_conn_ok()
            else: self._on_conn_err(data)
        except queue.Empty:
            self.root.after(100, lambda: self._wait_conn(q))

    def _conn_worker(self, q:queue.Queue):
        try:
            s=get_schema_from_db(self.db_type_var.get(),self.db_params)
            q.put((True, s))
        except Exception as exc:
            q.put((False, str(exc)))

    def _on_conn_ok(self):
        self.btn_conn.configure(state="normal",text="🔌  Conectar e Ler Schema")
        self._st(f"✓ {len(self.schema)} tabelas | duplo-clique para amostra",self.GREEN)
        self._fill_tree(); self.btn_gen.configure(state="normal")

    def _on_conn_err(self,msg:str):
        self.btn_conn.configure(state="normal",text="🔌  Conectar e Ler Schema")
        self._st("✗ Erro de conexão",self.RED)
        messagebox.showerror("Erro de Conexão",msg)

    def _fill_tree(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for tbl,cols in sorted(self.schema.items()):
            preview=", ".join(cols[:8])+("..." if len(cols)>8 else "")
            node=self.tree.insert("","end",text=tbl,values=(preview,))
            for c in cols: self.tree.insert(node,"end",text=f"    {c}")

    # ══════════════════════════════════════════════════════════════════════════
    #  GERAÇÃO
    # ══════════════════════════════════════════════════════════════════════════

    def _do_generate(self):
        sel=[k for k,v in self.ent_vars.items() if v.get()]
        if not sel: messagebox.showwarning("Aviso","Selecione pelo menos uma entidade."); return
        if not self.schema: messagebox.showwarning("Aviso","Conecte ao banco primeiro."); return
        self.btn_gen.configure(state="disabled",text="Gerando...")
        self._st("Gerando scripts...",self.ACC)
        # Carrega KB no main thread (sem conexão em thread)
        try:
            from core.kb_connection import load_kb_data
            kb_data = load_kb_data()
            erros = kb_data.get("errors", [])
            n_ovr = len(kb_data.get("overrides", {}))
            n_fs  = len(kb_data.get("final_scripts_all", {}))
            n_th  = len(kb_data.get("table_hints", {}))
            if erros:
                self._st(f"Aviso KB: {' | '.join(erros)}", self.AMBER)
            else:
                self._st(
                    f"KB: {n_ovr} mapeamentos fixos | {n_fs} entidades com scripts | "
                    f"{n_th} tabelas aprendidas — escolhendo melhor script...",
                    self.MUT
                )
        except Exception as e:
            kb_data = {}
            self._st(f"Erro ao carregar KB: {e}", self.RED)
        q = queue.Queue()
        threading.Thread(target=self._gen_worker,args=(sel,q,kb_data),daemon=True).start()
        self._wait_queue(q, self._on_gen_ok, sel)

    def _wait_queue(self, q, callback, *args):
        """Verifica fila a cada 100ms sem bloquear a UI (Python 3.14 safe)."""
        try:
            result = q.get_nowait()
            callback(result, *args)
        except queue.Empty:
            self.root.after(100, lambda: self._wait_queue(q, callback, *args))

    def _gen_worker(self,selected:list, q:queue.Queue, kb_data:dict=None):
        db=self.db_type_var.get(); results={}
        for eid in selected:
            try:
                mapping=map_schema(self.schema, eid, kb_data, self.schema)
                sql=render_sql(eid,mapping,db)
                if self.use_ai_var.get() and self.api_key_var.get().strip():
                    sql=self._ai(eid,sql,self.api_key_var.get().strip(),db)
                results[eid]=sql
            except Exception as exc:
                import traceback
                results[eid]=f"-- ERRO ao gerar {eid}:\n-- {exc}\n-- {traceback.format_exc()}"
        q.put(results)

    def _ai(self,eid,sql,api_key,db):
        try:
            import anthropic
            client=anthropic.Anthropic(api_key=api_key)
            schema_txt="\n".join(f"{t}: {', '.join(c)}" for t,c in self.schema.items())
            resp=client.messages.create(
                model="claude-sonnet-4-20250514",max_tokens=4096,
                messages=[{"role":"user","content":
                    f"Revise este SQL de migração para {db}.\n"
                    f"Schema:\n{schema_txt}\n\nSQL:\n```sql\n{sql}\n```\n"
                    f"Corrija NÃO_ENCONTRADO, adicione JOINs, adapte sintaxe. Retorne apenas o SQL."}])
            txt=resp.content[0].text.strip()
            if txt.startswith("```"):
                lines=txt.split("\n"); e2=-1 if lines[-1].strip()=="```" else len(lines)
                txt="\n".join(lines[1:e2])
            return txt
        except Exception as exc:
            return sql+f"\n-- IA falhou: {exc}\n"

    def _on_gen_ok(self,results,selected=None):
        self.btn_gen.configure(state="normal",text="⚙  Gerar Scripts")
        for eid,sql in results.items():
            t=self.sql_texts[eid]
            t.configure(state="normal"); t.delete("1.0","end"); t.insert("1.0",sql)
            self._highlight(t)
        if selected:
            try: self.nb.select(list(TEMPLATES.keys()).index(selected[0])+1)
            except: pass
        ok=sum(1 for s in results.values() if not s.startswith("-- ERRO"))
        self._st(f"✓ {ok}/{len(selected)} script(s) gerado(s).",self.GREEN)
        self._refresh_ovr_labels()

    # ══════════════════════════════════════════════════════════════════════════
    #  MAPEAMENTO (override)
    # ══════════════════════════════════════════════════════════════════════════

    def _to_feedback(self,key:str):
        sql=self.sql_texts[key].get("1.0","end").strip()
        if not sql: messagebox.showwarning("Aviso","Gere o script primeiro."); return
        self.fb_txt.delete("1.0","end"); self.fb_txt.insert("1.0",sql)
        self.fb_ent.set(key)
        idx=len(TEMPLATES)+1
        try: self.nb.select(idx)
        except: pass
        self._st("Script enviado. Corrija e clique 'Salvar Mapeamento Fixo'.",self.AMBER)

    def _do_save_override(self):
        sql=self.fb_txt.get("1.0","end").strip()
        eid=self.fb_ent.get()
        if not sql or sql.startswith("-- Cole aqui"):
            messagebox.showwarning("Aviso","Cole o SQL corrigido primeiro."); return
        if not self.fb_sistema.get().strip():
            messagebox.showwarning("Aviso","O campo Sistema e obrigatorio."); return

        kb=get_kb(); db=self.db_type_var.get(); tag=self.client_tag_var.get().strip()
        sistema=self.fb_sistema.get().strip()

        # Salva no banco central SQL Server
        kb.save_sql_override(eid,sql,db_type=db,client_tag=tag,sistema=sistema)
        kb.save_history(eid,"sql_override",db,f"sistema:{sistema} tag:{tag}")

        # Salva também no learner local (fallback offline)
        get_learner().set_sql_override(eid,sql,db_type=db,client_tag=tag)

        # ── Aprende com o SQL corrigido ───────────────────────────────────────
        try:
            from core.sql_analyzer import learn_from_sql
            result = learn_from_sql(sql, eid, db_type=db)
            extra  = (f" | aprendeu: {len(result['tables'])} tabelas, "
                      f"{len(result['fields'])} campos, "
                      f"{len(result['joins'])} JOINs")
        except Exception:
            extra = ""

        self.fb_msg.configure(
            text=(f"✓ Mapeamento salvo no banco central e localmente "
                  f"— '{TEMPLATES[eid]['nome']}'{extra}"),
            fg=self.GREEN)
        self._st(f"✓ Mapeamento fixo salvo: '{TEMPLATES[eid]['nome']}'",self.GREEN)
        self._refresh_all()

    def _clear_ovr(self,key:str):
        if messagebox.askyesno("Confirmar",
            f"Limpar mapeamento de '{TEMPLATES[key]['nome']}'?\n"
            "Voltará a usar o Mapeamento Automático."):
            get_kb().delete_overrides(key)
            get_learner().delete_sql_override(key)
            self._refresh_all()
            self._st(f"Mapeamento de '{key}' removido.",self.AMBER)

    def _auto_reprocess(self):
        qr = queue.Queue()
        threading.Thread(target=self._reprocess_bg, args=(qr,), daemon=True).start()
        self._wait_reprocess(qr)

    def _reprocess_bg(self, q):
        try:
            from core.sql_analyzer import reprocess_all_saved
            q.put(reprocess_all_saved())
        except Exception as exc:
            q.put({"ok": False, "erro": str(exc)})

    def _wait_reprocess(self, q):
        try:
            result = q.get_nowait()
            if result.get("ok"):
                c = result["contagens"]
                total = c["tables"] + c["fields"] + c["joins"]
                if total > 0:
                    self._st(
                        f"✓ Aprendizado carregado: {c['tables']} tabelas | "
                        f"{c['fields']} campos | {c['joins']} JOINs",
                        self.GREEN
                    )
            elif result.get("erro"):
                self._st(f"Aviso aprendizado: {result['erro']}", self.AMBER)
        except queue.Empty:
            self.root.after(200, lambda: self._wait_reprocess(q))

    def _check_update(self):
        """Verifica atualizacao no GitHub em background."""
        import threading
        import queue
        q = queue.Queue()
        def bg():
            try:
                from core.updater import check_update
                result = check_update(timeout=6)
                q.put(result)
            except Exception:
                q.put(None)
        threading.Thread(target=bg, daemon=True).start()
        self._wait_update_check(q)

    def _wait_update_check(self, q):
        try:
            remote = q.get_nowait()
            if remote:
                self._st(
                    f"Nova versao disponivel: v{remote.get('versao','')} "
                    f"— clique em Ajuda > Atualizar para instalar",
                    self.AMBER
                )
                # Mostra popup de atualização
                from core.updater import show_update_dialog
                show_update_dialog(self.root, remote)
        except queue.Empty:
            self.root.after(300, lambda: self._wait_update_check(q))

    def _reset_all(self):
        if messagebox.askyesno("Confirmar",
            "Resetar TODO o aprendizado LOCAL?\n(O banco central não é afetado)"):
            get_learner().clear_all()
            self._refresh_all()
            self._st("Aprendizado local resetado.",self.MUT)

    def _do_reprocess(self):
        """Reprocessa todos os scripts salvos no banco e reaplica o aprendizado."""
        if not messagebox.askyesno("Confirmar",
            "Reprocessar TODOS os scripts salvos no banco central?\n\n"
            "O sistema vai ler todos os mapeamentos e scripts finais "
            "e extrair tabelas, campos e JOINs para melhorar o Mapeamento Automático.\n\n"
            "Isso pode demorar alguns segundos."):
            return
        self._st("Reprocessando scripts salvos...", self.ACC)
        threading.Thread(target=self._reprocess_worker, daemon=True).start()

    def _reprocess_worker(self):
        try:
            from core.sql_analyzer import reprocess_all_saved
            result = reprocess_all_saved()
            if result.get("ok"):
                c = result["contagens"]
                msg = (f"✓ Reprocessamento concluído!\n"
                       f"  Mapeamentos analisados : {c['overrides']}\n"
                       f"  Scripts finais analisados: {c['final_scripts']}\n"
                       f"  Tabelas aprendidas     : {c['tables']}\n"
                       f"  Campos aprendidos      : {c['fields']}\n"
                       f"  JOINs aprendidos       : {c['joins']}")
                self.root.after(0, lambda m=msg: messagebox.showinfo("Reprocessamento concluído", m))
                self.root.after(50, lambda: self._st("✓ Reprocessamento concluído.", self.GREEN))
            else:
                err = result.get("erro","Falha desconhecida")
                self.root.after(0, lambda e=err: messagebox.showerror("Erro", e))
                self.root.after(50, lambda e=err: self._st(f"✗ {e}", self.RED))
        except Exception as exc:
            msg = str(exc)
            self.root.after(0, lambda m=msg: messagebox.showerror("Erro", m))
            self.root.after(50, lambda m=msg: self._st(f"✗ {m}", self.RED))

    def _refresh_ovr_labels(self):
        kb=get_kb(); learner=get_learner()
        for key,lbl in self.ovr_labels.items():
            has=kb.has_override(key) or learner.has_sql_override(key)
            lbl.configure(text="🟢" if has else "⚪",fg=self.GREEN if has else self.MUT)

    def _refresh_detail_labels(self):
        kb=get_kb(); learner=get_learner()
        for key,lbl in self.ovr_detail_labels.items():
            has=kb.has_override(key) or learner.has_sql_override(key)
            lbl.configure(
                text="🟢 Mapeamento fixo" if has else "⚪ Automático",
                fg=self.GREEN if has else self.MUT)

    def _refresh_all(self):
        self._refresh_ovr_labels(); self._refresh_detail_labels()
        for i in self.hist.get_children(): self.hist.delete(i)
        # Carrega do banco central
        kb=get_kb()
        rows=kb.get_overrides_list() if kb.is_connected() else []
        for r in rows:
            self.hist.insert("","end",values=(
                r.get("entity_key",""), r.get("sistema",""),
                r.get("db_type",""),    r.get("client_tag",""),
                (r.get("ts","") or "")[:16]))
        # Fallback: learner local se banco vazio
        if not rows:
            for e in get_learner().get_history():
                self.hist.insert("","end",values=(
                    e.get("entity",""),"",e.get("banco",""),
                    e.get("tag",""),e.get("ts","")[:16] if e.get("ts") else ""))

    # ══════════════════════════════════════════════════════════════════════════
    #  SCRIPTS FINAIS
    # ══════════════════════════════════════════════════════════════════════════

    def _to_final_script(self,key:str):
        sql=self.sql_texts[key].get("1.0","end").strip()
        if not sql: messagebox.showwarning("Aviso","Gere o script primeiro."); return
        tipo_map={
            "cliente_fornecedor":"Clientes / Fornecedores",
            "produtos":"Produtos",
            "contas_pagar":"Contas a Pagar",
            "contas_receber":"Contas a Receber",
        }
        self.fs_tipo_script.set(tipo_map.get(key,"Outro"))
        self.fs_tipo_banco.set(self.db_type_var.get())
        self.fs_sql.delete("1.0","end"); self.fs_sql.insert("1.0",sql)
        try: self.nb.select(len(TEMPLATES)+2)
        except: pass
        self._st("Script copiado para Scripts Finais. Preencha cliente, sistema e salve.",self.AMBER)

    def _do_save_final(self):
        cliente    =self.fs_cliente.get().strip()
        sistema    =self.fs_sistema.get().strip()
        tipo_banco =self.fs_tipo_banco.get().strip()
        tipo_script=self.fs_tipo_script.get().strip()
        sql        =self.fs_sql.get("1.0","end").strip()
        obs        =self.fs_obs.get().strip()

        if not cliente:
            messagebox.showwarning("Aviso","O campo 'Cliente' é obrigatório."); return
        if not sistema:
            messagebox.showwarning("Aviso","O campo 'Sistema' é obrigatório."); return
        if not sql:
            messagebox.showwarning("Aviso","O script SQL está vazio."); return

        kb=get_kb()
        if not kb.is_connected():
            messagebox.showerror("Erro","Sem conexão com o banco de conhecimento."); return

        ok=kb.save_final_script(cliente,sistema,tipo_banco,tipo_script,sql,obs)
        if ok:
            # ── Aprende com o script final ────────────────────────────────────
            _tipo_to_entity = {
                "Clientes / Fornecedores": "cliente_fornecedor",
                "Produtos":                "produtos",
                "Contas a Pagar":          "contas_pagar",
                "Contas a Receber":        "contas_receber",
            }
            eid_learn = _tipo_to_entity.get(tipo_script,"")
            extra = ""
            if eid_learn:
                try:
                    from core.sql_analyzer import learn_from_sql, SQLAnalyzer
                    result = learn_from_sql(sql, eid_learn, db_type=tipo_banco,
                                            weight=SQLAnalyzer.FINAL_WEIGHT)
                    extra = (f" | aprendeu: {len(result['tables'])} tabelas, "
                             f"{len(result['fields'])} campos, "
                             f"{len(result['joins'])} JOINs")
                except Exception:
                    pass

            self.fs_msg.configure(
                text=(f"✓ Salvo! Cliente: {cliente} | Sistema: {sistema} "
                      f"| {tipo_banco} | {tipo_script}{extra}"),
                fg=self.GREEN)
            self._st(f"✓ Script final salvo: {cliente} / {sistema}",self.GREEN)
            self._do_search_final()
        else:
            self.fs_msg.configure(text="✗ Erro ao salvar.",fg=self.RED)

    def _do_search_final(self):
        kb=get_kb()
        if not kb.is_connected(): return
        rows=kb.search_final_scripts(
            cliente    =self.sf_cliente.get(),
            sistema    =self.sf_sistema.get(),
            tipo_banco =self.sf_tipo_banco.get(),
            tipo_script=self.sf_tipo_script.get(),
        )
        for i in self.fs_tree.get_children(): self.fs_tree.delete(i)
        for r in rows:
            self.fs_tree.insert("","end",iid=r["id"],values=(
                r["usuario"],r["cliente"],r["sistema"],
                r["tipo_banco"],r["tipo_script"],
                r["ts"][:16],r.get("observacao",""),))
        self._st(f"{len(rows)} script(s) encontrado(s).",self.MUT)

    def _get_sel_id(self) -> str | None:
        sel=self.fs_tree.selection(); return sel[0] if sel else None

    def _use_as_override(self):
        """Copia script final selecionado para o editor de Mapeamento Fixo."""
        sid=self._get_sel_id()
        if not sid: messagebox.showwarning("Aviso","Selecione um script."); return

        kb=get_kb()
        sql=kb.get_script_by_id(sid)
        if not sql: messagebox.showerror("Erro","Script não encontrado."); return

        # Descobre a entidade pelo tipo_script da linha selecionada
        item=self.fs_tree.item(sid)
        vals=item.get("values",())
        # colunas: usuario(0) cliente(1) sistema(2) tipo_banco(3) tipo_script(4)
        tipo_script = vals[4] if len(vals)>4 else ""
        sistema_val = vals[2] if len(vals)>2 else ""
        _tipo_map={
            "Clientes / Fornecedores": "cliente_fornecedor",
            "Produtos":                "produtos",
            "Contas a Pagar":          "contas_pagar",
            "Contas a Receber":        "contas_receber",
        }
        eid=_tipo_map.get(tipo_script,"cliente_fornecedor")

        # Copia para a aba Mapeamento
        self.fb_txt.delete("1.0","end")
        self.fb_txt.insert("1.0",sql)
        self.fb_ent.set(eid)
        self.fb_sistema.set(sistema_val)

        # Navega para aba Mapeamento
        idx=len(TEMPLATES)+1
        try: self.nb.select(idx)
        except: pass
        self._st(
            f"Script copiado para Mapeamento. Revise e clique '💾 Salvar Mapeamento Fixo'.",
            self.AMBER)

    def _on_script_dclick(self,_): self._view_selected_script()

    def _view_selected_script(self):
        sid=self._get_sel_id()
        if not sid: messagebox.showwarning("Aviso","Selecione um script."); return
        sql=get_kb().get_script_by_id(sid)
        if not sql: messagebox.showerror("Erro","Script não encontrado."); return
        win=tk.Toplevel(self.root)
        win.title("Script Completo"); win.geometry("900x600"); win.configure(bg=self.BG)
        tb=tk.Frame(win,bg=self.BG); tb.pack(fill="x",padx=8,pady=6)
        self._btn(tb,"📋 Copiar",lambda:(win.clipboard_clear(),win.clipboard_append(sql),
                  self._st("✓ Copiado.",self.GREEN)),padx=8,pady=4).pack(side="left",padx=(0,6))
        self._btn(tb,"💾 Salvar .sql",lambda: self._save_text_dialog(sql),
                  bg=self.ACC,fg="white",padx=8,pady=4).pack(side="left")
        txt=scrolledtext.ScrolledText(win,wrap="none",font=("Consolas",10),
            bg="#1e1e2e",fg="#cdd6f4",insertbackground="white",padx=8,pady=6)
        txt.pack(fill="both",expand=True,padx=8,pady=(0,8))
        txt.insert("1.0",sql); self._highlight(txt)

    def _copy_selected_script(self):
        sid=self._get_sel_id()
        if not sid: messagebox.showwarning("Aviso","Selecione um script."); return
        sql=get_kb().get_script_by_id(sid)
        if sql: self.root.clipboard_clear(); self.root.clipboard_append(sql)
        self._st("✓ Script copiado.",self.GREEN)

    def _delete_selected_script(self):
        sid=self._get_sel_id()
        if not sid: messagebox.showwarning("Aviso","Selecione um script."); return
        if messagebox.askyesno("Confirmar","Excluir este script?"):
            get_kb().delete_final_script(sid)
            self._do_search_final()
            self._st("Script excluído.",self.MUT)

    def _save_text_dialog(self,text:str):
        path=filedialog.asksaveasfilename(
            defaultextension=".sql",filetypes=[("SQL","*.sql"),("All","*.*")])
        if path:
            Path(path).write_text(text,encoding="utf-8")
            self._st(f"✓ Salvo: {Path(path).name}",self.GREEN)

    # ══════════════════════════════════════════════════════════════════════════
    #  SALVAR / COPIAR / HIGHLIGHT
    # ══════════════════════════════════════════════════════════════════════════

    def _save(self,key):
        sql=self.sql_texts[key].get("1.0","end").strip()
        if not sql: messagebox.showwarning("Aviso","Gere o script primeiro."); return
        db=self.db_type_var.get().replace(" ","_").replace("/","")
        path=filedialog.asksaveasfilename(
            defaultextension=".sql",
            initialfile=f"{key}_{db}_{datetime.now().strftime('%Y%m%d_%H%M')}.sql",
            filetypes=[("SQL","*.sql"),("All","*.*")])
        if path:
            Path(path).write_text(sql,encoding="utf-8")
            self._st(f"✓ Salvo: {Path(path).name}",self.GREEN)

    def _copy(self,key):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.sql_texts[key].get("1.0","end").strip())
        self._st("✓ Copiado.",self.GREEN)

    def _highlight(self,w):
        w.tag_configure("kw",       foreground="#cba6f7")
        w.tag_configure("comment",  foreground="#6c7086")
        w.tag_configure("string",   foreground="#a6e3a1")
        w.tag_configure("warn",     foreground="#f38ba8",background="#313244")
        w.tag_configure("override", foreground="#89dceb")
        c=w.get("1.0","end")
        def tag(pat,tn,fl=re.IGNORECASE):
            for m in re.finditer(pat,c,fl):
                s,e=m.start(),m.end()
                ls=c[:s].count("\n")+1; cs=s-c[:s].rfind("\n")-1
                le=c[:e].count("\n")+1; ce=e-c[:e].rfind("\n")-1
                w.tag_add(tn,f"{ls}.{cs}",f"{le}.{ce}")
        tag(SQL_KW,"kw"); tag(r"--[^\n]*","comment",0)
        tag(r"'[^']*'","string",0)
        tag(r"/\*\s*NÃO_ENCONTRADO[^*]*\*/","warn",0)
        tag(r"-- ERRO","warn",0)
        tag(r"-- .*Mapeamento fixo","override",0)

    # ══════════════════════════════════════════════════════════════════════════
    #  HELPERS
    # ══════════════════════════════════════════════════════════════════════════

    def _sec(self,p,text):
        f=tk.Frame(p,bg=self.ACC); f.pack(fill="x",padx=4,pady=(8,4))
        tk.Label(f,text=f"  {text}",fg="white",bg=self.ACC,
                 font=("Segoe UI",10,"bold")).pack(anchor="w",pady=3)

    def _entry(self,p,var=None,show=None,width=None,**kw):
        o=dict(textvariable=var,font=("Segoe UI",10),relief="solid",
               bd=1,bg="white",fg=self.TEXT,insertbackground=self.TEXT)
        if show:  o["show"]=show
        if width: o["width"]=width
        return tk.Entry(p,**o,**kw)

    def _btn(self,p,text,cmd,bg=None,fg=None,state="normal",**kw):
        f=kw.pop("font",("Segoe UI",10,"bold"))
        return tk.Button(p,text=text,command=cmd,
            bg=bg or self.CARD,fg=fg or self.TEXT,
            activebackground=self.ACC2,activeforeground="white",
            font=f,relief="flat",cursor="hand2",state=state,
            padx=kw.pop("padx",12),pady=kw.pop("pady",6),**kw)

    def _st(self,msg:str,color:str=None):
        self.lbl_st.configure(text=f"  {msg}",fg=color or self.MUT)
