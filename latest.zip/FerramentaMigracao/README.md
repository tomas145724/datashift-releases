# Migration Script Generator v3.0

## Estrutura

```
FerramentaMigracao/
├── main.py                      ← execute este
├── requirements.txt
├── data/
│   └── learned_mappings.json    ← criado automaticamente (aprendizado)
├── templates/
│   └── sql_templates.py         ← ✏️ EDITE OS SCRIPTS PADRÃO AQUI
├── core/
│   ├── connectors.py            ← conexão e leitura de schema
│   ├── mapper.py                ← identificação de tabelas/campos/JOINs
│   ├── renderer.py              ← substituição de placeholders
│   └── learner.py               ← sistema de aprendizado por feedback
└── gui/
    └── app.py                   ← interface gráfica
```

## Como executar

```bash
pip install -r requirements.txt
python main.py
```

## Novidades v3.0

### Templates com CampoTabela_
Os scripts usam `CampoTabela_xxx` como placeholders semânticos.
O mapper resolve automaticamente para `alias.coluna_real`.

### Detecção multi-tabela com JOIN automático
Se um campo não existir na tabela principal, o sistema:
1. Varre todas as outras tabelas do schema
2. Tenta detectar a condição JOIN (nome de coluna comum, FK por nome)
3. Gera `LEFT JOIN tabela_aux alias ON ...` automaticamente
4. Marca com comentário se não conseguir detectar a condição

### Identificação inteligente de tabelas
Tabelas de clientes podem se chamar: `cliente`, `t_cli`, `entidades`, `pessoas`,
`cadcliente`, `parceiro` etc. O sistema usa scoring com múltiplos critérios.
Duplo-clique na tabela no Schema para ver uma amostra de dados.

### Sistema de aprendizado (ML por feedback)
Aba "📚 Aprendizado":
1. Gere um script → clique "Enviar para Aprendizado"
2. Corrija os campos `NÃO_ENCONTRADO` e ajuste tabelas/JOINs
3. Clique "Aprender" — o sistema extrai os mapeamentos e os salva
4. Nas próximas gerações, esses mapeamentos têm prioridade

O aprendizado é persistido em `data/learned_mappings.json`.

### Adaptação de sintaxe por banco
- **SQL Server** → sintaxe nativa (ISNULL, GETDATE, CHARINDEX, dateadd)
- **Firebird**   → COALESCE, CURRENT_TIMESTAMP, POSITION, DATEADD N DAY TO, ||
- **MySQL**      → COALESCE, NOW(), LOCATE, DATE_ADD
- **PostgreSQL** → COALESCE, NOW(), POSITION, interval, SIMILAR TO
