"""
Migration Knowledge Server — SQL Server
=========================================
Servidor central de aprendizado compartilhado usando SQL Server como backend.

Configuração (edite a seção CONFIG abaixo ou use variáveis de ambiente):
  MKB_HOST      → host do SQL Server     (default: localhost)
  MKB_PORT      → porta                  (default: 1433)
  MKB_DATABASE  → nome do banco          (default: MigrationKB)
  MKB_USER      → usuário SQL            (default: vazio = Windows Auth)
  MKB_PASSWORD  → senha                  (default: vazio = Windows Auth)
  MKB_TRUSTED   → usar Windows Auth      (default: true)
  MKB_API_PORT  → porta da API REST      (default: 8765)

Execução:
  pip install -r requirements_server.txt
  python server.py

  # Ou com parâmetros:
  python server.py --host 0.0.0.0 --port 8765

Acesso da equipe:
  Todos configuram o app com:  http://IP_DO_SERVIDOR:8765
  Documentação automática:     http://IP_DO_SERVIDOR:8765/docs
"""

import os
import re
import uuid
import json
import argparse
from datetime import datetime
from contextlib import contextmanager

# ─── CONFIG — lê config.json se existir, depois variáveis de ambiente ────────

def _load_config() -> dict:
    import json as _json
    from pathlib import Path as _Path
    cfg_file = _Path(__file__).parent / "config.json"
    # Padrão pré-configurado com servidor da empresa
    base = {
        "host":     "br2sql.moveresoftware.com",
        "port":     "1906",
        "database": "FerramentaMigracao",
        "user":     "",
        "password": "",
        "trusted":  "false",
        # Credenciais de acesso à API REST
        "api_user": "",
        "api_pass": "",
    }
    if cfg_file.exists():
        try:
            data = _json.loads(cfg_file.read_text(encoding="utf-8"))
            ss   = data.get("sql_server", {})
            api  = data.get("api_auth",   {})
            base.update({k: v for k, v in ss.items() if v != ""})
            if api.get("user"):     base["api_user"] = api["user"]
            if api.get("password"): base["api_pass"] = api["password"]
            print(f"  Config carregado de: {cfg_file}")
        except Exception as e:
            print(f"  Aviso: erro ao ler config.json — {e}")
    # Variáveis de ambiente sobrepõem tudo
    env_map = {
        "MKB_HOST":     "host",     "MKB_PORT":     "port",
        "MKB_DATABASE": "database", "MKB_USER":     "user",
        "MKB_PASSWORD": "password", "MKB_TRUSTED":  "trusted",
        "MKB_API_USER": "api_user", "MKB_API_PASS": "api_pass",
    }
    for env, key in env_map.items():
        val = os.environ.get(env)
        if val: base[key] = val
    return base

CONFIG = _load_config()

# ─── Instalação automática de dependências ────────────────────────────────────

def _pip(pkg, imp=None):
    try: __import__(imp or pkg)
    except ImportError:
        import sys
        print(f"  Instalando {pkg}...")
        os.system(f'"{sys.executable}" -m pip install {pkg} -q')

_pip("fastapi"); _pip("uvicorn"); _pip("pydantic"); _pip("pyodbc")

from fastapi import FastAPI, HTTPException, Query, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel
import uvicorn
import pyodbc
import secrets

# ─── Conexão com SQL Server ───────────────────────────────────────────────────

def _build_conn_str(cfg: dict) -> str:
    trusted = str(cfg.get("trusted","true")).lower() in ("true","yes","s","sim","1")

    # Detecta drivers disponíveis
    avail = pyodbc.drivers()
    for drv in ["ODBC Driver 18 for SQL Server",
                "ODBC Driver 17 for SQL Server",
                "SQL Server"]:
        if drv in avail:
            driver = drv
            break
    else:
        driver = avail[0] if avail else "ODBC Driver 17 for SQL Server"

    base = (f"DRIVER={{{driver}}};"
            f"SERVER={cfg['host']},{cfg['port']};"
            f"DATABASE={cfg['database']};"
            f"TrustServerCertificate=yes;")

    if trusted:
        return base + "Trusted_Connection=yes;"
    else:
        return base + f"UID={cfg['user']};PWD={cfg['password']};"


@contextmanager
def get_conn():
    conn = pyodbc.connect(_build_conn_str(CONFIG), autocommit=False)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _n(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


# ─── DDL — criação das tabelas no SQL Server ──────────────────────────────────

DDL = """
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='mkb_table_hints')
CREATE TABLE mkb_table_hints (
    id          NVARCHAR(36)  NOT NULL PRIMARY KEY,
    table_norm  NVARCHAR(200) NOT NULL,
    table_orig  NVARCHAR(200) NOT NULL,
    entity_key  NVARCHAR(100) NOT NULL,
    db_type     NVARCHAR(100),
    weight      FLOAT         NOT NULL DEFAULT 1.0,
    ts          NVARCHAR(30),
    usuario     NVARCHAR(100),
    CONSTRAINT uq_table_hint UNIQUE (table_norm, entity_key)
);

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='mkb_field_hints')
CREATE TABLE mkb_field_hints (
    id          NVARCHAR(36)  NOT NULL PRIMARY KEY,
    field_norm  NVARCHAR(200) NOT NULL,
    field_orig  NVARCHAR(200) NOT NULL,
    semantic    NVARCHAR(200) NOT NULL,
    db_type     NVARCHAR(100),
    weight      FLOAT         NOT NULL DEFAULT 1.0,
    ts          NVARCHAR(30),
    usuario     NVARCHAR(100),
    CONSTRAINT uq_field_hint UNIQUE (field_norm, semantic)
);

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='mkb_join_patterns')
CREATE TABLE mkb_join_patterns (
    id          NVARCHAR(36)  NOT NULL PRIMARY KEY,
    table_a     NVARCHAR(200) NOT NULL,
    table_b     NVARCHAR(200) NOT NULL,
    condition_  NVARCHAR(MAX) NOT NULL,
    db_type     NVARCHAR(100),
    ts          NVARCHAR(30),
    usuario     NVARCHAR(100),
    CONSTRAINT uq_join UNIQUE (table_a, table_b)
);

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='mkb_sql_overrides')
CREATE TABLE mkb_sql_overrides (
    id          NVARCHAR(36)  NOT NULL PRIMARY KEY,
    entity_key  NVARCHAR(100) NOT NULL,
    db_type     NVARCHAR(100),
    client_tag  NVARCHAR(200),
    sql_text    NVARCHAR(MAX) NOT NULL,
    ts          NVARCHAR(30),
    usuario     NVARCHAR(100)
);

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name='mkb_history')
CREATE TABLE mkb_history (
    id          NVARCHAR(36)  NOT NULL PRIMARY KEY,
    ts          NVARCHAR(30),
    usuario     NVARCHAR(100),
    db_type     NVARCHAR(100),
    entity_key  NVARCHAR(100),
    action      NVARCHAR(100),
    detail      NVARCHAR(MAX)
);
"""


def init_db():
    """Cria o banco e as tabelas se ainda não existirem."""
    # Tenta conectar sem banco para criá-lo se necessário
    cfg_master = dict(CONFIG)
    cfg_master["database"] = "master"
    db_name = CONFIG["database"]

    try:
        with pyodbc.connect(_build_conn_str(cfg_master), autocommit=True) as conn:
            cur = conn.cursor()
            exists = cur.execute(
                "SELECT 1 FROM sys.databases WHERE name=?", (db_name,)
            ).fetchone()
            if not exists:
                cur.execute(f"CREATE DATABASE [{db_name}]")
                print(f"  Banco '{db_name}' criado.")
    except Exception as e:
        print(f"  Aviso ao verificar banco: {e}")

    # Cria as tabelas
    with get_conn() as conn:
        cur = conn.cursor()
        for stmt in DDL.strip().split(";\n\n"):
            stmt = stmt.strip()
            if stmt:
                cur.execute(stmt)
    print("  Tabelas verificadas/criadas com sucesso.")


# ─── FastAPI ──────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Migration Knowledge Base",
    description="Base de conhecimento compartilhada — SQL Server backend",
    version="2.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Autenticação Basic Auth ──────────────────────────────────────────────────

_security = HTTPBasic(auto_error=False)

def _check_auth(credentials: HTTPBasicCredentials = Depends(_security)):
    """
    Valida credenciais Basic Auth.
    Se api_user estiver vazio no config, a API é pública (sem autenticação).
    """
    api_user = CONFIG.get("api_user", "")
    api_pass = CONFIG.get("api_pass", "")

    # Sem credenciais configuradas → acesso livre
    if not api_user:
        return True

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais necessárias",
            headers={"WWW-Authenticate": "Basic"},
        )

    ok_user = secrets.compare_digest(
        credentials.username.encode(), api_user.encode()
    )
    ok_pass = secrets.compare_digest(
        credentials.password.encode(), api_pass.encode()
    )
    if not (ok_user and ok_pass):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário ou senha incorretos",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username

# Atalho para usar em todos os endpoints
Auth = Depends(_check_auth)


def _row_to_dict(cursor, row) -> dict:
    """Converte linha pyodbc para dict."""
    cols = [d[0] for d in cursor.description]
    return dict(zip(cols, row))


def _rows_to_list(cursor) -> list[dict]:
    cols = [d[0] for d in cursor.description]
    return [dict(zip(cols, r)) for r in cursor.fetchall()]


def _ts() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "status":  "ok",
        "service": "Migration Knowledge Base v2.0",
        "backend": "SQL Server",
        "banco":   CONFIG["database"],
    }


@app.get("/stats")
def stats(_auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        th  = cur.execute("SELECT COUNT(*) FROM mkb_table_hints").fetchone()[0]
        fh  = cur.execute("SELECT COUNT(*) FROM mkb_field_hints").fetchone()[0]
        jp  = cur.execute("SELECT COUNT(*) FROM mkb_join_patterns").fetchone()[0]
        so  = cur.execute("SELECT COUNT(*) FROM mkb_sql_overrides").fetchone()[0]
        his = cur.execute("SELECT COUNT(*) FROM mkb_history").fetchone()[0]
        cur.execute("""
            SELECT TOP 5 usuario, COUNT(*) AS n
            FROM mkb_history GROUP BY usuario ORDER BY n DESC
        """)
        top = _rows_to_list(cur)
    return {
        "table_hints":   th,
        "field_hints":   fh,
        "join_patterns": jp,
        "sql_overrides": so,
        "historico":     his,
        "top_usuarios":  top,
    }


# ── Table hints ───────────────────────────────────────────────────────────────

class TableHintIn(BaseModel):
    table_name: str
    entity_key: str
    db_type:    str = ""
    weight:     float = 1.0
    usuario:    str = "anonimo"

@app.post("/learn/table")
def learn_table(data: TableHintIn, _auth=Auth):
    norm = _n(data.table_name)
    ts   = _ts()
    with get_conn() as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT id, weight FROM mkb_table_hints "
            "WHERE table_norm=? AND entity_key=?",
            (norm, data.entity_key)
        ).fetchone()
        if row:
            cur.execute(
                "UPDATE mkb_table_hints SET weight=?, ts=?, usuario=? WHERE id=?",
                (row[1] + data.weight, ts, data.usuario, row[0])
            )
        else:
            cur.execute(
                "INSERT INTO mkb_table_hints VALUES (?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), norm, data.table_name,
                 data.entity_key, data.db_type, data.weight, ts, data.usuario)
            )
        cur.execute(
            "INSERT INTO mkb_history VALUES (?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), ts, data.usuario, data.db_type,
             data.entity_key, "table_hint",
             f"{data.table_name} → {data.entity_key}")
        )
    return {"ok": True}

@app.get("/learn/table")
def get_table_hints(entity_key: str = Query(None), _auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        if entity_key:
            cur.execute(
                "SELECT * FROM mkb_table_hints "
                "WHERE entity_key=? ORDER BY weight DESC",
                (entity_key,)
            )
        else:
            cur.execute(
                "SELECT * FROM mkb_table_hints ORDER BY weight DESC"
            )
        return _rows_to_list(cur)


# ── Field hints ───────────────────────────────────────────────────────────────

class FieldHintIn(BaseModel):
    field_name: str
    semantic:   str
    db_type:    str = ""
    weight:     float = 1.0
    usuario:    str = "anonimo"

@app.post("/learn/field")
def learn_field(data: FieldHintIn, _auth=Auth):
    norm = _n(data.field_name)
    ts   = _ts()
    with get_conn() as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT id, weight FROM mkb_field_hints "
            "WHERE field_norm=? AND semantic=?",
            (norm, data.semantic)
        ).fetchone()
        if row:
            cur.execute(
                "UPDATE mkb_field_hints SET weight=?, ts=?, usuario=? WHERE id=?",
                (row[1] + data.weight, ts, data.usuario, row[0])
            )
        else:
            cur.execute(
                "INSERT INTO mkb_field_hints VALUES (?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), norm, data.field_name,
                 data.semantic, data.db_type, data.weight, ts, data.usuario)
            )
    return {"ok": True}

@app.get("/learn/field")
def get_field_hints(semantic: str = Query(None), _auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        if semantic:
            cur.execute(
                "SELECT * FROM mkb_field_hints "
                "WHERE semantic=? ORDER BY weight DESC",
                (semantic,)
            )
        else:
            cur.execute("SELECT * FROM mkb_field_hints ORDER BY weight DESC")
        return _rows_to_list(cur)


# ── Join patterns ─────────────────────────────────────────────────────────────

class JoinPatternIn(BaseModel):
    table_a:   str
    table_b:   str
    condition: str
    db_type:   str = ""
    usuario:   str = "anonimo"

@app.post("/learn/join")
def learn_join(data: JoinPatternIn, _auth=Auth):
    na, nb = _n(data.table_a), _n(data.table_b)
    ka, kb = (na, nb) if na < nb else (nb, na)
    ts = _ts()
    with get_conn() as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT id FROM mkb_join_patterns WHERE table_a=? AND table_b=?",
            (ka, kb)
        ).fetchone()
        if row:
            cur.execute(
                "UPDATE mkb_join_patterns "
                "SET condition_=?, ts=?, usuario=? WHERE id=?",
                (data.condition, ts, data.usuario, row[0])
            )
        else:
            cur.execute(
                "INSERT INTO mkb_join_patterns VALUES (?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), ka, kb,
                 data.condition, data.db_type, ts, data.usuario)
            )
    return {"ok": True}

@app.get("/learn/join")
def get_join_patterns(table_a: str = Query(None), _auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        if table_a:
            na = _n(table_a)
            cur.execute(
                "SELECT * FROM mkb_join_patterns "
                "WHERE table_a=? OR table_b=?",
                (na, na)
            )
        else:
            cur.execute("SELECT * FROM mkb_join_patterns")
        return _rows_to_list(cur)


# ── SQL Overrides ─────────────────────────────────────────────────────────────

class SqlOverrideIn(BaseModel):
    entity_key: str
    sql_text:   str
    db_type:    str = ""
    client_tag: str = ""
    usuario:    str = "anonimo"

@app.post("/learn/override")
def learn_override(data: SqlOverrideIn, _auth=Auth):
    ts = _ts()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO mkb_sql_overrides VALUES (?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), data.entity_key, data.db_type,
             data.client_tag, data.sql_text, ts, data.usuario)
        )
        cur.execute(
            "INSERT INTO mkb_history VALUES (?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), ts, data.usuario, data.db_type,
             data.entity_key, "sql_override",
             f"cliente: {data.client_tag or 'sem tag'}")
        )
    return {"ok": True}

@app.get("/learn/override")
def get_overrides(
    entity_key: str = Query(None),
    db_type:    str = Query(None),
    _auth=Auth,
):
    with get_conn() as conn:
        cur = conn.cursor()
        q, p = "SELECT * FROM mkb_sql_overrides WHERE 1=1", []
        if entity_key:
            q += " AND entity_key=?"; p.append(entity_key)
        if db_type:
            q += " AND db_type=?";    p.append(db_type)
        q += " ORDER BY ts DESC"
        cur.execute(q, p)
        return _rows_to_list(cur)


# ── Sincronização bulk ────────────────────────────────────────────────────────

class BulkLearnIn(BaseModel):
    table_hints:   list[TableHintIn]   = []
    field_hints:   list[FieldHintIn]   = []
    join_patterns: list[JoinPatternIn] = []
    sql_overrides: list[SqlOverrideIn] = []
    usuario:       str = "anonimo"

@app.post("/sync/push")
def sync_push(data: BulkLearnIn, _auth=Auth):
    counts = {"table_hints": 0, "field_hints": 0,
              "join_patterns": 0, "sql_overrides": 0}
    for item in data.table_hints:
        item.usuario = data.usuario
        learn_table(item); counts["table_hints"] += 1
    for item in data.field_hints:
        item.usuario = data.usuario
        learn_field(item); counts["field_hints"] += 1
    for item in data.join_patterns:
        item.usuario = data.usuario
        learn_join(item); counts["join_patterns"] += 1
    for item in data.sql_overrides:
        item.usuario = data.usuario
        learn_override(item); counts["sql_overrides"] += 1
    return {"ok": True, "sincronizado": counts}

@app.get("/sync/pull")
def sync_pull(_auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM mkb_table_hints ORDER BY weight DESC")
        th = _rows_to_list(cur)
        cur.execute("SELECT * FROM mkb_field_hints ORDER BY weight DESC")
        fh = _rows_to_list(cur)
        cur.execute("SELECT * FROM mkb_join_patterns")
        jp = _rows_to_list(cur)
        cur.execute("SELECT * FROM mkb_sql_overrides ORDER BY ts DESC")
        so = _rows_to_list(cur)
    return {
        "table_hints":   th,
        "field_hints":   fh,
        "join_patterns": jp,
        "sql_overrides": so,
    }

@app.get("/history")
def get_history(limit: int = 50, _auth=Auth):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            f"SELECT TOP {min(limit,200)} * FROM mkb_history ORDER BY ts DESC"
        )
        return _rows_to_list(cur)


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Migration Knowledge Base Server — SQL Server"
    )
    parser.add_argument("--host",     default="0.0.0.0",      help="IP de escuta")
    parser.add_argument("--port",     type=int, default=8765,  help="Porta da API")
    parser.add_argument("--db-host",  default=None,  help="SQL Server host")
    parser.add_argument("--db-port",  default=None,  help="SQL Server porta")
    parser.add_argument("--db-name",  default=None,  help="Nome do banco")
    parser.add_argument("--db-user",  default=None,  help="Usuário SQL")
    parser.add_argument("--db-pass",  default=None,  help="Senha SQL")
    parser.add_argument("--trusted",  action="store_true", help="Windows Auth")
    args = parser.parse_args()

    if args.db_host:  CONFIG["host"]     = args.db_host
    if args.db_port:  CONFIG["port"]     = args.db_port
    if args.db_name:  CONFIG["database"] = args.db_name
    if args.db_user:  CONFIG["user"]     = args.db_user
    if args.db_pass:  CONFIG["password"] = args.db_pass
    if args.trusted:  CONFIG["trusted"]  = "true"

    print(f"\n{'='*60}")
    print(f"  Migration Knowledge Base — SQL Server Backend")
    print(f"  SQL Server : {CONFIG['host']}:{CONFIG['port']}")
    print(f"  Banco      : {CONFIG['database']}")
    print(f"  Auth       : {'Windows (Trusted)' if CONFIG['trusted'] in ('true','True','1') else 'SQL Login'}")
    print(f"  API        : http://0.0.0.0:{args.port}")
    print(f"  Docs       : http://0.0.0.0:{args.port}/docs")
    print(f"{'='*60}\n")

    print("Inicializando banco de dados...")
    init_db()

    uvicorn.run(app, host=args.host, port=args.port)
